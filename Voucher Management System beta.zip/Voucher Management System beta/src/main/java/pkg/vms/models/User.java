package pkg.vms.models;

import java.time.LocalDateTime;

public class User {
    private int userId;
    private String username;
    private String nom;
    private String prenom;
    private String role;       // 'admin', 'manager', 'agent'
    private String passwordHash;
    private LocalDateTime ddl;
    private String email;
    private String titre;
    private String statut;     // 'active', 'inactive', 'suspended'
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public User() {}

    public User(String username, String nom, String prenom, String role) {
        this.username = username;
        this.nom = nom;
        this.prenom = prenom;
        this.role = role;
        this.statut = "active";
    }

    // --- Getters / Setters principaux ---

    public int getUserId()                      { return userId; }
    public void setUserId(int userId)           { this.userId = userId; }

    public String getUsername()                 { return username; }
    public void setUsername(String username)    { this.username = username; }

    public String getNom()                      { return nom; }
    public void setNom(String nom)              { this.nom = nom; }

    public String getPrenom()                   { return prenom; }
    public void setPrenom(String prenom)        { this.prenom = prenom; }

    public String getRole()                     { return role; }
    public void setRole(String role)            { this.role = role; }

    public String getPasswordHash()             { return passwordHash; }
    public void setPasswordHash(String h)       { this.passwordHash = h; }

    public LocalDateTime getDdl()               { return ddl; }
    public void setDdl(LocalDateTime ddl)       { this.ddl = ddl; }

    public String getEmail()                    { return email; }
    public void setEmail(String email)          { this.email = email; }

    public String getTitre()                    { return titre; }
    public void setTitre(String titre)          { this.titre = titre; }

    public String getStatut()                   { return statut; }
    public void setStatut(String statut)        { this.statut = statut; }

    public LocalDateTime getCreatedAt()         { return createdAt; }
    public void setCreatedAt(LocalDateTime t)   { this.createdAt = t; }

    public LocalDateTime getUpdatedAt()         { return updatedAt; }
    public void setUpdatedAt(LocalDateTime t)   { this.updatedAt = t; }

    // --- Méthodes utilitaires ---

    /** Prénom + Nom, utilisé dans les affichages. */
    public String getFullName() {
        String p = (prenom != null) ? prenom : "";
        String n = (nom    != null) ? nom    : "";
        return (p + " " + n).trim();
    }

    public boolean isActive()   { return "active".equalsIgnoreCase(statut); }
    public boolean isAdmin()    { return "admin".equalsIgnoreCase(role); }
    public boolean isManager()  { return "manager".equalsIgnoreCase(role); }
    public boolean isAgent()    { return "agent".equalsIgnoreCase(role); }

    @Override
    public String toString() {
        return "User{userId=" + userId
                + ", username='" + username + '\''
                + ", role='" + role + '\''
                + ", statut='" + statut + '\''
                + '}';
    }
}
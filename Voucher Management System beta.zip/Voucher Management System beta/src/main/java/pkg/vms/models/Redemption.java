package pkg.vms.models;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Redemption {

    private int           refRedemption;
    private int           refVoucher;
    private String        noVoucher;
    private int           magasinId;
    private int           redeemedBy;
    private LocalDateTime dateRedemption;
    private String        statut;        // success | failed | already_redeemed | expired
    private String        motifEchec;
    private LocalDateTime createdAt;

    // Champs calculés / jointures
    private String    nomMagasin;
    private String    nomUtilisateur;
    private String    clientNom;
    private BigDecimal montantVoucher;
    private LocalDateTime expireDate;
    private String    voucherStatut;

    public Redemption() {}

    public int    getRefRedemption()                       { return refRedemption; }
    public void   setRefRedemption(int r)                  { this.refRedemption = r; }
    public int    getRefVoucher()                          { return refVoucher; }
    public void   setRefVoucher(int r)                     { this.refVoucher = r; }
    public String getNoVoucher()                           { return noVoucher; }
    public void   setNoVoucher(String n)                   { this.noVoucher = n; }
    public int    getMagasinId()                           { return magasinId; }
    public void   setMagasinId(int m)                      { this.magasinId = m; }
    public int    getRedeemedBy()                          { return redeemedBy; }
    public void   setRedeemedBy(int r)                     { this.redeemedBy = r; }
    public LocalDateTime getDateRedemption()               { return dateRedemption; }
    public void   setDateRedemption(LocalDateTime d)       { this.dateRedemption = d; }
    public String getStatut()                              { return statut; }
    public void   setStatut(String s)                      { this.statut = s; }
    public String getMotifEchec()                          { return motifEchec; }
    public void   setMotifEchec(String m)                  { this.motifEchec = m; }
    public LocalDateTime getCreatedAt()                    { return createdAt; }
    public void   setCreatedAt(LocalDateTime c)            { this.createdAt = c; }
    public String getNomMagasin()                          { return nomMagasin; }
    public void   setNomMagasin(String n)                  { this.nomMagasin = n; }
    public String getNomUtilisateur()                      { return nomUtilisateur; }
    public void   setNomUtilisateur(String n)              { this.nomUtilisateur = n; }
    public String getClientNom()                           { return clientNom; }
    public void   setClientNom(String n)                   { this.clientNom = n; }
    public BigDecimal getMontantVoucher()                  { return montantVoucher; }
    public void   setMontantVoucher(BigDecimal m)          { this.montantVoucher = m; }
    public LocalDateTime getExpireDate()                   { return expireDate; }
    public void   setExpireDate(LocalDateTime e)           { this.expireDate = e; }
    public String getVoucherStatut()                       { return voucherStatut; }
    public void   setVoucherStatut(String s)               { this.voucherStatut = s; }

    public boolean isSuccess() { return "success".equalsIgnoreCase(statut); }

    public String getStatutLabel() {
        if (statut == null) return "—";
        switch (statut.toLowerCase()) {
            case "success":          return "✅ Rédimé";
            case "already_redeemed": return "⚠️ Déjà rédimé";
            case "expired":          return "❌ Expiré";
            case "failed":           return "❌ Invalide";
            default:                 return statut;
        }
    }

    @Override
    public String toString() {
        return "Redemption{ref=" + refRedemption + ", voucher='" + noVoucher + "', statut='" + statut + "'}";
    }
}
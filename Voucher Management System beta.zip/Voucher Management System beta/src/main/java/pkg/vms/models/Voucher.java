package pkg.vms.models;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Voucher {
    private Integer refVoucher;
    private String noVoucher;
    private BigDecimal montant;
    private LocalDateTime issueDate;
    private LocalDateTime expireDate;
    private String qrCode;
    private String statusVouch;
    private Integer clientId;
    private Integer refDemande;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Additional fields for display
    private String clientName;
    private Integer quantity;

    // Constructors
    public Voucher() {
        this.montant = BigDecimal.ZERO;
        this.statusVouch = "draft";
    }

    public Voucher(Integer refVoucher, String noVoucher, BigDecimal montant, LocalDateTime issueDate,
                   LocalDateTime expireDate, String qrCode, String statusVouch, Integer clientId,
                   Integer refDemande, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.refVoucher = refVoucher;
        this.noVoucher = noVoucher;
        this.montant = montant;
        this.issueDate = issueDate;
        this.expireDate = expireDate;
        this.qrCode = qrCode;
        this.statusVouch = statusVouch;
        this.clientId = clientId;
        this.refDemande = refDemande;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public Integer getRefVoucher() {
        return refVoucher;
    }

    public void setRefVoucher(Integer refVoucher) {
        this.refVoucher = refVoucher;
    }

    public String getNoVoucher() {
        return noVoucher;
    }

    public void setNoVoucher(String noVoucher) {
        this.noVoucher = noVoucher;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    public LocalDateTime getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDateTime issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDateTime getExpireDate() {
        return expireDate;
    }

    public void setExpireDate(LocalDateTime expireDate) {
        this.expireDate = expireDate;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getStatusVouch() {
        return statusVouch;
    }

    public void setStatusVouch(String statusVouch) {
        this.statusVouch = statusVouch;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getRefDemande() {
        return refDemande;
    }

    public void setRefDemande(Integer refDemande) {
        this.refDemande = refDemande;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Voucher{" +
                "refVoucher=" + refVoucher +
                ", noVoucher='" + noVoucher + '\'' +
                ", montant=" + montant +
                ", statusVouch='" + statusVouch + '\'' +
                '}';
    }
}
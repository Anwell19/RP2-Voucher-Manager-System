package pkg.vms.models;

import java.time.LocalDateTime;

public class Client {

    public Integer getRef_client() {
        return ref_client;
    }

    public void setRef_client(Integer ref_client) {
        this.ref_client = ref_client;
    }

    private Integer ref_client;

    public String getNom_client() {
        return nom_client;
    }

    public void setNom_client(String nom_client) {
        this.nom_client = nom_client;
    }

    private String nom_client;
    private String email;
    private String adresse;
    private String company;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructeurs
    public Client() {
        this.createdAt = LocalDateTime.now();
    }

    public Client(String nom, String email, String company) {
        this();
        this.nom_client = nom;
        this.email = email;
        this.company = company;
    }

    // Getters et Setters
    public Integer getId() {
        return ref_client;
    }

    public void setId(Integer id) {
        this.ref_client = id;
    }

    public String getNom() {
        return nom_client;
    }

    public void setNom(String nom) {
        this.nom_client = nom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "Client{" +
                "id=" + ref_client +
                ", nom='" + nom_client + '\'' +
                ", email='" + email + '\'' +
                ", company='" + company + '\'' +
                '}';
    }
}
package pkg.vms.models;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Demande {

    private Integer refDemande;
    private Integer clientId;
    private LocalDateTime dateCreation;
    private Integer nbVoucher;
    private BigDecimal valeurVoucher;
    private String statut;
    private LocalDateTime datePayement;
    private LocalDateTime dateApprobation;
    private Integer duree;
    private LocalDate expireDate;
    private String statusDemande;
    private Integer initiatedBy;
    private Integer approvedBy;
    private Integer paidBy;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Champs affichage (jointure table client)
    private String clientNom;    // pour DemandeController → PropertyValueFactory("clientNom")
    private String clientName;   // pour VoucherController  → PropertyValueFactory("clientName")
    private String clientEmail;

    public Demande() {
        this.dateCreation = LocalDateTime.now();
        this.createdAt    = LocalDateTime.now();
        this.statut       = "initiee";
        this.nbVoucher    = 0;
        this.valeurVoucher = BigDecimal.ZERO;
    }

    // ── Getters / Setters ────────────────────────────────────────────────────

    public Integer getRefDemande() { return refDemande; }
    public void setRefDemande(Integer v) { this.refDemande = v; }

    public Integer getClientId() { return clientId; }
    public void setClientId(Integer v) { this.clientId = v; }

    public LocalDateTime getDateCreation() { return dateCreation; }
    public void setDateCreation(LocalDateTime v) { this.dateCreation = v; }

    public Integer getNbVoucher() { return nbVoucher; }
    public void setNbVoucher(Integer v) { this.nbVoucher = v; }

    public BigDecimal getValeurVoucher() { return valeurVoucher; }
    public void setValeurVoucher(BigDecimal v) { this.valeurVoucher = v; }

    public String getStatut() { return statut; }
    public void setStatut(String v) { this.statut = v; }

    public LocalDateTime getDatePayement() { return datePayement; }
    public void setDatePayement(LocalDateTime v) { this.datePayement = v; }

    /** Alias VoucherDAO appelle setDatePaiement */
    public void setDatePaiement(LocalDateTime v) { this.datePayement = v; }

    public LocalDateTime getDateApprobation() { return dateApprobation; }
    public void setDateApprobation(LocalDateTime v) { this.dateApprobation = v; }

    public Integer getDuree() { return duree; }
    public void setDuree(Integer v) { this.duree = v; }

    public LocalDate getExpireDate() { return expireDate; }
    public void setExpireDate(LocalDate v) { this.expireDate = v; }

    public String getStatusDemande() { return statusDemande; }
    public void setStatusDemande(String v) { this.statusDemande = v; }

    public Integer getInitiatedBy() { return initiatedBy; }
    public void setInitiatedBy(Integer v) { this.initiatedBy = v; }

    public Integer getApprovedBy() { return approvedBy; }
    public void setApprovedBy(Integer v) { this.approvedBy = v; }

    public Integer getPaidBy() { return paidBy; }
    public void setPaidBy(Integer v) { this.paidBy = v; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime v) { this.createdAt = v; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime v) { this.updatedAt = v; }

    // ── Champs client (jointure) ─────────────────────────────────────────────

    /** DemandeController utilise clientNom */
    public String getClientNom() { return clientNom; }
    public void setClientNom(String v) {
        this.clientNom = v;
        if (this.clientName == null) this.clientName = v; // sync
    }

    /** VoucherController utilise clientName */
    public String getClientName() { return clientName; }
    public void setClientName(String v) {
        this.clientName = v;
        if (this.clientNom == null) this.clientNom = v; // sync
    }

    public String getClientEmail() { return clientEmail != null ? clientEmail : ""; }
    public void setClientEmail(String v) { this.clientEmail = v; }

    // ── Méthodes calculées ───────────────────────────────────────────────────

    /** Total = nb_voucher × valeur_voucher  — utilisé par VoucherController */
    public BigDecimal getTotal() {
        if (nbVoucher != null && valeurVoucher != null)
            return valeurVoucher.multiply(BigDecimal.valueOf(nbVoucher));
        return BigDecimal.ZERO;
    }

    /** Alias pour DemandeController */
    public BigDecimal getMontantTotal() { return getTotal(); }

    /** Référence formatée ex: VR00007-10 */
    public String getReference() {
        if (refDemande != null && nbVoucher != null)
            return String.format("VR%05d-%02d", refDemande, nbVoucher);
        return "";
    }

    @Override
    public String toString() {
        return "Demande{refDemande=" + refDemande
                + ", clientName='" + clientName + '\''
                + ", nbVoucher=" + nbVoucher
                + ", valeurVoucher=" + valeurVoucher
                + ", statut='" + statut + "'}";
    }
}
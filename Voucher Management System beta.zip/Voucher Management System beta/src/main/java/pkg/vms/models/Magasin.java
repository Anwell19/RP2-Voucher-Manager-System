package pkg.vms.models;

import java.time.LocalDateTime;

public class Magasin {

    private Integer magasinId;
    private String nom;
    private String attribute1;
    private LocalDateTime createdAt;

    // Constructeur
    public Magasin() {
        this.createdAt = LocalDateTime.now();
    }

    public Magasin(String nom) {
        this();
        this.nom = nom;
    }

    // Getters et Setters
    public Integer getMagasinId() {
        return magasinId;
    }

    public void setMagasinId(Integer magasinId) {
        this.magasinId = magasinId;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAttribute1() {
        return attribute1;
    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Magasin{" +
                "magasinId=" + magasinId +
                ", nom='" + nom + '\'' +
                ", attribute1='" + attribute1 + '\'' +
                '}';
    }
}
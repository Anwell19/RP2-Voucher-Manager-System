package pkg.vms.utils;

public class Logger {
}

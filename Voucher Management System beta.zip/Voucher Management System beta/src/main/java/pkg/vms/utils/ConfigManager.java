package pkg.vms.utils;

public class ConfigManager {
}

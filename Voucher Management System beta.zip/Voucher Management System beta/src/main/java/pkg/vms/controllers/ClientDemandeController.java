package pkg.vms.controllers;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import pkg.vms.dao.ClientDAO;
import pkg.vms.dao.DemandeDAO;
import pkg.vms.models.Client;
import pkg.vms.models.Demande;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

/**
 * Controller pour la vue ClientDemande (formulaire public de soumission de bons cadeau).
 *
 * Corrections appliquées :
 *  - Validation email avec regex
 *  - Calcul automatique date expiration depuis la durée
 *  - Gestion du total avec BigDecimal (évite les erreurs de virgule flottante)
 *  - Bannière d'erreur inline (sans Dialog bloquant)
 *  - Récapitulatif mis à jour en temps réel via listeners
 *  - Initialisation défensive (ne plante pas si un champ est null)
 *  - Feedback visuel après soumission réussie
 */
public class ClientDemandeController implements Initializable {

    // ─── Champs Informations Client ──────────────────────────────────
    @FXML private TextField  txtNom;
    @FXML private TextField  txtEmail;
    @FXML private TextField  txtCompany;
    @FXML private TextArea   txtAdresse;
    @FXML private Label      lblEmailError;

    // ─── Champs Commande ─────────────────────────────────────────────
    @FXML private TextField  txtNbVoucher;
    @FXML private TextField  txtValeurVoucher;
    @FXML private TextField  txtDuree;
    @FXML private DatePicker dateExpire;
    @FXML private TextArea   txtNotes;

    // ─── Récapitulatif ────────────────────────────────────────────────
    @FXML private Label      lblRecapNbVoucher;
    @FXML private Label      lblRecapValeur;
    @FXML private Label      lblRecapDuree;
    @FXML private Label      lblMontantTotal;
    @FXML private Label      lblTotalDetail;
    @FXML private Label      lblReference;

    // ─── Interface ───────────────────────────────────────────────────
    @FXML private ProgressBar progressBar;
    @FXML private HBox        alertBanner;
    @FXML private Label       alertMessage;
    @FXML private Label       lblStatus;

    // ─── Boutons ─────────────────────────────────────────────────────
    @FXML private Button btnSoumettre;
    @FXML private Button btnReinitialiser;
    @FXML private Button btnAnnuler;

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

    // ─── DAOs ─────────────────────────────────────────────────────────
    private final ClientDAO  clientDAO  = new ClientDAO();
    private final DemandeDAO demandeDAO = new DemandeDAO();

    // ─────────────────────────────────────────────────────────────────
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        configurerListeners();
        reinitialiserRecap();
        setStatus("Prêt — remplissez le formulaire et soumettez votre demande.");
    }

    // ─── Listeners temps réel ────────────────────────────────────────

    private void configurerListeners() {
        // Mise à jour récapitulatif à chaque frappe
        txtNbVoucher.textProperty().addListener((obs, o, n)     -> mettreAJourRecap());
        txtValeurVoucher.textProperty().addListener((obs, o, n) -> mettreAJourRecap());
        txtDuree.textProperty().addListener((obs, o, n)         -> {
            calculerDateExpirationDepuisDuree();
            mettreAJourRecap();
        });

        // Validation email en temps réel
        txtEmail.focusedProperty().addListener((obs, estFocus, perduFocus) -> {
            if (perduFocus) validerEmail(txtEmail.getText());
        });

        // DatePicker → recalcul durée si date choisie manuellement
        dateExpire.valueProperty().addListener((obs, o, n) -> {
            if (n != null && txtDuree.getText().trim().isEmpty()) {
                long jours = LocalDate.now().until(n, java.time.temporal.ChronoUnit.DAYS);
                if (jours > 0) txtDuree.setText(String.valueOf(jours));
            }
        });
    }

    private void mettreAJourRecap() {
        String nbStr  = txtNbVoucher.getText().trim();
        String valStr = txtValeurVoucher.getText().trim();
        String durStr = txtDuree.getText().trim();

        // Nombre de vouchers
        if (!nbStr.isEmpty() && nbStr.matches("\\d+")) {
            lblRecapNbVoucher.setText(nbStr + " bon(s)");
        } else {
            lblRecapNbVoucher.setText("—");
        }

        // Valeur unitaire
        try {
            BigDecimal val = new BigDecimal(valStr);
            lblRecapValeur.setText("Rs " + val.setScale(2, RoundingMode.HALF_UP));
        } catch (NumberFormatException e) {
            lblRecapValeur.setText("—");
        }

        // Durée
        if (!durStr.isEmpty() && durStr.matches("\\d+")) {
            lblRecapDuree.setText(durStr + " j");
        } else {
            lblRecapDuree.setText("—");
        }

        // Total
        try {
            int nb = Integer.parseInt(nbStr);
            BigDecimal val = new BigDecimal(valStr);
            BigDecimal total = val.multiply(BigDecimal.valueOf(nb)).setScale(2, RoundingMode.HALF_UP);
            lblMontantTotal.setText("Rs " + total.toPlainString());
            lblTotalDetail.setText(nb + " × Rs " + val.setScale(2, RoundingMode.HALF_UP));
        } catch (Exception e) {
            lblMontantTotal.setText("Rs 0.00");
            lblTotalDetail.setText("");
        }
    }

    private void calculerDateExpirationDepuisDuree() {
        String durStr = txtDuree.getText().trim();
        if (!durStr.isEmpty() && durStr.matches("\\d+")) {
            try {
                int jours = Integer.parseInt(durStr);
                dateExpire.setValue(LocalDate.now().plusDays(jours));
            } catch (NumberFormatException ignored) {}
        }
    }

    // ─── Validation ──────────────────────────────────────────────────

    private boolean validerEmail(String email) {
        if (lblEmailError == null) return true;
        if (email == null || email.trim().isEmpty()) {
            cacherEmailError();
            return false;
        }
        if (!email.matches(EMAIL_REGEX)) {
            afficherEmailError("Format d'email invalide (ex : nom@domaine.com)");
            return false;
        }
        cacherEmailError();
        return true;
    }

    private void afficherEmailError(String msg) {
        if (lblEmailError != null) {
            lblEmailError.setText(msg);
            lblEmailError.setVisible(true);
            lblEmailError.setManaged(true);
        }
    }

    private void cacherEmailError() {
        if (lblEmailError != null) {
            lblEmailError.setVisible(false);
            lblEmailError.setManaged(false);
        }
    }

    private boolean validerFormulaire() {
        StringBuilder erreurs = new StringBuilder();

        // Nom
        if (txtNom.getText().trim().isEmpty())
            erreurs.append("• Le nom complet est obligatoire.\n");

        // Email
        String email = txtEmail.getText().trim();
        if (email.isEmpty()) {
            erreurs.append("• L'adresse email est obligatoire.\n");
        } else if (!email.matches(EMAIL_REGEX)) {
            erreurs.append("• L'adresse email n'est pas valide.\n");
        }

        // Adresse
        if (txtAdresse.getText().trim().isEmpty())
            erreurs.append("• L'adresse de livraison est obligatoire.\n");

        // Nombre de vouchers
        String nbStr = txtNbVoucher.getText().trim();
        if (nbStr.isEmpty()) {
            erreurs.append("• Le nombre de vouchers est obligatoire.\n");
        } else {
            try {
                int nb = Integer.parseInt(nbStr);
                if (nb <= 0) erreurs.append("• Le nombre de vouchers doit être > 0.\n");
                if (nb > 10000) erreurs.append("• Le nombre de vouchers ne peut excéder 10 000.\n");
            } catch (NumberFormatException e) {
                erreurs.append("• Le nombre de vouchers doit être un entier.\n");
            }
        }

        // Valeur unitaire
        String valStr = txtValeurVoucher.getText().trim();
        if (valStr.isEmpty()) {
            erreurs.append("• La valeur unitaire est obligatoire.\n");
        } else {
            try {
                BigDecimal val = new BigDecimal(valStr);
                if (val.compareTo(BigDecimal.ZERO) <= 0)
                    erreurs.append("• La valeur unitaire doit être > 0.\n");
            } catch (NumberFormatException e) {
                erreurs.append("• La valeur unitaire doit être un nombre (ex : 500.00).\n");
            }
        }

        if (erreurs.length() > 0) {
            afficherAlerte(erreurs.toString().trim());
            return false;
        }
        cacherAlerte();
        return true;
    }

    // ─── Handlers boutons ────────────────────────────────────────────

    @FXML
    public void handleSoumettre(ActionEvent event) {
        if (!validerFormulaire()) return;

        btnSoumettre.setDisable(true);
        setStatus("⏳ Envoi de la demande en cours...");
        if (progressBar != null) progressBar.setProgress(-1); // animation indéterminée

        // Exécution dans un thread secondaire pour ne pas bloquer l'UI
        Thread thread = new Thread(() -> {
            try {
                // 1. Créer ou récupérer le client
                Client client = new Client();
                client.setNom(txtNom.getText().trim());
                client.setEmail(txtEmail.getText().trim());
                client.setCompany(txtCompany.getText().trim().isEmpty() ? null : txtCompany.getText().trim());
                client.setAdresse(txtAdresse.getText().trim());

                boolean clientCree = clientDAO.create(client);
                if (!clientCree || client.getId() == null) {
                    Platform.runLater(() -> {
                        afficherAlerte("Erreur lors de la création du client. Vérifiez la connexion à la base de données.");
                        btnSoumettre.setDisable(false);
                        if (progressBar != null) progressBar.setProgress(0.33);
                        setStatus("❌ Échec de la soumission.");
                    });
                    return;
                }

                // 2. Créer la demande
                Demande demande = new Demande();
                demande.setClientId(client.getId());
                demande.setNbVoucher(Integer.parseInt(txtNbVoucher.getText().trim()));
                demande.setValeurVoucher(new BigDecimal(txtValeurVoucher.getText().trim()));
                demande.setStatusDemande("Demande en attente de validation");

                // Durée
                String durStr = txtDuree.getText().trim();
                if (!durStr.isEmpty() && durStr.matches("\\d+")) {
                    demande.setDuree(Integer.parseInt(durStr));
                } else {
                    demande.setDuree(90); // valeur par défaut
                }

                // Date expiration
                if (dateExpire.getValue() != null) {
                    demande.setExpireDate(dateExpire.getValue());
                } else {
                    demande.setExpireDate(LocalDate.now().plusDays(demande.getDuree()));
                }

                // initiated_by = null (demande publique, non liée à un agent connecté)
                demande.setInitiatedBy(null);

                boolean demandeCreee = demandeDAO.create(demande);

                Platform.runLater(() -> {
                    if (demandeCreee) {
                        String ref = "DMD-" + demande.getRefDemande();
                        if (lblReference != null) lblReference.setText("Réf : " + ref);
                        if (progressBar != null) progressBar.setProgress(1.0);
                        cacherAlerte();
                        setStatus("✅ Demande soumise avec succès — Référence : " + ref);
                        afficherSucces(ref);
                    } else {
                        afficherAlerte("Erreur lors de la création de la demande. Réessayez ou contactez le support.");
                        if (progressBar != null) progressBar.setProgress(0.33);
                        setStatus("❌ Échec de la soumission.");
                    }
                    btnSoumettre.setDisable(false);
                });

            } catch (Exception ex) {
                Platform.runLater(() -> {
                    afficherAlerte("Erreur inattendue : " + ex.getMessage());
                    btnSoumettre.setDisable(false);
                    if (progressBar != null) progressBar.setProgress(0.33);
                    setStatus("❌ Erreur inattendue.");
                });
                ex.printStackTrace();
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    @FXML
    public void handleReinitialiser(ActionEvent event) {
        txtNom.clear();
        txtEmail.clear();
        txtCompany.clear();
        txtAdresse.clear();
        txtNbVoucher.clear();
        txtValeurVoucher.clear();
        txtDuree.clear();
        dateExpire.setValue(null);
        if (txtNotes != null) txtNotes.clear();
        reinitialiserRecap();
        cacherAlerte();
        cacherEmailError();
        if (progressBar != null) progressBar.setProgress(0.33);
        if (lblReference != null) lblReference.setText("Réf. générée à la soumission");
        setStatus("Formulaire réinitialisé.");
        txtNom.requestFocus();
    }

    @FXML
    public void handleAnnuler(ActionEvent event) {
        // Ferme la fenêtre ou revient au dashboard selon le contexte
        if (txtNom.getScene() != null && txtNom.getScene().getWindow() != null) {
            txtNom.getScene().getWindow().hide();
        }
    }

    @FXML
    public void handleFermerAlert(ActionEvent event) {
        cacherAlerte();
    }

    // ─── Alertes inline ──────────────────────────────────────────────

    private void afficherAlerte(String message) {
        if (alertBanner != null && alertMessage != null) {
            alertMessage.setText(message);
            alertBanner.setVisible(true);
            alertBanner.setManaged(true);
        }
    }

    private void cacherAlerte() {
        if (alertBanner != null) {
            alertBanner.setVisible(false);
            alertBanner.setManaged(false);
        }
    }

    private void afficherSucces(String ref) {
        // Affiche une boîte de dialogue de succès
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Demande soumise");
        alert.setHeaderText("✅  Demande envoyée avec succès !");
        alert.setContentText(
            "Votre demande a bien été enregistrée.\n\n" +
            "Référence : " + ref + "\n\n" +
            "Vous recevrez une confirmation par email sous peu.\n" +
            "Le traitement prend 24–48h ouvrées."
        );
        alert.showAndWait();
    }

    // ─── Helpers ─────────────────────────────────────────────────────

    private void reinitialiserRecap() {
        if (lblRecapNbVoucher != null) lblRecapNbVoucher.setText("—");
        if (lblRecapValeur    != null) lblRecapValeur.setText("—");
        if (lblRecapDuree     != null) lblRecapDuree.setText("—");
        if (lblMontantTotal   != null) lblMontantTotal.setText("Rs 0.00");
        if (lblTotalDetail    != null) lblTotalDetail.setText("");
    }

    private void setStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }
}

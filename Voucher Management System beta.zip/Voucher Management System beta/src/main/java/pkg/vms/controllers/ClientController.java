package pkg.vms.controllers;

import pkg.vms.dao.ClientDAO;
import pkg.vms.models.Client;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class ClientController {

    @FXML private TextField txtNom;
    @FXML private TextField txtEmail;
    @FXML private TextField txtCompany;
    @FXML private TextField txtAdresse;
    @FXML private TextField txtRecherche;

    @FXML private TableView<Client> tableClients;
    @FXML private TableColumn<Client, Integer> colId;
    @FXML private TableColumn<Client, String> colNom;
    @FXML private TableColumn<Client, String> colEmail;
    @FXML private TableColumn<Client, String> colCompany;
    @FXML private TableColumn<Client, String> colAdresse;
    @FXML private TableColumn<Client, String> colCreatedAt;

    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;

    @FXML private Label lblStatus;
    @FXML private Label lblTotal;

    private ClientDAO clientDAO;
    private ObservableList<Client> clientsList;
    private Client selectedClient;
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    @FXML
    public void initialize() {
        clientDAO = new ClientDAO();
        clientsList = FXCollections.observableArrayList();

        // Initialiser les colonnes du tableau
        initializeTableColumns();

        // Charger les données
        loadClients();

        // Configurer la sélection dans le tableau
        tableClients.setOnMouseClicked(this::handleTableClick);

        // État initial des boutons
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);

        updateStatus("Prêt");
    }

    private void initializeTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colCompany.setCellValueFactory(new PropertyValueFactory<>("company"));
        colAdresse.setCellValueFactory(new PropertyValueFactory<>("adresse"));

        // Formatter la date de création
        colCreatedAt.setCellValueFactory(cellData -> {
            LocalDateTime date = cellData.getValue().getCreatedAt();
            return new javafx.beans.property.SimpleStringProperty(
                    date != null ? date.format(dateFormatter) : ""
            );
        });

        // Permettre le tri sur toutes les colonnes
        tableClients.getSortOrder().add(colNom);
    }

    private void loadClients() {
        List<Client> clients = clientDAO.readAll();
        clientsList.clear();
        clientsList.addAll(clients);
        tableClients.setItems(clientsList);
        updateTotal();
        updateStatus("Clients chargés : " + clients.size() + " client(s)");
    }

    @FXML
    private void handleAjouter() {
        if (validateInput()) {
            Client client = new Client();
            fillClientFromForm(client);

            // Vérifier si l'email existe déjà
            if (clientDAO.emailExists(client.getEmail(), null)) {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Cet email est déjà utilisé par un autre client.");
                return;
            }

            if (clientDAO.create(client)) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "Client ajouté avec succès.");
                loadClients();
                clearForm();
                updateStatus("Client ajouté : " + client.getNom());
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'ajouter le client.");
            }
        }
    }

    @FXML
    private void handleModifier() {
        if (selectedClient == null) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez sélectionner un client à modifier.");
            return;
        }

        if (validateInput()) {
            fillClientFromForm(selectedClient);

            // Vérifier si l'email existe déjà (sauf pour le client actuel)
            if (clientDAO.emailExists(selectedClient.getEmail(), selectedClient.getId())) {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Cet email est déjà utilisé par un autre client.");
                return;
            }

            if (clientDAO.update(selectedClient)) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "Client modifié avec succès.");
                loadClients();
                clearForm();
                updateStatus("Client modifié : " + selectedClient.getNom());
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de modifier le client.");
            }
        }
    }

    @FXML
    private void handleSupprimer() {
        if (selectedClient == null) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez sélectionner un client à supprimer.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmation");
        confirmation.setHeaderText("Supprimer le client");
        confirmation.setContentText("Êtes-vous sûr de vouloir supprimer " + selectedClient.getNom() + " ?\n" +
                "Cette action est irréversible.");

        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (clientDAO.delete(selectedClient.getId())) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "Client supprimé avec succès.");
                loadClients();
                clearForm();
                updateStatus("Client supprimé");
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de supprimer le client.\n" +
                        "Le client a peut-être des demandes associées.");
            }
        }
    }

    @FXML
    private void handleNouveau() {
        clearForm();
        updateStatus("Nouveau formulaire");
    }

    @FXML
    private void handleRecherche(KeyEvent event) {
        String keyword = txtRecherche.getText().trim();

        if (keyword.isEmpty()) {
            loadClients();
        } else {
            List<Client> results = clientDAO.search(keyword);
            clientsList.clear();
            clientsList.addAll(results);
            tableClients.setItems(clientsList);
            updateTotal();
            updateStatus("Recherche : " + results.size() + " résultat(s)");
        }
    }

    @FXML
    private void handleRafraichir() {
        txtRecherche.clear();
        loadClients();
        clearForm();
        updateStatus("Données rafraîchies");
    }

    private void handleTableClick(MouseEvent event) {
        Client client = tableClients.getSelectionModel().getSelectedItem();
        if (client != null) {
            selectedClient = client;
            fillFormFromClient(client);
            btnModifier.setDisable(false);
            btnSupprimer.setDisable(false);
            updateStatus("Client sélectionné : " + client.getNom());
        }
    }

    private void fillClientFromForm(Client client) {
        client.setNom(txtNom.getText().trim());
        client.setEmail(txtEmail.getText().trim().toLowerCase());
        client.setCompany(txtCompany.getText().trim());
        client.setAdresse(txtAdresse.getText().trim());
    }

    private void fillFormFromClient(Client client) {
        txtNom.setText(client.getNom());
        txtEmail.setText(client.getEmail());
        txtCompany.setText(client.getCompany());
        txtAdresse.setText(client.getAdresse());
    }

    private void clearForm() {
        txtNom.clear();
        txtEmail.clear();
        txtCompany.clear();
        txtAdresse.clear();

        selectedClient = null;
        tableClients.getSelectionModel().clearSelection();
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
    }

    private boolean validateInput() {
        StringBuilder errors = new StringBuilder();

        if (txtNom.getText().trim().isEmpty()) {
            errors.append("- Le nom est obligatoire\n");
        }

        if (txtEmail.getText().trim().isEmpty()) {
            errors.append("- L'email est obligatoire\n");
        } else if (!isValidEmail(txtEmail.getText().trim())) {
            errors.append("- L'email n'est pas valide\n");
        }

        if (errors.length() > 0) {
            showAlert(Alert.AlertType.ERROR, "Erreur de validation", errors.toString());
            return false;
        }

        return true;
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email.matches(emailRegex);
    }

    private void updateTotal() {
        lblTotal.setText("Total : " + clientsList.size() + " client(s)");
    }

    private void updateStatus(String message) {
        lblStatus.setText(message);
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

}
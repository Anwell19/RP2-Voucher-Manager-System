package pkg.vms.controllers;

public class ApprobationController {
}

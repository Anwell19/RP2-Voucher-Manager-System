package pkg.vms.controllers;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import pkg.vms.dao.UserManagementDAO;
import pkg.vms.dao.UserPermissionsDAO;
import pkg.vms.dao.UserPermissionsDAO.UserPermissions;
import pkg.vms.models.User;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Contrôleur de UserManagement.fxml
 *
 * Nouveauté : gestion des permissions par menu via UserPermissionsDAO.
 * L'admin peut cocher/décocher chacun des 5 menus pour chaque utilisateur.
 * Les permissions sont sauvegardées dans vms.user_permissions.
 */
public class UserManagementController {

    // ---- Formulaire ----
    @FXML private TextField        txtUsername;
    @FXML private TextField        txtFullName;
    @FXML private TextField        txtEmail;
    @FXML private TextField        txtTitre;
    @FXML private ComboBox<String> cmbRole;
    @FXML private ComboBox<String> cmbStatut;
    @FXML private PasswordField    txtPassword;
    @FXML private PasswordField    txtPasswordConfirm;
    @FXML private TextField        txtRecherche;

    // ---- Permissions (5 CheckBoxes) ----
    @FXML private CheckBox chkClients;
    @FXML private CheckBox chkUsers;
    @FXML private CheckBox chkMagasins;
    @FXML private CheckBox chkDemandes;
    @FXML private CheckBox chkVouchers;

    // ---- Boutons permissions ----
    @FXML private Button btnSelectAll;
    @FXML private Button btnClearAll;
    @FXML private Label  lblPermHint;

    // ---- Tableau ----
    @FXML private TableView<User>            tableUsers;
    @FXML private TableColumn<User, Integer> colId;
    @FXML private TableColumn<User, String>  colUsername;
    @FXML private TableColumn<User, String>  colFullName;
    @FXML private TableColumn<User, String>  colEmail;
    @FXML private TableColumn<User, String>  colRole;
    @FXML private TableColumn<User, String>  colStatut;
    @FXML private TableColumn<User, String>  colPermissions;   // ← nouvelle colonne
    @FXML private TableColumn<User, String>  colCreatedAt;
    @FXML private TableColumn<User, String>  colUpdatedAt;

    // ---- Boutons CRUD ----
    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;
    @FXML private Button btnResetPassword;

    // ---- Statut ----
    @FXML private Label lblStatus;
    @FXML private Label lblTotal;

    // ---- État interne ----
    private UserManagementDAO  dao;
    private UserPermissionsDAO permDao;
    private ObservableList<User> usersList;
    private User selectedUser;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private static final List<String> ROLES   = List.of("admin", "manager", "agent");
    private static final List<String> STATUTS = List.of("active", "inactive", "suspended");

    // =========================================================
    // Initialisation
    // =========================================================

    @FXML
    public void initialize() {
        dao       = new UserManagementDAO();
        permDao   = new UserPermissionsDAO();
        usersList = FXCollections.observableArrayList();

        initTableColumns();
        initComboBoxes();
        loadUsers();

        tableUsers.setOnMouseClicked(this::handleTableClick);
        setSelectionDependentButtons(true);
        updateStatus("Prêt");
    }

    private void initTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("userId"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));

        colFullName.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getFullName()));

        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));

        // Colonne "Menus autorisés" : charge les permissions depuis la DB
        if (colPermissions != null) {
            colPermissions.setCellValueFactory(data -> {
                User u = data.getValue();
                if (u.getUserId() <= 0) return new SimpleStringProperty("—");
                UserPermissions p = permDao.getByUserId(u.getUserId());
                return new SimpleStringProperty(buildPermissionSummary(p));
            });
        }

        colCreatedAt.setCellValueFactory(data -> {
            LocalDateTime d = data.getValue().getCreatedAt();
            return new SimpleStringProperty(d != null ? d.format(FMT) : "");
        });
        colUpdatedAt.setCellValueFactory(data -> {
            LocalDateTime d = data.getValue().getUpdatedAt();
            return new SimpleStringProperty(d != null ? d.format(FMT) : "");
        });
    }

    /** Construit un résumé textuel des permissions pour la colonne tableau. */
    private String buildPermissionSummary(UserPermissions p) {
        if (p == null) return "Aucun accès";
        StringBuilder sb = new StringBuilder();
        if (p.isMenuClients())   sb.append("Clients ");
        if (p.isMenuUsers())     sb.append("Users ");
        if (p.isMenuMagasins())  sb.append("Magasins ");
        if (p.isMenuDemandes())  sb.append("Demandes ");
        if (p.isMenuVouchers())  sb.append("Vouchers ");
        return sb.length() > 0 ? sb.toString().trim() : "Aucun accès";
    }

    private void initComboBoxes() {
        cmbRole.setItems(FXCollections.observableArrayList(ROLES));
        if (cmbStatut != null)
            cmbStatut.setItems(FXCollections.observableArrayList(STATUTS));
    }

    // =========================================================
    // Chargement
    // =========================================================

    private void loadUsers() {
        List<User> users = dao.readAll();
        usersList.setAll(users);
        tableUsers.setItems(usersList);
        updateTotal();
        updateStatus("✓ " + users.size() + " utilisateur(s) chargé(s)");
    }

    // =========================================================
    // Handler : changement de rôle → suggestion de permissions
    // =========================================================

    @FXML
    private void handleRoleChange() {
        String role = cmbRole.getValue();
        if (role == null) return;

        // Pré-remplir les CheckBoxes selon le rôle choisi
        // L'admin peut toujours modifier manuellement après
        switch (role.toLowerCase()) {
            case "admin" -> {
                setAllPermissions(true);
                setPermHint("💡 Admin : tous les menus activés par défaut");
            }
            case "manager" -> {
                chkClients .setSelected(true);
                chkUsers   .setSelected(false);
                chkMagasins.setSelected(true);
                chkDemandes.setSelected(true);
                chkVouchers.setSelected(true);
                setPermHint("💡 Manager : Clients, Magasins, Demandes, Vouchers");
            }
            case "agent" -> {
                chkClients .setSelected(false);
                chkUsers   .setSelected(false);
                chkMagasins.setSelected(false);
                chkDemandes.setSelected(true);
                chkVouchers.setSelected(true);
                setPermHint("💡 Agent : Demandes et Vouchers uniquement");
            }
            default -> setPermHint("💡 Sélectionnez les menus accessibles");
        }
    }

    @FXML
    private void handleSelectAllPermissions() {
        setAllPermissions(true);
    }

    @FXML
    private void handleClearAllPermissions() {
        setAllPermissions(false);
    }

    private void setAllPermissions(boolean value) {
        chkClients .setSelected(value);
        chkUsers   .setSelected(value);
        chkMagasins.setSelected(value);
        chkDemandes.setSelected(value);
        chkVouchers.setSelected(value);
    }

    private void setPermHint(String text) {
        if (lblPermHint != null) lblPermHint.setText(text);
    }

    // =========================================================
    // CRUD
    // =========================================================

    @FXML
    private void handleAjouter() {
        if (!validateInput(true)) return;

        User user = buildUserFromForm();

        if (dao.usernameExists(user.getUsername(), null)) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Ce nom d'utilisateur existe déjà.");
            return;
        }
        if (user.getEmail() != null && !user.getEmail().isEmpty()
                && dao.emailExists(user.getEmail(), null)) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Cet email est déjà utilisé.");
            return;
        }

        String password = txtPassword.getText().trim();

        if (dao.create(user, password)) {
            // Sauvegarder les permissions
            UserPermissions perms = buildPermissionsFromCheckboxes(user.getUserId());
            boolean permSaved = permDao.save(perms);

            String msg = "✓ Utilisateur créé avec succès.";
            if (!permSaved) msg += "\n⚠️ Avertissement : les permissions n'ont pas pu être enregistrées.";

            showAlert(Alert.AlertType.INFORMATION, "Succès", msg);
            loadUsers();
            clearForm();
            updateStatus("Utilisateur ajouté : " + user.getUsername());
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de créer l'utilisateur.");
        }
    }

    @FXML
    private void handleModifier() {
        if (selectedUser == null) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez sélectionner un utilisateur.");
            return;
        }
        if (!validateInput(false)) return;

        User updated = buildUserFromForm();
        updated.setUserId(selectedUser.getUserId());

        if (dao.usernameExists(updated.getUsername(), updated.getUserId())) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Ce nom d'utilisateur existe déjà.");
            return;
        }
        if (updated.getEmail() != null && !updated.getEmail().isEmpty()
                && dao.emailExists(updated.getEmail(), updated.getUserId())) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Cet email est déjà utilisé.");
            return;
        }

        if (dao.update(updated)) {
            // Mettre à jour le mot de passe si saisi
            String newPassword = txtPassword.getText().trim();
            if (!newPassword.isEmpty()) {
                dao.changePassword(updated.getUserId(), newPassword);
            }

            // Sauvegarder les permissions
            UserPermissions perms = buildPermissionsFromCheckboxes(updated.getUserId());
            boolean permSaved = permDao.save(perms);

            String msg = newPassword.isEmpty()
                    ? "✓ Utilisateur modifié."
                    : "✓ Utilisateur et mot de passe modifiés.";
            if (!permSaved) msg += "\n⚠️ Avertissement : les permissions n'ont pas pu être mises à jour.";

            showAlert(Alert.AlertType.INFORMATION, "Succès", msg);
            loadUsers();
            clearForm();
            updateStatus("Modifié : " + updated.getUsername());
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de modifier l'utilisateur.");
        }
    }

    @FXML
    private void handleSupprimer() {
        if (selectedUser == null) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez sélectionner un utilisateur.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText("Supprimer l'utilisateur");
        confirm.setContentText("Supprimer « " + selectedUser.getUsername()
                + " » (" + selectedUser.getFullName() + ") ?\n⚠️ Action irréversible.");

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // Les permissions sont supprimées automatiquement par ON DELETE CASCADE
            if (dao.delete(selectedUser.getUserId())) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "✓ Utilisateur supprimé.");
                loadUsers();
                clearForm();
                updateStatus("Utilisateur supprimé");
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur",
                        "Impossible de supprimer l'utilisateur.\n"
                                + "Il est peut-être lié à des données existantes.");
            }
        }
    }

    @FXML
    private void handleNouveau() {
        clearForm();
        updateStatus("Nouveau formulaire");
    }

    @FXML
    private void handleResetPassword() {
        if (selectedUser == null) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez sélectionner un utilisateur.");
            return;
        }

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Réinitialiser le mot de passe");
        dialog.setHeaderText("Utilisateur : " + selectedUser.getUsername());
        dialog.setContentText("Nouveau mot de passe :");

        dialog.showAndWait().ifPresent(newPwd -> {
            if (newPwd.trim().isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Attention", "Le mot de passe ne peut pas être vide.");
                return;
            }
            if (newPwd.trim().length() < 6) {
                showAlert(Alert.AlertType.WARNING, "Attention",
                        "Le mot de passe doit contenir au moins 6 caractères.");
                return;
            }
            if (dao.changePassword(selectedUser.getUserId(), newPwd.trim())) {
                showAlert(Alert.AlertType.INFORMATION, "Succès",
                        "✓ Mot de passe réinitialisé pour " + selectedUser.getUsername());
                updateStatus("MDP réinitialisé");
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de réinitialiser le mot de passe.");
            }
        });
    }

    // =========================================================
    // Recherche / Rafraîchir
    // =========================================================

    @FXML
    private void handleRecherche(KeyEvent event) {
        String kw = txtRecherche.getText().trim();
        if (kw.isEmpty()) {
            loadUsers();
        } else {
            List<User> results = dao.search(kw);
            usersList.setAll(results);
            tableUsers.setItems(usersList);
            updateTotal();
            updateStatus("🔍 " + results.size() + " résultat(s)");
        }
    }

    @FXML
    private void handleRafraichir() {
        txtRecherche.clear();
        loadUsers();
        clearForm();
        updateStatus("🔄 Données rafraîchies");
    }

    // =========================================================
    // Sélection tableau
    // =========================================================

    private void handleTableClick(MouseEvent event) {
        User user = tableUsers.getSelectionModel().getSelectedItem();
        if (user != null) {
            selectedUser = user;
            fillFormFromUser(user);
            fillPermissionsFromUser(user.getUserId());
            setSelectionDependentButtons(false);
            updateStatus("Sélectionné : " + user.getUsername()
                    + " [" + user.getRole() + " — " + user.getStatut() + "]");
        }
    }

    // =========================================================
    // Helpers formulaire
    // =========================================================

    private User buildUserFromForm() {
        User u = new User();
        u.setUsername(txtUsername.getText().trim());

        String full = txtFullName.getText().trim();
        int space = full.indexOf(' ');
        if (space > 0) {
            u.setPrenom(full.substring(0, space).trim());
            u.setNom(full.substring(space + 1).trim());
        } else {
            u.setPrenom(full);
            u.setNom("");
        }

        u.setEmail(txtEmail.getText().trim());
        u.setRole(cmbRole.getValue() != null ? cmbRole.getValue() : "agent");

        if (cmbStatut != null && cmbStatut.getValue() != null)
            u.setStatut(cmbStatut.getValue());
        else
            u.setStatut("active");

        if (txtTitre != null) u.setTitre(txtTitre.getText().trim());
        return u;
    }

    /** Construit un objet UserPermissions depuis les CheckBoxes du formulaire. */
    private UserPermissions buildPermissionsFromCheckboxes(int userId) {
        UserPermissions p = new UserPermissions();
        p.setUserId      (userId);
        p.setMenuClients (chkClients  != null && chkClients .isSelected());
        p.setMenuUsers   (chkUsers    != null && chkUsers   .isSelected());
        p.setMenuMagasins(chkMagasins != null && chkMagasins.isSelected());
        p.setMenuDemandes(chkDemandes != null && chkDemandes.isSelected());
        p.setMenuVouchers(chkVouchers != null && chkVouchers.isSelected());
        return p;
    }

    private void fillFormFromUser(User user) {
        txtUsername.setText(user.getUsername());
        txtFullName.setText(user.getFullName());
        txtEmail.setText(user.getEmail() != null ? user.getEmail() : "");
        cmbRole.setValue(user.getRole());
        if (cmbStatut != null) cmbStatut.setValue(user.getStatut());
        if (txtTitre != null) txtTitre.setText(user.getTitre() != null ? user.getTitre() : "");
        txtPassword.clear();
        txtPasswordConfirm.clear();
    }

    /** Charge et affiche les permissions d'un utilisateur dans les CheckBoxes. */
    private void fillPermissionsFromUser(int userId) {
        UserPermissions p = permDao.getByUserId(userId);
        if (chkClients  != null) chkClients .setSelected(p.isMenuClients());
        if (chkUsers    != null) chkUsers   .setSelected(p.isMenuUsers());
        if (chkMagasins != null) chkMagasins.setSelected(p.isMenuMagasins());
        if (chkDemandes != null) chkDemandes.setSelected(p.isMenuDemandes());
        if (chkVouchers != null) chkVouchers.setSelected(p.isMenuVouchers());
        setPermHint("🔐 Permissions chargées pour : " + userId);
    }

    private void clearForm() {
        txtUsername.clear();
        txtFullName.clear();
        txtEmail.clear();
        txtPassword.clear();
        txtPasswordConfirm.clear();
        cmbRole.setValue(null);
        if (cmbStatut != null) cmbStatut.setValue(null);
        if (txtTitre != null) txtTitre.clear();

        // Réinitialiser les CheckBoxes
        setAllPermissions(false);
        setPermHint("💡 Sélectionnez un rôle pour pré-remplir");

        selectedUser = null;
        tableUsers.getSelectionModel().clearSelection();
        setSelectionDependentButtons(true);
    }

    // =========================================================
    // Validation
    // =========================================================

    private boolean validateInput(boolean isNew) {
        StringBuilder errors = new StringBuilder();

        if (txtUsername.getText().trim().isEmpty())
            errors.append("- Le nom d'utilisateur est obligatoire\n");

        if (txtFullName.getText().trim().isEmpty())
            errors.append("- Le nom complet est obligatoire\n");

        String email = txtEmail.getText().trim();
        if (!email.isEmpty() && !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"))
            errors.append("- L'email n'est pas valide\n");

        if (cmbRole.getValue() == null)
            errors.append("- Le rôle est obligatoire\n");

        // Vérifier qu'au moins un menu est sélectionné
        boolean anyPerm = (chkClients  != null && chkClients .isSelected())
                || (chkUsers    != null && chkUsers   .isSelected())
                || (chkMagasins != null && chkMagasins.isSelected())
                || (chkDemandes != null && chkDemandes.isSelected())
                || (chkVouchers != null && chkVouchers.isSelected());
        if (!anyPerm)
            errors.append("- Sélectionnez au moins un menu accessible\n");

        if (isNew) {
            String pwd = txtPassword.getText().trim();
            if (pwd.isEmpty())
                errors.append("- Le mot de passe est obligatoire\n");
            else if (pwd.length() < 6)
                errors.append("- Le mot de passe doit contenir au moins 6 caractères\n");
            if (!txtPassword.getText().equals(txtPasswordConfirm.getText()))
                errors.append("- Les mots de passe ne correspondent pas\n");
        } else {
            String pwd = txtPassword.getText().trim();
            if (!pwd.isEmpty()) {
                if (pwd.length() < 6)
                    errors.append("- Le mot de passe doit contenir au moins 6 caractères\n");
                if (!txtPassword.getText().equals(txtPasswordConfirm.getText()))
                    errors.append("- Les mots de passe ne correspondent pas\n");
            }
        }

        if (errors.length() > 0) {
            showAlert(Alert.AlertType.ERROR, "Erreur de validation", errors.toString());
            return false;
        }
        return true;
    }

    // =========================================================
    // Utilitaires UI
    // =========================================================

    private void setSelectionDependentButtons(boolean disabled) {
        btnModifier.setDisable(disabled);
        btnSupprimer.setDisable(disabled);
        btnResetPassword.setDisable(disabled);
    }

    private void updateTotal() {
        if (lblTotal != null)
            lblTotal.setText("Total : " + usersList.size() + " utilisateur(s)");
    }

    private void updateStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
package pkg.vms.controllers;

import pkg.vms.dao.VoucherDAO;
import pkg.vms.models.Demande;
import pkg.vms.models.Voucher;
import pkg.vms.services.EmailService;
import pkg.vms.services.PDFGeneratorService;
import pkg.vms.services.VoucherImageGeneratorService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.Scene;

import java.io.File;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class VoucherController {

    @FXML private TableView<Demande> demandeTable;
    @FXML private TableColumn<Demande, Integer> colRef;
    @FXML private TableColumn<Demande, String> colReference;
    @FXML private TableColumn<Demande, String> colClient;
    @FXML private TableColumn<Demande, String> colEmail;
    @FXML private TableColumn<Demande, Integer> colQte;
    @FXML private TableColumn<Demande, BigDecimal> colValeur;
    @FXML private TableColumn<Demande, BigDecimal> colTotal;
    @FXML private TableColumn<Demande, String> colStatut;
    @FXML private TableColumn<Demande, LocalDateTime> colDate;
    @FXML private TableColumn<Demande, Void> colActions;

    @FXML private Label lblDemandeRef;
    @FXML private Button btnSendEmail;
    @FXML private Button btnExportPDF;
    @FXML private VBox voucherDetailsPane;

    private VoucherDAO voucherDAO;
    private Demande selectedDemande;
    private ObservableList<Demande> demandeList;
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private VoucherImageGeneratorService imageGenerator;

    public VoucherController() {
        this.voucherDAO = new VoucherDAO();
        this.demandeList = FXCollections.observableArrayList();
        this.imageGenerator = new VoucherImageGeneratorService();
    }

    @FXML
    public void initialize() {
        setupTableColumns();
        loadDemandes();
        setupSelectionListener();

        // Désactiver les boutons par défaut
        btnSendEmail.setDisable(true);
        btnExportPDF.setDisable(true);
    }

    private void setupTableColumns() {
        colRef.setCellValueFactory(new PropertyValueFactory<>("refDemande"));

        // Colonne référence avec format VR00XXX-XX
        colReference.setCellValueFactory(cellData -> {
            Demande demande = cellData.getValue();
            String ref = String.format("VR%05d-%02d",
                    demande.getRefDemande(),
                    demande.getNbVoucher());
            return new javafx.beans.property.SimpleStringProperty(ref);
        });

        colClient.setCellValueFactory(new PropertyValueFactory<>("clientName"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("clientEmail"));
        colQte.setCellValueFactory(new PropertyValueFactory<>("nbVoucher"));
        colValeur.setCellValueFactory(new PropertyValueFactory<>("valeurVoucher"));

        // Colonne total calculé
        colTotal.setCellValueFactory(cellData -> {
            Demande demande = cellData.getValue();
            BigDecimal total = demande.getTotal();
            return new javafx.beans.property.SimpleObjectProperty<>(total);
        });

        colStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("dateCreation"));

        // Format date
        colDate.setCellFactory(column -> new TableCell<Demande, LocalDateTime>() {
            @Override
            protected void updateItem(LocalDateTime date, boolean empty) {
                super.updateItem(date, empty);
                if (empty || date == null) {
                    setText(null);
                } else {
                    setText(dateFormatter.format(date));
                }
            }
        });

        // Format montant avec Rs
        colValeur.setCellFactory(column -> new TableCell<Demande, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal amount, boolean empty) {
                super.updateItem(amount, empty);
                if (empty || amount == null) {
                    setText(null);
                } else {
                    setText(String.format("Rs %.0f", amount));
                }
            }
        });

        colTotal.setCellFactory(column -> new TableCell<Demande, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal amount, boolean empty) {
                super.updateItem(amount, empty);
                if (empty || amount == null) {
                    setText(null);
                } else {
                    setText(String.format("Rs %.0f", amount));
                    setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
                }
            }
        });

        // Colonne statut avec couleur
        colStatut.setCellFactory(column -> new TableCell<Demande, String>() {
            @Override
            protected void updateItem(String statut, boolean empty) {
                super.updateItem(statut, empty);
                if (empty || statut == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(statut.toUpperCase());
                    switch (statut.toLowerCase()) {
                        case "initiee":
                            setStyle("-fx-background-color: #FFF4E6; -fx-text-fill: #FF9800;");
                            break;
                        case "approuvee":
                            setStyle("-fx-background-color: #E8F5E9; -fx-text-fill: #4CAF50;");
                            break;
                        case "payee":
                            setStyle("-fx-background-color: #E3F2FD; -fx-text-fill: #2196F3;");
                            break;
                        default:
                            setStyle("");
                    }
                }
            }
        });

        // Colonne actions avec boutons
        colActions.setCellFactory(param -> new TableCell<Demande, Void>() {
            private final Button btnGenerate = new Button("Générer");
            private final Button btnView = new Button("👁");

            {
                btnGenerate.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
                btnView.setStyle("-fx-background-color: transparent; -fx-font-size: 16px;");

                btnGenerate.setOnAction(event -> {
                    Demande demande = getTableView().getItems().get(getIndex());
                    handleGenerateVouchers(demande);
                });

                btnView.setOnAction(event -> {
                    Demande demande = getTableView().getItems().get(getIndex());
                    handleViewVouchers(demande);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Demande demande = getTableView().getItems().get(getIndex());
                    javafx.scene.layout.HBox buttons = new javafx.scene.layout.HBox(5);

                    try {
                        if (voucherDAO.hasGeneratedVouchers(demande.getRefDemande())) {
                            btnGenerate.setDisable(true);
                            btnGenerate.setText("Généré");
                            btnGenerate.setStyle("-fx-background-color: #cccccc; -fx-text-fill: white;");
                        } else {
                            btnGenerate.setDisable(false);
                            btnGenerate.setText("Générer");
                            btnGenerate.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                    buttons.getChildren().addAll(btnGenerate, btnView);
                    setGraphic(buttons);
                }
            }
        });
    }

    private void setupSelectionListener() {
        demandeTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        selectedDemande = newValue;
                        updateDemandeDetails(newValue);
                    }
                }
        );
    }

    private void updateDemandeDetails(Demande demande) {
        String ref = String.format("VR%05d-%02d", demande.getRefDemande(), demande.getNbVoucher());
        lblDemandeRef.setText(ref);

        try {
            if (voucherDAO.hasGeneratedVouchers(demande.getRefDemande())) {
                btnSendEmail.setDisable(false);
                btnExportPDF.setDisable(false);
            } else {
                btnSendEmail.setDisable(true);
                btnExportPDF.setDisable(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadDemandes() {
        try {
            List<Demande> demandes = voucherDAO.getAllDemandeWithClient();
            demandeList.clear();
            demandeList.addAll(demandes);
            demandeTable.setItems(demandeList);
        } catch (SQLException e) {
            showError("Erreur de chargement", "Impossible de charger les demandes: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleGenerateVouchers(Demande demande) {
        try {
            // Vérifier si déjà généré
            if (voucherDAO.hasGeneratedVouchers(demande.getRefDemande())) {
                showInfo("Information", "Les vouchers ont déjà été générés pour cette demande.");
                return;
            }

            // Confirmer
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirmation");
            confirm.setHeaderText("Générer les vouchers");
            confirm.setContentText(String.format("Voulez-vous générer %d voucher(s) de Rs %.2f pour %s?",
                    demande.getNbVoucher(), demande.getValeurVoucher(), demande.getClientName()));

            Optional<ButtonType> result = confirm.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Générer les vouchers dans la base
                List<Voucher> vouchers = voucherDAO.generateVouchersForDemande(demande.getRefDemande());

                if (!vouchers.isEmpty()) {
                    // Créer le répertoire pour les images
                    String voucherDir = "vouchers/VR" + String.format("%05d", demande.getRefDemande());
                    new File(voucherDir).mkdirs();

                    // Générer les images de vouchers
                    try {
                        imageGenerator.generateVouchersImages(vouchers, voucherDir);
                        showSuccess("Succès", String.format("%d voucher(s) générés avec succès!\nImages sauvegardées dans: %s",
                                vouchers.size(), voucherDir));
                    } catch (Exception e) {
                        showWarning("Attention", "Vouchers créés mais erreur lors de la génération des images: " + e.getMessage());
                        e.printStackTrace();
                    }

                    loadDemandes();
                    updateDemandeDetails(demande);
                } else {
                    showError("Erreur", "Aucun voucher n'a été généré.");
                }
            }
        } catch (SQLException e) {
            showError("Erreur", "Erreur lors de la génération: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleViewVouchers(Demande demande) {
        try {
            List<Voucher> vouchers = voucherDAO.getVouchersByDemande(demande.getRefDemande());

            if (vouchers.isEmpty()) {
                showInfo("Information", "Aucun voucher trouvé pour cette demande.\nVeuillez d'abord les générer.");
                return;
            }

            showVouchersDialog(demande, vouchers);
        } catch (SQLException e) {
            showError("Erreur", "Erreur lors de la récupération des vouchers: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showVouchersDialog(Demande demande, List<Voucher> vouchers) {
        Stage dialog = new Stage();
        dialog.setTitle("Vouchers - " + demande.getClientName());

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        Label title = new Label("Liste des vouchers générés");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Table pour afficher les vouchers
        TableView<Voucher> voucherTable = new TableView<>();
        voucherTable.setPrefHeight(300);

        TableColumn<Voucher, String> colCode = new TableColumn<>("Code");
        colCode.setCellValueFactory(new PropertyValueFactory<>("noVoucher"));
        colCode.setPrefWidth(150);

        TableColumn<Voucher, BigDecimal> colAmount = new TableColumn<>("Montant");
        colAmount.setCellValueFactory(new PropertyValueFactory<>("montant"));
        colAmount.setPrefWidth(100);

        TableColumn<Voucher, String> colStatus = new TableColumn<>("Statut");
        colStatus.setCellValueFactory(new PropertyValueFactory<>("statusVouch"));
        colStatus.setPrefWidth(100);

        TableColumn<Voucher, Void> colView = new TableColumn<>("Action");
        colView.setPrefWidth(100);
        colView.setCellFactory(param -> new TableCell<Voucher, Void>() {
            private final Button btnView = new Button("Voir Image");
            {
                btnView.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
                btnView.setOnAction(event -> {
                    Voucher v = getTableView().getItems().get(getIndex());
                    showVoucherImageDialog(v, demande);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnView);
            }
        });

        voucherTable.getColumns().addAll(colCode, colAmount, colStatus, colView);
        voucherTable.setItems(FXCollections.observableArrayList(vouchers));

        // Boutons
        javafx.scene.layout.HBox buttons = new javafx.scene.layout.HBox(10);

        Button btnGenerateAll = new Button("Régénérer Toutes les Images");
        btnGenerateAll.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white;");
        btnGenerateAll.setOnAction(e -> {
            try {
                String voucherDir = "vouchers/VR" + String.format("%05d", demande.getRefDemande());
                imageGenerator.generateVouchersImages(vouchers, voucherDir);
                showSuccess("Succès", "Toutes les images ont été régénérées!");
            } catch (Exception ex) {
                showError("Erreur", "Erreur: " + ex.getMessage());
            }
        });

        Button closeBtn = new Button("Fermer");
        closeBtn.setOnAction(e -> dialog.close());

        buttons.getChildren().addAll(btnGenerateAll, closeBtn);

        content.getChildren().addAll(title, voucherTable, buttons);

        Scene scene = new Scene(content, 600, 500);
        dialog.setScene(scene);
        dialog.show();
    }

    private void showVoucherImageDialog(Voucher voucher, Demande demande) {
        try {
            // Sanitize le no_voucher pour le nom de fichier
            String sanitizedVoucherNo = voucher.getNoVoucher()
                    .replace("/", "-")
                    .replace("\\", "-")
                    .replace(":", "-");

            String imagePath = "vouchers/VR" + String.format("%05d", demande.getRefDemande()) +
                    "/Voucher_" + sanitizedVoucherNo + ".png";
            File imageFile = new File(imagePath);

            if (!imageFile.exists()) {
                // Générer l'image si elle n'existe pas
                String voucherDir = "vouchers/VR" + String.format("%05d", demande.getRefDemande());
                imageGenerator.generateAndSaveVoucher(voucher, voucherDir);
            }

            Stage imageDialog = new Stage();
            imageDialog.setTitle("Voucher - " + voucher.getNoVoucher());

            javafx.scene.image.Image image = new javafx.scene.image.Image(imageFile.toURI().toString());
            javafx.scene.image.ImageView imageView = new javafx.scene.image.ImageView(image);
            imageView.setPreserveRatio(true);
            imageView.setFitWidth(800);

            VBox content = new VBox(10);
            content.setPadding(new Insets(10));
            content.setAlignment(javafx.geometry.Pos.CENTER);

            javafx.scene.layout.HBox buttons = new javafx.scene.layout.HBox(10);
            buttons.setAlignment(javafx.geometry.Pos.CENTER);

            Button btnSave = new Button("Enregistrer Sous...");
            btnSave.setOnAction(e -> {
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Enregistrer le voucher");
                fileChooser.setInitialFileName("Voucher_" + sanitizedVoucherNo + ".png");
                fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG Images", "*.png"));

                File file = fileChooser.showSaveDialog(imageDialog);
                if (file != null) {
                    try {
                        java.nio.file.Files.copy(imageFile.toPath(), file.toPath(),
                                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        showSuccess("Succès", "Image enregistrée!");
                    } catch (Exception ex) {
                        showError("Erreur", "Erreur lors de la sauvegarde: " + ex.getMessage());
                    }
                }
            });

            Button btnClose = new Button("Fermer");
            btnClose.setOnAction(e -> imageDialog.close());

            buttons.getChildren().addAll(btnSave, btnClose);
            content.getChildren().addAll(imageView, buttons);

            ScrollPane scrollPane = new ScrollPane(content);
            scrollPane.setFitToWidth(true);

            Scene scene = new Scene(scrollPane, 850, 500);
            imageDialog.setScene(scene);
            imageDialog.show();

        } catch (Exception e) {
            showError("Erreur", "Impossible d'afficher l'image: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSendEmail() {
        if (selectedDemande == null) {
            showWarning("Attention", "Veuillez sélectionner une demande.");
            return;
        }

        showEmailDialog(selectedDemande);
    }

    private void showEmailDialog(Demande demande) {
        Stage dialog = new Stage();
        dialog.setTitle("Envoyer les vouchers par email");

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        Label lblTitle = new Label("Envoyer les vouchers à:");
        lblTitle.setStyle("-fx-font-weight: bold;");

        TextField txtEmail = new TextField(demande.getClientEmail());
        txtEmail.setPromptText("Adresse email");

        TextArea txtMessage = new TextArea();
        txtMessage.setPromptText("Message personnalisé (optionnel)");
        txtMessage.setPrefRowCount(5);

        Button btnSend = new Button("Envoyer");
        btnSend.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");

        Button btnCancel = new Button("Annuler");

        javafx.scene.layout.HBox buttons = new javafx.scene.layout.HBox(10);
        buttons.getChildren().addAll(btnSend, btnCancel);

        btnSend.setOnAction(e -> {
            String email = txtEmail.getText().trim();
            String message = txtMessage.getText().trim();

            if (email.isEmpty()) {
                showWarning("Attention", "Veuillez entrer une adresse email.");
                return;
            }

            try {
                List<Voucher> vouchers = voucherDAO.getVouchersByDemande(demande.getRefDemande());

                // Utiliser EmailService pour envoyer
                EmailService emailService = new EmailService();
                boolean sent = emailService.sendVouchersEmail(email, demande, vouchers, message);

                if (sent) {
                    showSuccess("Succès", "Email envoyé avec succès!");
                    dialog.close();
                } else {
                    showError("Erreur", "Échec de l'envoi de l'email.");
                }
            } catch (Exception ex) {
                showError("Erreur", "Erreur lors de l'envoi: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        btnCancel.setOnAction(e -> dialog.close());

        content.getChildren().addAll(lblTitle, txtEmail, txtMessage, buttons);

        Scene scene = new Scene(content, 400, 300);
        dialog.setScene(scene);
        dialog.show();
    }

    @FXML
    private void handleExportPDF() {
        if (selectedDemande == null) {
            showWarning("Attention", "Veuillez sélectionner une demande.");
            return;
        }

        try {
            List<Voucher> vouchers = voucherDAO.getVouchersByDemande(selectedDemande.getRefDemande());

            if (vouchers.isEmpty()) {
                showInfo("Information", "Aucun voucher à exporter.");
                return;
            }

            // NOUVEAU: Vérifier et générer les images si nécessaire
            String voucherDir = "vouchers/VR" + String.format("%05d", selectedDemande.getRefDemande());
            File dir = new File(voucherDir);

            // Vérifier combien d'images existent déjà
            int existingImages = 0;
            if (dir.exists()) {
                File[] files = dir.listFiles((d, name) -> name.endsWith(".png"));
                existingImages = files != null ? files.length : 0;
            }

            // Si images manquantes, proposer de les générer
            if (existingImages < vouchers.size()) {
                Alert confirmGenerate = new Alert(Alert.AlertType.CONFIRMATION);
                confirmGenerate.setTitle("Images manquantes");
                confirmGenerate.setHeaderText("Génération des images requise");
                confirmGenerate.setContentText(
                        String.format("Il y a %d voucher(s) mais seulement %d image(s) trouvée(s).\n\n" +
                                        "Voulez-vous générer les images manquantes avant d'exporter le PDF?\n" +
                                        "(Cela peut prendre quelques secondes)",
                                vouchers.size(), existingImages)
                );

                ButtonType btnGenerate = new ButtonType("Générer et Exporter");
                ButtonType btnSkip = new ButtonType("Exporter Quand Même");
                ButtonType btnCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);

                confirmGenerate.getButtonTypes().setAll(btnGenerate, btnSkip, btnCancel);

                Optional<ButtonType> result = confirmGenerate.showAndWait();

                if (result.isPresent() && result.get() == btnCancel) {
                    return;
                }

                if (result.isPresent() && result.get() == btnGenerate) {
                    // Générer toutes les images
                    try {
                        showInfo("Génération en cours",
                                "Génération de " + vouchers.size() + " image(s)...\n" +
                                        "Veuillez patienter.");

                        imageGenerator.generateVouchersImages(vouchers, voucherDir);

                        showSuccess("Succès",
                                vouchers.size() + " image(s) générée(s) avec succès!");
                    } catch (Exception e) {
                        showError("Erreur",
                                "Erreur lors de la génération des images: " + e.getMessage());
                        e.printStackTrace();
                        return;
                    }
                }
            }

            // Dialog pour choisir le type de PDF
            Alert choiceDialog = new Alert(Alert.AlertType.CONFIRMATION);
            choiceDialog.setTitle("Type de PDF");
            choiceDialog.setHeaderText("Choisissez le format du PDF");
            choiceDialog.setContentText("Quel type de PDF voulez-vous générer?");

            ButtonType btnFullImages = new ButtonType("Vouchers avec Images (1 par page)");
            ButtonType btnCompact = new ButtonType("PDF Compact (2 par page)");
            ButtonType btnCancel = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);

            choiceDialog.getButtonTypes().setAll(btnFullImages, btnCompact, btnCancel);

            Optional<ButtonType> result = choiceDialog.showAndWait();

            if (result.isPresent() && result.get() != btnCancel) {
                // FileChooser pour sauvegarder
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Enregistrer le PDF");
                fileChooser.setInitialFileName(String.format("Vouchers_VR%05d.pdf", selectedDemande.getRefDemande()));
                fileChooser.getExtensionFilters().add(
                        new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
                );

                File file = fileChooser.showSaveDialog(btnExportPDF.getScene().getWindow());

                if (file != null) {
                    // Générer le PDF selon le choix
                    PDFGeneratorService pdfService = new PDFGeneratorService();

                    if (result.get() == btnFullImages) {
                        // PDF avec images complètes (1 voucher par page)
                        pdfService.generateVouchersPDF(selectedDemande, vouchers, file.getAbsolutePath());
                        showSuccess("Succès", "PDF avec images généré avec succès!\n" + vouchers.size() + " voucher(s) exportés.");
                    } else {
                        // PDF compact (2 vouchers par page)
                        pdfService.generateCompactVouchersPDF(selectedDemande, vouchers, file.getAbsolutePath());
                        showSuccess("Succès", "PDF compact généré avec succès!\n" + vouchers.size() + " voucher(s) exportés.");
                    }
                }
            }
        } catch (Exception e) {
            showError("Erreur", "Erreur lors de l'export: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRefresh() {
        loadDemandes();
    }

    // Méthodes utilitaires pour les alertes
    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccess(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

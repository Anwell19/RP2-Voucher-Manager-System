package pkg.vms.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import pkg.vms.dao.MagasinDAO;
import pkg.vms.models.Magasin;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class MagasinController {

    @FXML private TextField txtNom;
    @FXML private TextField txtAttribute1;
    @FXML private TextField txtRecherche;

    @FXML private TableView<Magasin> tableMagasins;
    @FXML private TableColumn<Magasin, Integer> colId;
    @FXML private TableColumn<Magasin, String> colNom;
    @FXML private TableColumn<Magasin, String> colAttribute1;
    @FXML private TableColumn<Magasin, String> colCreatedAt;

    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;

    @FXML private Label lblStatus;
    @FXML private Label lblTotal;

    private MagasinDAO magasinDAO;
    private ObservableList<Magasin> magasinsList;
    private Magasin selectedMagasin;
    private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    @FXML
    public void initialize() {
        magasinDAO = new MagasinDAO();
        magasinsList = FXCollections.observableArrayList();

        // Initialiser les colonnes
        initializeTableColumns();

        // Charger les données
        loadMagasins();

        // Configurer la sélection
        tableMagasins.setOnMouseClicked(this::handleTableClick);

        // État initial des boutons
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);

        updateStatus("Prêt");
    }

    private void initializeTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("magasinId"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colAttribute1.setCellValueFactory(new PropertyValueFactory<>("attribute1"));

        // Formatter la date de création
        colCreatedAt.setCellValueFactory(cellData -> {
            LocalDateTime date = cellData.getValue().getCreatedAt();
            return new javafx.beans.property.SimpleStringProperty(
                    date != null ? date.format(dateTimeFormatter) : ""
            );
        });

        // Tri par nom par défaut
        tableMagasins.getSortOrder().add(colNom);
    }

    private void loadMagasins() {
        List<Magasin> magasins = magasinDAO.readAll();
        magasinsList.clear();
        magasinsList.addAll(magasins);
        tableMagasins.setItems(magasinsList);
        updateTotal();
        updateStatus("✓ " + magasins.size() + " magasin(s) chargé(s)");
    }

    @FXML
    private void handleAjouter() {
        if (validateInput()) {
            Magasin magasin = new Magasin();
            fillMagasinFromForm(magasin);

            if (magasinDAO.create(magasin)) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "✓ Magasin ajouté avec succès.");
                loadMagasins();
                clearForm();
                updateStatus("Magasin ajouté : " + magasin.getNom());
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'ajouter le magasin.");
            }
        }
    }

    @FXML
    private void handleModifier() {
        if (selectedMagasin == null) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez sélectionner un magasin à modifier.");
            return;
        }

        if (validateInput()) {
            fillMagasinFromForm(selectedMagasin);

            if (magasinDAO.update(selectedMagasin)) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "✓ Magasin modifié avec succès.");
                loadMagasins();
                clearForm();
                updateStatus("Magasin modifié : " + selectedMagasin.getNom());
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de modifier le magasin.");
            }
        }
    }

    @FXML
    private void handleSupprimer() {
        if (selectedMagasin == null) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez sélectionner un magasin à supprimer.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmation");
        confirmation.setHeaderText("Supprimer le magasin");
        confirmation.setContentText("Êtes-vous sûr de vouloir supprimer le magasin :\n" +
                selectedMagasin.getNom() + " ?\n\n" +
                "Cette action est irréversible.");

        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (magasinDAO.delete(selectedMagasin.getMagasinId())) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "✓ Magasin supprimé avec succès.");
                loadMagasins();
                clearForm();
                updateStatus("Magasin supprimé");
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur",
                        "Impossible de supprimer le magasin.\n" +
                                "Il est peut-être lié à des vouchers ou des rédemptions.");
            }
        }
    }

    @FXML
    private void handleNouveau() {
        clearForm();
        updateStatus("Nouveau formulaire");
    }

    @FXML
    private void handleRecherche(KeyEvent event) {
        String keyword = txtRecherche.getText().trim();

        if (keyword.isEmpty()) {
            loadMagasins();
        } else {
            List<Magasin> results = magasinDAO.search(keyword);
            magasinsList.clear();
            magasinsList.addAll(results);
            tableMagasins.setItems(magasinsList);
            updateTotal();
            updateStatus("🔍 " + results.size() + " résultat(s)");
        }
    }

    @FXML
    private void handleRafraichir() {
        txtRecherche.clear();
        loadMagasins();
        clearForm();
        updateStatus("🔄 Données rafraîchies");
    }

    private void handleTableClick(MouseEvent event) {
        Magasin magasin = tableMagasins.getSelectionModel().getSelectedItem();
        if (magasin != null) {
            selectedMagasin = magasin;
            fillFormFromMagasin(magasin);
            btnModifier.setDisable(false);
            btnSupprimer.setDisable(false);
            updateStatus("Magasin sélectionné : " + magasin.getNom());
        }
    }

    private void fillMagasinFromForm(Magasin magasin) {
        magasin.setNom(txtNom.getText().trim());
        magasin.setAttribute1(txtAttribute1.getText().trim());
    }

    private void fillFormFromMagasin(Magasin magasin) {
        txtNom.setText(magasin.getNom());
        txtAttribute1.setText(magasin.getAttribute1());
    }

    private void clearForm() {
        txtNom.clear();
        txtAttribute1.clear();

        selectedMagasin = null;
        tableMagasins.getSelectionModel().clearSelection();
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
    }

    private boolean validateInput() {
        StringBuilder errors = new StringBuilder();

        if (txtNom.getText().trim().isEmpty()) {
            errors.append("- Le nom du magasin est obligatoire\n");
        }

        if (errors.length() > 0) {
            showAlert(Alert.AlertType.ERROR, "Erreur de validation", errors.toString());
            return false;
        }

        return true;
    }

    private void updateTotal() {
        lblTotal.setText("Total : " + magasinsList.size() + " magasin(s)");
    }

    private void updateStatus(String message) {
        lblStatus.setText(message);
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
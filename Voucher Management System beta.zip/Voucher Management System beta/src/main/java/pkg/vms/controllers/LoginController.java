package pkg.vms.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import pkg.vms.dao.LoginDAO;
import pkg.vms.models.User;

import java.io.IOException;

/**
 * Contrôleur de l'écran de connexion (Login.fxml).
 *
 * Délègue l'authentification à LoginDAO qui interroge vms.users.
 * Après succès, ouvre le Dashboard et y injecte l'utilisateur connecté.
 */
public class LoginController {

    @FXML private TextField     txtUsername;
    @FXML private PasswordField txtPassword;
    @FXML private Button        btnLogin;
    @FXML private Label         lblError;
    @FXML private CheckBox      chkRememberMe;
    @FXML private Hyperlink     linkForgotPassword;

    private LoginDAO loginDAO;

    public LoginController() {
        loginDAO = new LoginDAO();
    }

    @FXML
    public void initialize() {
        hideError();

        // Touche Entrée dans les champs → déclenche le login
        if (txtPassword != null) txtPassword.setOnAction(e -> handleLogin());
        if (txtUsername != null) txtUsername.setOnAction(e -> handleLogin());
    }

    // ---------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------

    @FXML
    private void handleLogin() {
        hideError();

        String username = txtUsername.getText().trim();
        String password = txtPassword.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Veuillez remplir tous les champs.");
            return;
        }

        try {
            User user = loginDAO.authenticate(username, password);

            if (user != null) {
                System.out.println("[LoginController] Connexion réussie : "
                        + user.getFullName() + " (" + user.getRole() + ")");
                openDashboard(user);
            } else {
                showError("Nom d'utilisateur ou mot de passe incorrect.");
                txtPassword.clear();
            }

        } catch (Exception e) {
            showError("Erreur de connexion : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleForgotPassword() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Mot de passe oublié");
        alert.setHeaderText("Réinitialisation du mot de passe");
        alert.setContentText("Veuillez contacter votre administrateur pour réinitialiser votre mot de passe.");
        alert.showAndWait();
    }

    @FXML
    private void handleCancel() {
        System.exit(0);
    }

    // ---------------------------------------------------------------
    // Navigation vers le Dashboard
    // ---------------------------------------------------------------

    private void openDashboard(User user) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/pkg/vms/fxml/dashboard.fxml"));
            Parent root = loader.load();

            // Injecter l'utilisateur APRÈS le chargement du FXML
            DashboardController dc = loader.getController();
            dc.setCurrentUser(user);

            Stage stage = (Stage) btnLogin.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("VMS — " + user.getFullName() + " [" + user.getRole() + "]");
            stage.setMaximized(true);
            stage.show();

        } catch (IOException e) {
            showError("Erreur lors de l'ouverture du tableau de bord.");
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------------
    // Helpers UI
    // ---------------------------------------------------------------

    private void showError(String message) {
        if (lblError != null) {
            lblError.setText(message);
            lblError.setVisible(true);
            lblError.setManaged(true);
        }
    }

    private void hideError() {
        if (lblError != null) {
            lblError.setVisible(false);
            lblError.setManaged(false);
        }
    }
}
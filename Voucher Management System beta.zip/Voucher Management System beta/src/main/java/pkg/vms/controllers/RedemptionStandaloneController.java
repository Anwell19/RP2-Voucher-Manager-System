package pkg.vms.controllers;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import pkg.vms.dao.MagasinDAO;
import pkg.vms.dao.RedemptionDAO;
import pkg.vms.models.Magasin;
import pkg.vms.models.Redemption;
import pkg.vms.models.Voucher;

import java.math.BigDecimal;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Controller pour la vue Rédemption STANDALONE.
 *
 * Cette vue est totalement séparée du VMS principal — elle peut être lancée
 * depuis un bouton "Terminal Rédemption" dans le dashboard, ou directement
 * depuis HelloApplication en mode kiosque magasin.
 *
 * Flux :
 *   1. L'agent scanne / saisit le code QR
 *   2. handleValider() appelle RedemptionDAO.validateVoucher() → requête PostgreSQL
 *   3. Le résultat (VALID / NOT_FOUND / EXPIRED / ALREADY_REDEEMED) s'affiche
 *   4. Si VALID : bouton "Confirmer" visible → handleConfirmerRedemption() → INSERT DB
 *   5. Historique rechargé après chaque rédemption
 *
 * Corrections / améliorations :
 *   - Validation du statut "issued" (la DB stocke "issued", pas "active")
 *   - Thread séparé pour les appels DB (pas de gel UI)
 *   - Indicateur de chargement pendant la vérification
 *   - Indicateur connexion DB dans la status bar
 *   - Filtrage de l'historique par texte + statut
 *   - Compteurs session mis à jour en temps réel
 *   - Gestion magasin non sélectionné
 */
public class RedemptionStandaloneController implements Initializable {

    // ─── Zone scan ────────────────────────────────────────────────────
    @FXML private TextField     txtCodeVoucher;
    @FXML private ComboBox<Magasin> cmbMagasin;
    @FXML private Button        btnValider;
    @FXML private Button        btnReset;
    @FXML private HBox          loadingBox;

    // ─── Panneau résultat ─────────────────────────────────────────────
    @FXML private VBox          panneauResultat;
    @FXML private HBox          resultHeader;
    @FXML private Label         lblResultatIcon;
    @FXML private Label         lblResultatTitre;
    @FXML private Label         lblResultatMessage;
    @FXML private Label         lblCodeVoucher;
    @FXML private Label         lblClientNom;
    @FXML private Label         lblMontant;
    @FXML private Label         lblExpiration;
    @FXML private Label         lblRefDemande;
    @FXML private Button        btnConfirmerRedemption;

    // ─── Header compteurs ─────────────────────────────────────────────
    @FXML private Label         lblTotalAujourdhui;
    @FXML private Label         lblMontantJour;
    @FXML private Label         lblAgentNom;
    @FXML private Label         lblMagasinNom;

    // ─── Historique ───────────────────────────────────────────────────
    @FXML private TableView<Redemption>     tableHistorique;
    @FXML private TableColumn<Redemption, String>  colCode;
    @FXML private TableColumn<Redemption, String>  colClient;
    @FXML private TableColumn<Redemption, String>  colMontantCol;
    @FXML private TableColumn<Redemption, String>  colMagasinCol;
    @FXML private TableColumn<Redemption, String>  colDate;
    @FXML private TableColumn<Redemption, String>  colStatutCol;
    @FXML private TableColumn<Redemption, String>  colAgent;
    @FXML private TextField     txtRecherche;
    @FXML private ToggleButton  btnFiltreAll;
    @FXML private ToggleButton  btnFiltreSuccess;
    @FXML private ToggleButton  btnFiltreEchec;

    // ─── Stats résumé ─────────────────────────────────────────────────
    @FXML private Label         lblStatSucces;
    @FXML private Label         lblStatEchecs;
    @FXML private Label         lblStatMontantTotal;

    // ─── Status bar ───────────────────────────────────────────────────
    @FXML private Label         lblStatus;
    @FXML private Label         lblDbStatus;

    private static final DateTimeFormatter DT_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final DateTimeFormatter D_FMT   = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final int AGENT_ID_DEFAULT = 7; // agent par défaut si non authentifié

    private final RedemptionDAO redemptionDAO = new RedemptionDAO();
    private final MagasinDAO    magasinDAO    = new MagasinDAO();

    private ObservableList<Redemption> allRedemptions = FXCollections.observableArrayList();
    private FilteredList<Redemption>   filteredList;

    // Mémorise le voucher validé pour la confirmation
    private Voucher voucherEnCours = null;

    // Compteurs de session
    private int sessionSucces = 0;
    private int sessionEchecs = 0;
    private BigDecimal sessionMontant = BigDecimal.ZERO;

    // ─────────────────────────────────────────────────────────────────
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        configurerTableau();
        configurerFiltres();
        chargerMagasins();
        chargerHistorique();
        verifierConnexionDB();
        setStatus("Prêt — Scannez ou saisissez un code de bon cadeau.");
        if (txtCodeVoucher != null) txtCodeVoucher.requestFocus();
    }

    // ─── Configuration tableau ────────────────────────────────────────

    private void configurerTableau() {
        if (colCode != null)       colCode.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNoVoucher()));
        if (colClient != null)     colClient.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getClientNom()));
        if (colMontantCol != null) colMontantCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().getMontantVoucher() != null ? "Rs " + c.getValue().getMontantVoucher() : "—"
        ));
        if (colMagasinCol != null) colMagasinCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNomMagasin()));
        if (colDate != null)       colDate.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().getDateRedemption() != null ? c.getValue().getDateRedemption().format(DT_FMT) : "—"
        ));
        if (colStatutCol != null)  colStatutCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getStatut()));
        if (colAgent != null)      colAgent.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNomUtilisateur()));

        // Rendu statut avec couleur
        if (colStatutCol != null) {
            colStatutCol.setCellFactory(col -> new TableCell<>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                        setStyle("");
                    } else {
                        setText(item);
                        if ("success".equalsIgnoreCase(item)) {
                            setStyle("-fx-text-fill: #059669; -fx-font-weight: bold;");
                        } else {
                            setStyle("-fx-text-fill: #DC2626; -fx-font-weight: bold;");
                        }
                    }
                }
            });
        }

        filteredList = new FilteredList<>(allRedemptions, r -> true);
        if (tableHistorique != null) tableHistorique.setItems(filteredList);
    }

    private void configurerFiltres() {
        if (txtRecherche != null) {
            txtRecherche.textProperty().addListener((obs, o, n) -> appliquerFiltre());
        }
    }

    private void appliquerFiltre() {
        String recherche = txtRecherche != null ? txtRecherche.getText().toLowerCase().trim() : "";
        boolean filtreSucces = btnFiltreSuccess != null && btnFiltreSuccess.isSelected();
        boolean filtreEchec  = btnFiltreEchec  != null && btnFiltreEchec.isSelected();

        filteredList.setPredicate(r -> {
            // Filtre texte
            boolean matchTexte = recherche.isEmpty()
                || (r.getNoVoucher()    != null && r.getNoVoucher().toLowerCase().contains(recherche))
                || (r.getClientNom()    != null && r.getClientNom().toLowerCase().contains(recherche))
                || (r.getNomMagasin()   != null && r.getNomMagasin().toLowerCase().contains(recherche));
            // Filtre statut
            boolean matchStatut = true;
            if (filtreSucces) matchStatut = "success".equalsIgnoreCase(r.getStatut());
            if (filtreEchec)  matchStatut = !"success".equalsIgnoreCase(r.getStatut());
            return matchTexte && matchStatut;
        });
    }

    // ─── Chargement données ───────────────────────────────────────────

    private void chargerMagasins() {
        Thread t = new Thread(() -> {
            List<Magasin> magasins = magasinDAO.readAll();
            Platform.runLater(() -> {
                if (cmbMagasin != null) {
                    cmbMagasin.getItems().clear();
                    cmbMagasin.getItems().addAll(magasins);
                    if (!magasins.isEmpty()) cmbMagasin.setValue(magasins.get(0));
                    cmbMagasin.setConverter(new javafx.util.StringConverter<>() {
                        @Override public String toString(Magasin m)   { return m != null ? m.getNom() : ""; }
                        @Override public Magasin fromString(String s) { return null; }
                    });
                }
            });
        });
        t.setDaemon(true);
        t.start();
    }

    private void chargerHistorique() {
        Thread t = new Thread(() -> {
            List<Redemption> liste = redemptionDAO.getHistorique();
            int todayCount = redemptionDAO.countToday();
            Platform.runLater(() -> {
                allRedemptions.setAll(liste);
                mettreAJourCompteurs(todayCount);
            });
        });
        t.setDaemon(true);
        t.start();
    }

    private void verifierConnexionDB() {
        Thread t = new Thread(() -> {
            try {
                pkg.vms.dao.DatabaseConnection.getConnection();
                Platform.runLater(() -> {
                    if (lblDbStatus != null)
                        lblDbStatus.setText("⚡ Base de données connectée");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    if (lblDbStatus != null) {
                        lblDbStatus.setText("⚠️ Connexion DB indisponible");
                        lblDbStatus.setStyle("-fx-text-fill: #EF4444;");
                    }
                });
            }
        });
        t.setDaemon(true);
        t.start();
    }

    // ─── Validation voucher ───────────────────────────────────────────

    @FXML
    public void handleValider(ActionEvent event) {
        String code = txtCodeVoucher != null ? txtCodeVoucher.getText().trim() : "";
        if (code.isEmpty()) {
            setStatus("⚠️  Veuillez saisir ou scanner un code de bon cadeau.");
            return;
        }

        // Vérification magasin
        if (cmbMagasin != null && cmbMagasin.getValue() == null) {
            setStatus("⚠️  Veuillez sélectionner un magasin.");
            return;
        }

        // UI : désactiver bouton + afficher indicateur
        setBoutonValiderActif(false);
        afficherChargement(true);
        cacherResultat();
        voucherEnCours = null;
        setStatus("🔄  Vérification du code « " + code + " » en cours...");

        Thread t = new Thread(() -> {
            RedemptionDAO.ValidationStatus status = redemptionDAO.validateVoucher(code);
            Platform.runLater(() -> {
                afficherChargement(false);
                setBoutonValiderActif(true);
                traiterResultatValidation(status);
            });
        });
        t.setDaemon(true);
        t.start();
    }

    private void traiterResultatValidation(RedemptionDAO.ValidationStatus status) {
        afficherPanneauResultat(true);

        switch (status.result) {

            case VALID:
                voucherEnCours = status.voucher;
                Voucher v = status.voucher;

                // Header vert
                setStyleResultatHeader(true);
                if (lblResultatIcon  != null) lblResultatIcon.setText("✅");
                if (lblResultatTitre != null) lblResultatTitre.setText("BON VALIDE");
                if (lblResultatMessage != null) lblResultatMessage.setText("Ce bon peut être utilisé.");

                // Détails
                if (lblCodeVoucher != null) lblCodeVoucher.setText(v.getNoVoucher());
                if (lblClientNom   != null) lblClientNom.setText(v.getClientName() != null ? v.getClientName() : "—");
                if (lblMontant     != null) lblMontant.setText("Rs " + v.getMontant());
                if (lblExpiration  != null) lblExpiration.setText(
                        v.getExpireDate() != null ? v.getExpireDate().format(D_FMT) : "—"
                );
                if (lblRefDemande  != null) lblRefDemande.setText("DMD-" + v.getRefDemande());

                // Bouton confirmer visible
                if (btnConfirmerRedemption != null) {
                    btnConfirmerRedemption.setVisible(true);
                    btnConfirmerRedemption.setManaged(true);
                }

                setStatus("✅  Bon valide — montant : Rs " + v.getMontant() + " · Confirmez pour valider la rédemption.");
                break;

            case NOT_FOUND:
                afficherErreurResultat("❌", "BON INTROUVABLE",
                        "Aucun voucher ne correspond à ce code dans la base de données.\n" +
                        "Vérifiez le code ou contactez le support.");
                setStatus("❌  Code introuvable : « " + (txtCodeVoucher != null ? txtCodeVoucher.getText() : "") + " »");
                sessionEchecs++;
                break;

            case ALREADY_REDEEMED:
                afficherErreurResultat("🚫", "BON DÉJÀ UTILISÉ",
                        "Ce bon a déjà été rédimé et ne peut plus être utilisé.\n" +
                        "Chaque bon est à usage unique.");
                setStatus("🚫  Bon déjà utilisé.");
                sessionEchecs++;
                break;

            case EXPIRED:
                afficherErreurResultat("⏰", "BON EXPIRÉ",
                        "Ce bon a dépassé sa date d'expiration et n'est plus valide.\n" +
                        (status.message != null ? status.message : ""));
                setStatus("⏰  Bon expiré.");
                sessionEchecs++;
                break;

            case INVALID_STATUS:
                afficherErreurResultat("⚠️", "STATUT INVALIDE",
                        "Ce bon n'est pas dans un état permettant son utilisation.\n" +
                        "Statut : " + (status.message != null ? status.message : "inconnu"));
                setStatus("⚠️  Statut invalide.");
                sessionEchecs++;
                break;

            case ERROR:
            default:
                afficherErreurResultat("🛑", "ERREUR TECHNIQUE",
                        "Une erreur s'est produite lors de la vérification.\n" +
                        (status.message != null ? status.message : "Vérifiez la connexion à la base de données."));
                setStatus("🛑  Erreur technique. Vérifiez la connexion DB.");
                break;
        }

        mettreAJourStatsSessions();
    }

    // ─── Confirmation rédemption ──────────────────────────────────────

    @FXML
    public void handleConfirmerRedemption(ActionEvent event) {
        if (voucherEnCours == null) return;

        Magasin magasin = cmbMagasin != null ? cmbMagasin.getValue() : null;
        if (magasin == null) {
            setStatus("⚠️  Veuillez sélectionner un magasin avant de confirmer.");
            return;
        }

        // Confirmation utilisateur
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmer la Rédemption");
        confirm.setHeaderText("Confirmer l'utilisation du bon ?");
        confirm.setContentText(
            "Code   : " + voucherEnCours.getNoVoucher() + "\n" +
            "Client : " + (voucherEnCours.getClientName() != null ? voucherEnCours.getClientName() : "—") + "\n" +
            "Montant : Rs " + voucherEnCours.getMontant() + "\n\n" +
            "⚠️  Cette action est irréversible."
        );

        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                executerRedemption(voucherEnCours, magasin.getMagasinId(), AGENT_ID_DEFAULT);
            }
        });
    }

    private void executerRedemption(Voucher voucher, int magasinId, int agentId) {
        btnConfirmerRedemption.setDisable(true);
        setStatus("⏳  Enregistrement de la rédemption...");

        Thread t = new Thread(() -> {
            boolean ok = redemptionDAO.enregistrerRedemption(
                    voucher.getRefVoucher(), magasinId, agentId
            );
            Platform.runLater(() -> {
                if (ok) {
                    sessionSucces++;
                    if (voucher.getMontant() != null)
                        sessionMontant = sessionMontant.add(voucher.getMontant());

                    setStatus("✅  Rédemption enregistrée avec succès — Bon : " + voucher.getNoVoucher());
                    mettreAJourStatsSessions();
                    voucherEnCours = null;

                    // Réinitialiser la zone de scan
                    if (txtCodeVoucher != null) {
                        txtCodeVoucher.clear();
                        txtCodeVoucher.requestFocus();
                    }
                    cacherResultat();

                    // Recharger l'historique
                    chargerHistorique();

                } else {
                    setStatus("❌  Échec de l'enregistrement. Réessayez.");
                    if (btnConfirmerRedemption != null) btnConfirmerRedemption.setDisable(false);
                }
            });
        });
        t.setDaemon(true);
        t.start();
    }

    // ─── Handlers divers ─────────────────────────────────────────────

    @FXML
    public void handleReset(ActionEvent event) {
        if (txtCodeVoucher != null) txtCodeVoucher.clear();
        cacherResultat();
        voucherEnCours = null;
        setStatus("Formulaire réinitialisé — Prêt pour le prochain scan.");
        if (txtCodeVoucher != null) txtCodeVoucher.requestFocus();
    }

    @FXML
    public void handleRafraichirHistorique(ActionEvent event) {
        chargerHistorique();
        setStatus("Historique rafraîchi.");
    }

    @FXML
    public void handleFiltreAll(ActionEvent event) {
        if (btnFiltreSuccess != null) btnFiltreSuccess.setSelected(false);
        if (btnFiltreEchec   != null) btnFiltreEchec.setSelected(false);
        appliquerFiltre();
    }

    @FXML
    public void handleFiltreSucces(ActionEvent event) {
        if (btnFiltreAll   != null) btnFiltreAll.setSelected(false);
        if (btnFiltreEchec != null) btnFiltreEchec.setSelected(false);
        appliquerFiltre();
    }

    @FXML
    public void handleFiltreEchecs(ActionEvent event) {
        if (btnFiltreAll     != null) btnFiltreAll.setSelected(false);
        if (btnFiltreSuccess != null) btnFiltreSuccess.setSelected(false);
        appliquerFiltre();
    }

    // ─── Helpers UI ──────────────────────────────────────────────────

    private void afficherPanneauResultat(boolean visible) {
        if (panneauResultat != null) {
            panneauResultat.setVisible(visible);
            panneauResultat.setManaged(visible);
        }
    }

    private void cacherResultat() {
        afficherPanneauResultat(false);
        if (btnConfirmerRedemption != null) {
            btnConfirmerRedemption.setVisible(false);
            btnConfirmerRedemption.setManaged(false);
            btnConfirmerRedemption.setDisable(false);
        }
    }

    private void setStyleResultatHeader(boolean valide) {
        if (resultHeader == null) return;
        resultHeader.getStyleClass().removeAll("rds-result-valid-header", "rds-result-invalid-header");
        resultHeader.getStyleClass().add(valide ? "rds-result-valid-header" : "rds-result-invalid-header");
    }

    private void afficherErreurResultat(String icon, String titre, String message) {
        setStyleResultatHeader(false);
        if (lblResultatIcon    != null) lblResultatIcon.setText(icon);
        if (lblResultatTitre   != null) lblResultatTitre.setText(titre);
        if (lblResultatMessage != null) lblResultatMessage.setText(message);
        if (lblCodeVoucher != null) lblCodeVoucher.setText(txtCodeVoucher != null ? txtCodeVoucher.getText() : "—");
        if (lblClientNom   != null) lblClientNom.setText("—");
        if (lblMontant     != null) lblMontant.setText("—");
        if (lblExpiration  != null) lblExpiration.setText("—");
        if (lblRefDemande  != null) lblRefDemande.setText("—");
        if (btnConfirmerRedemption != null) {
            btnConfirmerRedemption.setVisible(false);
            btnConfirmerRedemption.setManaged(false);
        }
    }

    private void afficherChargement(boolean visible) {
        if (loadingBox != null) {
            loadingBox.setVisible(visible);
            loadingBox.setManaged(visible);
        }
    }

    private void setBoutonValiderActif(boolean actif) {
        if (btnValider != null) btnValider.setDisable(!actif);
    }

    private void mettreAJourCompteurs(int todayCount) {
        if (lblTotalAujourdhui != null) lblTotalAujourdhui.setText(String.valueOf(todayCount));
    }

    private void mettreAJourStatsSessions() {
        if (lblStatSucces      != null) lblStatSucces.setText(String.valueOf(sessionSucces));
        if (lblStatEchecs      != null) lblStatEchecs.setText(String.valueOf(sessionEchecs));
        if (lblStatMontantTotal != null) lblStatMontantTotal.setText("Rs " + sessionMontant.toPlainString());
        if (lblMontantJour     != null) lblMontantJour.setText("Rs " + sessionMontant.toPlainString());
    }

    private void setStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }
}

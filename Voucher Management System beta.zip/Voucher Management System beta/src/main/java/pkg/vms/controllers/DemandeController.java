package pkg.vms.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import pkg.vms.dao.DemandeDAO;
import pkg.vms.models.Client;
import pkg.vms.models.Demande;
import pkg.vms.models.User;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class DemandeController {

    @FXML private TextField txtRecherche;
    @FXML private ComboBox<String> cmbFiltreStatut;

    @FXML private TableView<Demande> tableDemandes;
    @FXML private TableColumn<Demande, Integer> colRefDemande;
    @FXML private TableColumn<Demande, String> colReference;
    @FXML private TableColumn<Demande, String> colClient;
    @FXML private TableColumn<Demande, String> colEmail;
    @FXML private TableColumn<Demande, Integer> colNbVoucher;
    @FXML private TableColumn<Demande, BigDecimal> colValeurVoucher;
    @FXML private TableColumn<Demande, BigDecimal> colMontantTotal;
    @FXML private TableColumn<Demande, String> colStatut;
    @FXML private TableColumn<Demande, String> colPaiement;
    @FXML private TableColumn<Demande, String> colDateCreation;
    @FXML private TableColumn<Demande, Void> colActions;

    @FXML private Label lblStatus;
    @FXML private Label lblTotal;
    @FXML private Label lblInitiees;
    @FXML private Label lblPayees;
    @FXML private Label lblApprouvees;
    @FXML private Label lblRejetees;

    private DemandeDAO demandeDAO;
    private ObservableList<Demande> demandesList;
    private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    // ── Utilisateur connecté (injecté par DashboardController) ───────────────
    private User currentUser;

    /** Appelé par DashboardController après le chargement du FXML */
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    /** Retourne l'ID de l'utilisateur connecté, ou null si non défini */
    private Integer getCurrentUserId() {
        return (currentUser != null) ? currentUser.getUserId() : null;
    }

    // ─────────────────────────────────────────────────────────────────────────

    @FXML
    public void initialize() {
        demandeDAO = new DemandeDAO();
        demandesList = FXCollections.observableArrayList();
        initializeTableColumns();
        cmbFiltreStatut.setValue("Tous");
        loadDemandes();
        updateStatus("Prêt - Système de gestion des demandes");
    }

    private void initializeTableColumns() {
        colRefDemande.setCellValueFactory(new PropertyValueFactory<>("refDemande"));

        colReference.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getReference()));

        colClient.setCellValueFactory(new PropertyValueFactory<>("clientNom"));

        colEmail.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getClientEmail() != null
                                ? cellData.getValue().getClientEmail() : "N/A"));

        colNbVoucher.setCellValueFactory(new PropertyValueFactory<>("nbVoucher"));

        colValeurVoucher.setCellValueFactory(new PropertyValueFactory<>("valeurVoucher"));
        colValeurVoucher.setCellFactory(column -> new TableCell<Demande, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal item, boolean empty) {
                super.updateItem(item, empty);
                setText((empty || item == null) ? null : String.format("Rs %.0f", item));
            }
        });

        colMontantTotal.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleObjectProperty<>(
                        cellData.getValue().getMontantTotal()));
        colMontantTotal.setCellFactory(column -> new TableCell<Demande, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); }
                else {
                    setText(String.format("Rs %.0f", item));
                    setStyle("-fx-font-weight: bold; -fx-text-fill: #27ae60; -fx-font-size: 13px;");
                }
            }
        });

        colStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));
        colStatut.setCellFactory(column -> new TableCell<Demande, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item.toUpperCase());
                setAlignment(Pos.CENTER);
                switch (item.toLowerCase()) {
                    case "initiee":
                        setStyle("-fx-background-color:#fff3cd;-fx-text-fill:#856404;-fx-font-weight:bold;-fx-padding:5 10;-fx-background-radius:12;-fx-font-size:11px;"); break;
                    case "payee":
                        setStyle("-fx-background-color:#cfe2ff;-fx-text-fill:#084298;-fx-font-weight:bold;-fx-padding:5 10;-fx-background-radius:12;-fx-font-size:11px;"); break;
                    case "approuvee":
                        setStyle("-fx-background-color:#d1e7dd;-fx-text-fill:#0f5132;-fx-font-weight:bold;-fx-padding:5 10;-fx-background-radius:12;-fx-font-size:11px;"); break;
                    case "rejetee":
                        setStyle("-fx-background-color:#f8d7da;-fx-text-fill:#842029;-fx-font-weight:bold;-fx-padding:5 10;-fx-background-radius:12;-fx-font-size:11px;"); break;
                    default:
                        setStyle("-fx-font-weight:bold;");
                }
            }
        });

        colPaiement.setCellValueFactory(cellData -> {
            LocalDateTime dp = cellData.getValue().getDatePayement();
            return new javafx.beans.property.SimpleStringProperty(dp != null ? "PAYÉ" : "NON PAYÉ");
        });
        colPaiement.setCellFactory(column -> new TableCell<Demande, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setAlignment(Pos.CENTER);
                setStyle("PAYÉ".equals(item)
                        ? "-fx-background-color:#d4edda;-fx-text-fill:#155724;-fx-font-weight:bold;-fx-padding:5 10;-fx-background-radius:12;-fx-font-size:10px;"
                        : "-fx-background-color:#f8d7da;-fx-text-fill:#721c24;-fx-font-weight:bold;-fx-padding:5 10;-fx-background-radius:12;-fx-font-size:10px;");
            }
        });

        colDateCreation.setCellValueFactory(cellData -> {
            LocalDateTime date = cellData.getValue().getDateCreation();
            return new javafx.beans.property.SimpleStringProperty(
                    date != null ? date.format(dateTimeFormatter) : "");
        });

        colActions.setCellFactory(column -> new TableCell<Demande, Void>() {
            private final Button btnPayer    = new Button("💳 Payer");
            private final Button btnApprouver = new Button("✅ Approuver");
            private final Button btnRejeter  = new Button("❌ Rejeter");
            private final Button btnDetails  = new Button("👁️");
            private final HBox   actionBox   = new HBox(5);

            {
                btnPayer.setStyle    ("-fx-background-color:#3498db;-fx-text-fill:white;-fx-background-radius:5;-fx-padding:5 10;-fx-cursor:hand;-fx-font-size:11px;-fx-font-weight:bold;");
                btnApprouver.setStyle("-fx-background-color:#27ae60;-fx-text-fill:white;-fx-background-radius:5;-fx-padding:5 10;-fx-cursor:hand;-fx-font-size:11px;-fx-font-weight:bold;");
                btnRejeter.setStyle  ("-fx-background-color:#e74c3c;-fx-text-fill:white;-fx-background-radius:5;-fx-padding:5 10;-fx-cursor:hand;-fx-font-size:11px;-fx-font-weight:bold;");
                btnDetails.setStyle  ("-fx-background-color:#95a5a6;-fx-text-fill:white;-fx-background-radius:5;-fx-padding:5 10;-fx-cursor:hand;-fx-font-size:11px;");
                actionBox.setAlignment(Pos.CENTER);

                btnPayer.setOnAction(e -> {
                    Demande d = getTableView().getItems().get(getIndex());
                    handleMarquerPaye(d);
                });
                btnApprouver.setOnAction(e -> {
                    Demande d = getTableView().getItems().get(getIndex());
                    handleApprouver(d);
                });
                btnRejeter.setOnAction(e -> {
                    Demande d = getTableView().getItems().get(getIndex());
                    handleRejeter(d);
                });
                btnDetails.setOnAction(e -> {
                    Demande d = getTableView().getItems().get(getIndex());
                    handleDetails(d);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); return; }

                Demande demande = getTableView().getItems().get(getIndex());
                actionBox.getChildren().clear();

                String statut  = demande.getStatut().toLowerCase();
                boolean estPaye = demande.getDatePayement() != null;

                if ("initiee".equals(statut) && !estPaye) {
                    actionBox.getChildren().addAll(btnPayer, btnRejeter, btnDetails);
                } else if (("initiee".equals(statut) && estPaye) || "payee".equals(statut)) {
                    actionBox.getChildren().addAll(btnApprouver, btnRejeter, btnDetails);
                } else {
                    actionBox.getChildren().add(btnDetails);
                }
                setGraphic(actionBox);
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Chargement
    // ─────────────────────────────────────────────────────────────────────────

    private void loadDemandes() {
        List<Demande> demandes = demandeDAO.readAll();
        demandesList.clear();
        demandesList.addAll(demandes);
        tableDemandes.setItems(demandesList);
        updateStatistics();
        updateStatus("✓ " + demandes.size() + " demande(s) chargée(s)");
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Actions FXML
    // ─────────────────────────────────────────────────────────────────────────

    @FXML
    private void handleRecherche(KeyEvent event) {
        String keyword = txtRecherche.getText().trim();
        String statutFiltre = cmbFiltreStatut.getValue();

        if (keyword.isEmpty() && "Tous".equals(statutFiltre)) {
            loadDemandes();
        } else if (!keyword.isEmpty()) {
            List<Demande> results = demandeDAO.search(keyword);
            if (!"Tous".equals(statutFiltre))
                results.removeIf(d -> !d.getStatut().equals(statutFiltre));
            demandesList.clear();
            demandesList.addAll(results);
            tableDemandes.setItems(demandesList);
            updateStatistics();
            updateStatus("🔍 " + results.size() + " résultat(s) trouvé(s)");
        } else {
            handleFiltreStatut();
        }
    }

    @FXML
    private void handleFiltreStatut() {
        String statut = cmbFiltreStatut.getValue();
        if ("Tous".equals(statut)) {
            loadDemandes();
        } else {
            List<Demande> results = demandeDAO.filterByStatut(statut);
            demandesList.clear();
            demandesList.addAll(results);
            tableDemandes.setItems(demandesList);
            updateStatistics();
            updateStatus("📊 Filtre : " + results.size() + " demande(s) " + statut);
        }
    }

    @FXML
    private void handleRafraichir() {
        txtRecherche.clear();
        cmbFiltreStatut.setValue("Tous");
        loadDemandes();
        updateStatus("🔄 Données rafraîchies");
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Logique métier — utilise getCurrentUserId() partout
    // ─────────────────────────────────────────────────────────────────────────

    private void handleMarquerPaye(Demande demande) {
        // Vérifier que l'utilisateur est connecté
        Integer userId = getCurrentUserId();
        if (userId == null) {
            showAlert(Alert.AlertType.WARNING, "Session expirée",
                    "Impossible de récupérer l'utilisateur connecté.\nVeuillez vous reconnecter.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmer le paiement");
        confirmation.setHeaderText("Marquer comme payé");
        confirmation.setContentText(String.format(
                "Demande : %s\nClient : %s\nMontant : Rs %.2f\n\nConfirmer que le paiement a été reçu ?",
                demande.getReference(), demande.getClientNom(), demande.getMontantTotal()));

        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (demandeDAO.marquerPaye(demande.getRefDemande(), userId)) {
                showAlert(Alert.AlertType.INFORMATION, "Succès",
                        "✓ Paiement enregistré avec succès!\n\nLa demande peut maintenant être approuvée.");
                loadDemandes();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'enregistrer le paiement.");
            }
        }
    }

    private void handleApprouver(Demande demande) {
        if (demande.getDatePayement() == null) {
            showAlert(Alert.AlertType.WARNING, "Attention",
                    "Cette demande n'a pas encore été payée!\n\nVeuillez d'abord marquer le paiement.");
            return;
        }

        Integer userId = getCurrentUserId();
        if (userId == null) {
            showAlert(Alert.AlertType.WARNING, "Session expirée",
                    "Impossible de récupérer l'utilisateur connecté.\nVeuillez vous reconnecter.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Approuver la demande");
        confirmation.setHeaderText("Confirmation d'approbation");
        confirmation.setContentText(String.format(
                "Demande : %s\nClient : %s\nNombre de vouchers : %d\n" +
                        "Valeur unitaire : Rs %.2f\nMontant total : Rs %.2f\n\n" +
                        "⚠️ Cette action déclenchera la génération et l'envoi des %d vouchers par email.\n\n" +
                        "Confirmer l'approbation ?",
                demande.getReference(), demande.getClientNom(),
                demande.getNbVoucher(), demande.getValeurVoucher(),
                demande.getMontantTotal(), demande.getNbVoucher()));

        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (demandeDAO.marquerApprouve(demande.getRefDemande(), userId)) {
                showAlert(Alert.AlertType.INFORMATION, "Demande Approuvée!",
                        "✅ La demande a été approuvée avec succès!\n\n" +
                                "📧 Les vouchers seront générés et envoyés à :\n" +
                                demande.getClientEmail());
                loadDemandes();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'approuver la demande.");
            }
        }
    }

    private void handleRejeter(Demande demande) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Rejeter la demande");
        dialog.setHeaderText("Demande " + demande.getReference());
        dialog.setContentText("Motif du rejet :");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(motif -> {
            if (motif.trim().isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Attention", "Veuillez indiquer un motif de rejet.");
                return;
            }
            if (demandeDAO.marquerRejetee(demande.getRefDemande(), motif)) {
                showAlert(Alert.AlertType.INFORMATION, "Demande Rejetée",
                        "❌ La demande a été rejetée.\nLe client sera notifié par email.");
                loadDemandes();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de rejeter la demande.");
            }
        });
    }

    void handleSoumettre() {
        Client client = createOrGetClient();
        Demande demande = new Demande();
        demande.setClientId(client.getId());
        demande.setInitiatedBy(getCurrentUserId());
        demandeDAO.create(demande);
    }

    private Client createOrGetClient() { return null; }

    private void handleDetails(Demande demande) {
        Alert details = new Alert(Alert.AlertType.INFORMATION);
        details.setTitle("Détails de la demande");
        details.setHeaderText("📋 Demande " + demande.getReference());
        details.setContentText(String.format(
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n👤 CLIENT\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "Nom : %s\nEmail : %s\n\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🎟️ VOUCHERS\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "Quantité : %d vouchers\nValeur unitaire : Rs %.2f\nMontant total : Rs %.2f\n\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📊 STATUT\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "Statut : %s\nPaiement : %s\nApprobation : %s\n\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📅 DATES\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "Création : %s\nValidité : %d jours\nExpiration : %s\n\nNotes : %s",
                demande.getClientNom(),
                demande.getClientEmail() != null ? demande.getClientEmail() : "N/A",
                demande.getNbVoucher(), demande.getValeurVoucher(), demande.getMontantTotal(),
                demande.getStatut().toUpperCase(),
                demande.getDatePayement()    != null ? "✓ PAYÉ le "    + demande.getDatePayement().format(dateTimeFormatter)    : "✗ NON PAYÉ",
                demande.getDateApprobation() != null ? "✓ APPROUVÉ le " + demande.getDateApprobation().format(dateTimeFormatter) : "✗ EN ATTENTE",
                demande.getDateCreation().format(dateTimeFormatter),
                demande.getDuree() != null ? demande.getDuree() : 0,
                demande.getExpireDate() != null ? demande.getExpireDate().toString() : "N/A",
                demande.getStatusDemande() != null ? demande.getStatusDemande() : "Aucune note"
        ));
        details.showAndWait();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private void updateStatistics() {
        lblTotal.setText(String.valueOf(demandesList.size()));
        lblInitiees.setText  (String.valueOf(demandesList.stream().filter(d -> "initiee".equals(d.getStatut())).count()));
        lblPayees.setText    (String.valueOf(demandesList.stream().filter(d -> "payee".equals(d.getStatut())).count()));
        lblApprouvees.setText(String.valueOf(demandesList.stream().filter(d -> "approuvee".equals(d.getStatut())).count()));
        lblRejetees.setText  (String.valueOf(demandesList.stream().filter(d -> "rejetee".equals(d.getStatut())).count()));
    }

    private void updateStatus(String message) { lblStatus.setText(message); }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
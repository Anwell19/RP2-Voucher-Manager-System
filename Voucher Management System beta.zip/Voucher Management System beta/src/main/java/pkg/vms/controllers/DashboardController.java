package pkg.vms.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import pkg.vms.dao.ClientDAO;
import pkg.vms.dao.DemandeDAO;
import pkg.vms.dao.UserPermissionsDAO;
import pkg.vms.dao.UserPermissionsDAO.UserPermissions;
import pkg.vms.dao.VoucherDAO;
import pkg.vms.models.User;

import java.io.IOException;

/**
 * Contrôleur du tableau de bord principal.
 *
 * Contrôle d'accès : les boutons de menu sont activés/désactivés
 * en fonction des permissions stockées dans vms.user_permissions,
 * telles que définies par l'admin dans la gestion des utilisateurs.
 */
public class DashboardController {

    // ---- Layout ----
    @FXML private VBox       sideMenu;
    @FXML private HBox       topNavBar;
    @FXML private StackPane  mainContent;
    @FXML private BorderPane contentArea;

    // ---- Menu ----
    @FXML private Button btnDashboard;
    @FXML private Button btnUsers;
    @FXML private Button btnClients;
    @FXML private Button btnDemandes;
    @FXML private Button btnVouchers;
    @FXML private Button btnRedemption;
    @FXML private Button btnParametres;
    @FXML private Button btnDeconnexion;
    @FXML private Button btnMagasins;

    // ---- Statistiques ----
    @FXML private Label lblTotalClients;
    @FXML private Label lblTotalDemandes;
    @FXML private Label lblTotalVouchers;

    // ---- Utilisateur connecté ----
    @FXML private Label lblCurrentUser;
    @FXML private Label lblUserRole;

    // ---- DAO ----
    private ClientDAO          clientDAO;
    private DemandeDAO         demandeDAO;
    private VoucherDAO         voucherDAO;
    private UserPermissionsDAO permissionsDAO;

    private Button          activeButton;
    private User            currentUser;
    private UserPermissions currentPermissions;  // permissions chargées depuis la DB

    // =========================================================
    // Initialisation
    // =========================================================

    @FXML
    public void initialize() {
        clientDAO      = new ClientDAO();
        demandeDAO     = new DemandeDAO();
        voucherDAO     = new VoucherDAO();
        permissionsDAO = new UserPermissionsDAO();

        loadStatistics();
        if (btnDashboard != null) setActiveButton(btnDashboard);
    }

    // =========================================================
    // Injection de l'utilisateur connecté
    // =========================================================

    public void setCurrentUser(User user) {
        this.currentUser = user;
        if (user != null) {
            System.out.println("[Dashboard] Connecté : "
                    + user.getFullName() + " — rôle : " + user.getRole());

            // Charger les permissions depuis la base de données
            currentPermissions = permissionsDAO.getByUserId(user.getUserId());
            System.out.println("[Dashboard] Permissions : " + currentPermissions);

            updateUserDisplay();
            configureMenuAccess();
        }
    }

    // =========================================================
    // Affichage utilisateur
    // =========================================================

    private void updateUserDisplay() {
        if (currentUser == null) return;
        if (lblCurrentUser != null) lblCurrentUser.setText(currentUser.getFullName());
        if (lblUserRole    != null) lblUserRole.setText(getRoleLabel(currentUser.getRole()));
    }

    private String getRoleLabel(String role) {
        if (role == null) return "Inconnu";
        return switch (role.toLowerCase()) {
            case "admin"   -> "Administrateur";
            case "manager" -> "Manager";
            case "agent"   -> "Agent";
            default        -> role;
        };
    }

    // =========================================================
    // Contrôle d'accès basé sur les permissions DB
    // =========================================================

    /**
     * Active ou désactive chaque bouton de menu selon les permissions
     * stockées dans vms.user_permissions pour l'utilisateur connecté.
     *
     * L'admin voit toujours TOUT, indépendamment des permissions sauvegardées
     * (sécurité supplémentaire pour éviter le lock-out).
     */
    private void configureMenuAccess() {
        if (currentUser == null) return;

        boolean isAdmin = "admin".equalsIgnoreCase(currentUser.getRole());

        // Si admin → tout est visible, on ne touche à rien
        if (isAdmin) {
            System.out.println("[Dashboard] Admin connecté — accès complet.");
            return;
        }

        // Pour les autres rôles : on se base sur les permissions DB
        if (currentPermissions == null) {
            // Pas de permissions trouvées → tout désactiver par sécurité
            disableButton(btnClients,  "Accès non autorisé");
            disableButton(btnUsers,    "Accès non autorisé");
            disableButton(btnMagasins, "Accès non autorisé");
            disableButton(btnDemandes, "Accès non autorisé");
            disableButton(btnVouchers, "Accès non autorisé");
            return;
        }

        // Appliquer les permissions individuellement
        if (!currentPermissions.isMenuClients())
            disableButton(btnClients, "Accès non autorisé pour votre compte");

        if (!currentPermissions.isMenuUsers())
            disableButton(btnUsers, "Accès réservé aux administrateurs");

        if (!currentPermissions.isMenuMagasins())
            disableButton(btnMagasins, "Accès non autorisé pour votre compte");

        if (!currentPermissions.isMenuDemandes())
            disableButton(btnDemandes, "Accès non autorisé pour votre compte");

        if (!currentPermissions.isMenuVouchers())
            disableButton(btnVouchers, "Accès non autorisé pour votre compte");
    }

    /**
     * Vérifie si l'utilisateur courant peut accéder à un menu donné.
     * Utilisé dans les handlers pour double vérification (défense en profondeur).
     */
    private boolean canAccess(String menu) {
        if (currentUser == null) return false;

        // L'admin a toujours accès
        if ("admin".equalsIgnoreCase(currentUser.getRole())) return true;

        if (currentPermissions == null) return false;

        return switch (menu) {
            case "clients"  -> currentPermissions.isMenuClients();
            case "users"    -> currentPermissions.isMenuUsers();
            case "magasins" -> currentPermissions.isMenuMagasins();
            case "demandes" -> currentPermissions.isMenuDemandes();
            case "vouchers" -> currentPermissions.isMenuVouchers();
            default         -> false;
        };
    }

    private void disableButton(Button btn, String tooltip) {
        if (btn != null) {
            btn.setDisable(true);
            btn.setTooltip(new Tooltip(tooltip));
        }
    }

    private void showAccessDenied() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Accès refusé");
        alert.setHeaderText("Permissions insuffisantes");
        alert.setContentText("Vous n'avez pas les permissions nécessaires pour accéder à cette fonctionnalité.\n"
                + "Contactez votre administrateur.");
        alert.showAndWait();
    }

    // =========================================================
    // Statistiques
    // =========================================================

    private void loadStatistics() {
        int clients = 0, demandes = 0;
        try { if (clientDAO  != null) clients  = clientDAO.count();  } catch (Exception e) { System.err.println("ClientDAO : "  + e.getMessage()); }
        try { if (demandeDAO != null) demandes = demandeDAO.count(); } catch (Exception e) { System.err.println("DemandeDAO : " + e.getMessage()); }
        if (lblTotalClients  != null) lblTotalClients .setText(String.valueOf(clients));
        if (lblTotalDemandes != null) lblTotalDemandes.setText(String.valueOf(demandes));
        if (lblTotalVouchers != null) lblTotalVouchers.setText("0");
    }

    // =========================================================
    // Handlers menu — double vérification d'accès
    // =========================================================

    @FXML private void handleDashboard() {
        setActiveButton(btnDashboard);
        showDashboardHome();
        hideSideMenu(false);
        hideTopNavBar();
    }

    @FXML private void handleUsers() {
        if (!canAccess("users")) { showAccessDenied(); return; }
        setActiveButton(btnUsers);
        loadView("/pkg/vms/fxml/UserManagement.fxml");
        hideSideMenu(true); showTopNavBar();
    }

    @FXML private void handleClients() {
        if (!canAccess("clients")) { showAccessDenied(); return; }
        setActiveButton(btnClients);
        loadView("/pkg/vms/fxml/Client.fxml");
        hideSideMenu(true); showTopNavBar();
    }

    @FXML private void handleDemandes() {
        if (!canAccess("demandes")) { showAccessDenied(); return; }
        setActiveButton(btnDemandes);
        loadView("/pkg/vms/fxml/demande.fxml");
        hideSideMenu(true); showTopNavBar();
    }

    @FXML private void handleVouchers() {
        if (!canAccess("vouchers")) { showAccessDenied(); return; }
        setActiveButton(btnVouchers);
        loadView("/pkg/vms/fxml/voucher.fxml");
        hideSideMenu(true); showTopNavBar();
    }

    @FXML private void handleMagasins() {
        if (!canAccess("magasins")) { showAccessDenied(); return; }
        setActiveButton(btnMagasins);
        loadView("/pkg/vms/fxml/magasin.fxml");
        hideSideMenu(true); showTopNavBar();
    }

    @FXML private void handleParametres() {
        showAlert(Alert.AlertType.INFORMATION, "Paramètres", "Page des paramètres en cours de développement.");
    }

    @FXML private void handleDeconnexion() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Déconnexion");
        confirm.setHeaderText("Confirmer la déconnexion");
        confirm.setContentText("Êtes-vous sûr de vouloir vous déconnecter ?");
        confirm.showAndWait().ifPresent(r -> { if (r == ButtonType.OK) logout(); });
    }

    // =========================================================
    // Navigation interne
    // =========================================================

    private void loadView(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent view = loader.load();
            injectUser(loader.getController());
            if (mainContent != null) mainContent.getChildren().setAll(view);
        } catch (IOException e) {
            System.err.println("[Dashboard] Impossible de charger : " + fxmlPath);
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger la vue : " + fxmlPath);
        }
    }

    private void injectUser(Object controller) {
        if (controller == null || currentUser == null) return;
        try {
            java.lang.reflect.Method setter = controller.getClass().getMethod("setCurrentUser", User.class);
            setter.invoke(controller, currentUser);
        } catch (NoSuchMethodException ignored) {
        } catch (Exception e) {
            System.err.println("[Dashboard] Erreur injection user dans "
                    + controller.getClass().getSimpleName() + " : " + e.getMessage());
        }
    }

    private void showDashboardHome() {
        loadStatistics();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pkg/vms/fxml/dashboard.fxml"));
            Parent view = loader.load();
            if (view instanceof BorderPane) {
                Node center = ((BorderPane) view).getCenter();
                if (mainContent != null)
                    mainContent.getChildren().setAll(center != null ? center : defaultWelcomeNode());
            }
        } catch (IOException e) {
            if (mainContent != null) mainContent.getChildren().setAll(defaultWelcomeNode());
        }
    }

    private VBox defaultWelcomeNode() {
        VBox box = new VBox(20);
        box.setAlignment(Pos.CENTER);
        box.setStyle("-fx-background-color: white;");
        Label title = new Label("Tableau de bord");
        title.setStyle("-fx-font-size:32px; -fx-font-weight:bold; -fx-text-fill:#2c3e50;");
        Label sub = new Label("Bienvenue "
                + (currentUser != null ? currentUser.getFullName() : "")
                + (currentUser != null ? " — " + getRoleLabel(currentUser.getRole()) : ""));
        sub.setStyle("-fx-font-size:16px; -fx-text-fill:#7f8c8d;");
        box.getChildren().addAll(title, sub);
        return box;
    }

    private void logout() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pkg/vms/fxml/Login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnDeconnexion.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("VMS — Connexion");
            stage.setMaximized(false);
            stage.setWidth(900);
            stage.setHeight(600);
            stage.centerOnScreen();
            stage.show();
        } catch (IOException e) {
            System.err.println("[Dashboard] Erreur déconnexion : " + e.getMessage());
            System.exit(0);
        }
    }

    // =========================================================
    // Helpers UI
    // =========================================================

    private void setActiveButton(Button button) {
        if (button == null) return;
        if (activeButton != null) activeButton.getStyleClass().remove("menu-button-active");
        if (!button.getStyleClass().contains("menu-button-active"))
            button.getStyleClass().add("menu-button-active");
        activeButton = button;
    }

    private void hideSideMenu(boolean hide) {
        if (sideMenu != null) { sideMenu.setVisible(!hide); sideMenu.setManaged(!hide); }
    }
    private void showTopNavBar() {
        if (topNavBar != null) { topNavBar.setVisible(true);  topNavBar.setManaged(true); }
    }
    private void hideTopNavBar() {
        if (topNavBar != null) { topNavBar.setVisible(false); topNavBar.setManaged(false); }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert a = new Alert(type);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(content);
        a.showAndWait();
    }
}
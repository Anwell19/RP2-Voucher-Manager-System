package pkg.vms.services;

import pkg.vms.models.Demande;
import pkg.vms.models.Voucher;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Properties;

/**
 * Service d'envoi d'email — envoie le PDF des vouchers en pièce jointe
 */
public class EmailService {

    private static final String SMTP_HOST      = "smtp-vmsproject.alwaysdata.net";
    private static final String SMTP_PORT      = "587";
    private static final String SENDER_EMAIL   = "vmsproject@alwaysdata.net";
    private static final String SENDER_PASSWORD = "Vmsmada2025";

    // ─────────────────────────────────────────────────────────────────────────
    //  Envoi principal : génère le PDF en temp puis l'envoie en pièce jointe
    // ─────────────────────────────────────────────────────────────────────────

    public boolean sendVouchersEmail(String recipientEmail, Demande demande,
                                     List<Voucher> vouchers, String customMessage) {
        File pdfFile = null;
        try {
            // 1. Générer le PDF temporaire
            pdfFile = generateTempPDF(demande, vouchers);

            // 2. Construire la session SMTP
            Session session = buildSession();

            // 3. Construire le message multipart
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(SENDER_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Vos Vouchers – Réf. " + String.format("VR%05d", demande.getRefDemande()));

            // Corps HTML
            MimeBodyPart htmlPart = new MimeBodyPart();
            htmlPart.setContent(buildEmailBody(demande, vouchers, customMessage),
                    "text/html; charset=utf-8");

            // Pièce jointe PDF
            MimeBodyPart attachPart = new MimeBodyPart();
            DataSource source = new FileDataSource(pdfFile);
            attachPart.setDataHandler(new DataHandler(source));
            attachPart.setFileName(String.format("Vouchers_VR%05d.pdf", demande.getRefDemande()));

            // Assembler
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(htmlPart);
            multipart.addBodyPart(attachPart);
            message.setContent(multipart);

            Transport.send(message);
            System.out.println("Email envoyé avec PDF à : " + recipientEmail);
            return true;

        } catch (Exception e) {
            System.err.println("Erreur envoi email : " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            // Supprimer le fichier temporaire
            if (pdfFile != null && pdfFile.exists()) {
                pdfFile.delete();
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Génération du PDF temporaire
    // ─────────────────────────────────────────────────────────────────────────

    private File generateTempPDF(Demande demande, List<Voucher> vouchers) throws Exception {
        // Vérifier / générer les images si nécessaire
        String voucherDir = "vouchers/VR" + String.format("%05d", demande.getRefDemande());
        new File(voucherDir).mkdirs();

        VoucherImageGeneratorService imgService = new VoucherImageGeneratorService();
        for (Voucher v : vouchers) {
            String sanitized = v.getNoVoucher()
                    .replace("/", "-").replace("\\", "-").replace(":", "-");
            File imgFile = new File(voucherDir + "/Voucher_" + sanitized + ".png");
            if (!imgFile.exists()) {
                imgService.generateAndSaveVoucher(v, voucherDir);
            }
        }

        // Créer le PDF temporaire
        File tmpPdf = File.createTempFile(
                String.format("Vouchers_VR%05d_", demande.getRefDemande()), ".pdf");

        PDFGeneratorService pdfService = new PDFGeneratorService();
        pdfService.generateVouchersPDF(demande, vouchers, tmpPdf.getAbsolutePath());
        return tmpPdf;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Corps HTML de l'email (simple et propre)
    // ─────────────────────────────────────────────────────────────────────────

    private String buildEmailBody(Demande demande, List<Voucher> vouchers, String customMessage) {
        String clientName = demande.getClientName() != null ? demande.getClientName() : "Client";
        StringBuilder sb = new StringBuilder();

        sb.append("<!DOCTYPE html><html><head><meta charset='utf-8'>")
                .append("<style>")
                .append("body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:0;}")
                .append(".wrap{max-width:600px;margin:30px auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.1);}")
                .append(".header{background:linear-gradient(135deg,#6a11cb,#2575fc);padding:36px 30px;text-align:center;}")
                .append(".header h1{color:#fff;margin:0;font-size:26px;letter-spacing:1px;}")
                .append(".header p{color:rgba(255,255,255,.8);margin:6px 0 0;font-size:14px;}")
                .append(".body{padding:30px;}")
                .append(".greeting{font-size:17px;color:#222;margin-bottom:16px;}")
                .append(".custom-msg{background:#f0f4ff;border-left:4px solid #6a11cb;padding:12px 16px;border-radius:0 8px 8px 0;color:#333;margin-bottom:20px;font-size:14px;}")
                .append(".info-box{background:#fafafa;border:1px solid #e8e8e8;border-radius:8px;padding:18px 22px;margin-bottom:24px;}")
                .append(".info-box p{margin:6px 0;font-size:14px;color:#555;}")
                .append(".info-box strong{color:#222;}")
                .append(".attach-note{background:linear-gradient(135deg,#e8f5e9,#e3f2fd);border-radius:8px;padding:16px 20px;margin-bottom:24px;display:flex;align-items:center;gap:12px;}")
                .append(".attach-note .icon{font-size:32px;}")
                .append(".attach-note p{margin:0;font-size:14px;color:#333;}")
                .append(".attach-note p strong{color:#1565c0;}")
                .append(".footer{background:#f8f8f8;padding:20px 30px;text-align:center;font-size:12px;color:#999;border-top:1px solid #eee;}")
                .append("</style></head><body>")
                .append("<div class='wrap'>")

                // Header
                .append("<div class='header'>")
                .append("<h1>🎟️ Vos Vouchers</h1>")
                .append("<p>Référence : ").append(String.format("VR%05d-%02d", demande.getRefDemande(), demande.getNbVoucher())).append("</p>")
                .append("</div>")

                // Body
                .append("<div class='body'>")
                .append("<p class='greeting'>Bonjour <strong>").append(clientName).append("</strong>,</p>");

        if (customMessage != null && !customMessage.isBlank()) {
            sb.append("<div class='custom-msg'>").append(customMessage).append("</div>");
        }

        sb.append("<p style='color:#555;font-size:14px;margin-bottom:20px;'>")
                .append("Veuillez trouver ci-joint vos <strong>").append(vouchers.size())
                .append(" voucher(s)</strong> au format PDF.")
                .append("</p>")

                // Infos résumé
                .append("<div class='info-box'>")
                .append("<p>📦 <strong>Nombre de vouchers :</strong> ").append(vouchers.size()).append("</p>")
                .append("<p>💰 <strong>Valeur unitaire :</strong> Rs ").append(demande.getValeurVoucher()).append("</p>")
                .append("<p>🧾 <strong>Montant total :</strong> Rs ").append(demande.getTotal()).append("</p>")
                .append("</div>")

                // Note pièce jointe
                .append("<div class='attach-note'>")
                .append("<span class='icon'>📎</span>")
                .append("<p>Le fichier <strong>").append(String.format("Vouchers_VR%05d.pdf", demande.getRefDemande()))
                .append("</strong> est joint à cet email.<br>")
                .append("Chaque voucher contient un QR code unique à scanner lors de l'utilisation.</p>")
                .append("</div>")

                .append("</div>") // end body

                // Footer
                .append("<div class='footer'>")
                .append("<p>Merci de votre confiance. Cet email est automatique, merci de ne pas y répondre.</p>")
                .append("</div>")
                .append("</div>") // end wrap
                .append("</body></html>");

        return sb.toString();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Session SMTP
    // ─────────────────────────────────────────────────────────────────────────

    private Session buildSession() {
        Properties props = new Properties();
        props.put("mail.smtp.auth",              "true");
        props.put("mail.smtp.starttls.enable",   "true");
        props.put("mail.smtp.host",              SMTP_HOST);
        props.put("mail.smtp.port",              SMTP_PORT);
        props.put("mail.smtp.ssl.trust",         SMTP_HOST);

        return Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Envoi d'un voucher unique (inchangé, conservé pour compatibilité)
    // ─────────────────────────────────────────────────────────────────────────

    public boolean sendSingleVoucher(String recipientEmail, Voucher voucher, String clientName) {
        try {
            Session session = buildSession();

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(SENDER_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Votre Voucher – " + voucher.getNoVoucher());

            String body = String.format(
                    "<html><body style='font-family:Arial,sans-serif;'>"
                            + "<h2 style='color:#6a11cb;'>Votre Voucher</h2>"
                            + "<p>Bonjour <strong>%s</strong>,</p>"
                            + "<div style='border:2px solid #6a11cb;padding:20px;border-radius:10px;max-width:400px;'>"
                            + "<p><strong>Code :</strong> %s</p>"
                            + "<p><strong>Montant :</strong> Rs %s</p>"
                            + "<p><strong>Expiration :</strong> %s</p>"
                            + "</div><p>Merci !</p></body></html>",
                    clientName, voucher.getNoVoucher(), voucher.getMontant(), voucher.getExpireDate()
            );

            message.setContent(body, "text/html; charset=utf-8");
            Transport.send(message);
            return true;
        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
    }
}
package pkg.vms.services;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

/**
 * Service pour la génération de QR codes
 */
public class QRCodeService {

    /**
     * Génère une image de QR code
     * @param data Les données à encoder
     * @param width Largeur de l'image
     * @param height Hauteur de l'image
     * @return BufferedImage contenant le QR code
     */
    public BufferedImage generateQRCodeImage(String data, int width, int height) throws WriterException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();

        // Configuration du QR code
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.MARGIN, 1);

        // Générer la matrice de bits
        BitMatrix bitMatrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, width, height, hints);

        // Convertir en image
        return MatrixToImageWriter.toBufferedImage(bitMatrix);
    }

    /**
     * Génère et sauvegarde un QR code dans un fichier
     * @param data Les données à encoder
     * @param width Largeur
     * @param height Hauteur
     * @param filePath Chemin du fichier de sortie
     */
    public void generateQRCodeFile(String data, int width, int height, String filePath)
            throws WriterException, IOException {
        BufferedImage qrImage = generateQRCodeImage(data, width, height);

        File outputFile = new File(filePath);
        outputFile.getParentFile().mkdirs();

        ImageIO.write(qrImage, "PNG", outputFile);
    }

    /**
     * Génère un QR code avec taille par défaut (200x200)
     */
    public BufferedImage generateQRCodeImage(String data) throws WriterException {
        return generateQRCodeImage(data, 200, 200);
    }

    /**
     * Crée un QR code avec logo au centre (optionnel)
     */
    public BufferedImage generateQRCodeWithLogo(String data, int size, BufferedImage logo)
            throws WriterException {
        BufferedImage qrImage = generateQRCodeImage(data, size, size);

        if (logo != null) {
            java.awt.Graphics2D g2d = qrImage.createGraphics();

            // Position et taille du logo (30% de la taille du QR code)
            int logoSize = size / 3;
            int logoX = (size - logoSize) / 2;
            int logoY = (size - logoSize) / 2;

            // Fond blanc pour le logo
            g2d.setColor(java.awt.Color.WHITE);
            g2d.fillRect(logoX - 5, logoY - 5, logoSize + 10, logoSize + 10);

            // Dessiner le logo
            g2d.drawImage(logo, logoX, logoY, logoSize, logoSize, null);
            g2d.dispose();
        }

        return qrImage;
    }
}
package pkg.vms.services;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.draw.LineSeparator;
import pkg.vms.models.Demande;
import pkg.vms.models.Voucher;

import java.io.File;
import java.io.FileOutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Service pour la génération de PDF des vouchers avec images
 */
public class PDFGeneratorService {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /**
     * Génère un PDF contenant les images des vouchers
     */
    public void generateVouchersPDF(Demande demande, List<Voucher> vouchers, String outputPath) throws Exception {
        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(outputPath));

        document.open();

        // Page de garde avec informations de la demande
        addCoverPage(document, demande, vouchers.size());

        // Nouvelle page pour les vouchers
        document.newPage();

        // Ajouter chaque voucher comme image
        addVoucherImages(document, demande, vouchers);

        document.close();
        writer.close();

        System.out.println("PDF généré: " + outputPath);
    }

    /**
     * Page de garde avec résumé
     */
    private void addCoverPage(Document document, Demande demande, int voucherCount) throws DocumentException {
        // Titre principal
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 28, Font.BOLD, BaseColor.DARK_GRAY);
        Paragraph title = new Paragraph("VOUCHERS", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(10);
        document.add(title);

        // Référence
        Font refFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, new BaseColor(33, 150, 243));
        String ref = String.format("VR%05d-%02d", demande.getRefDemande(), demande.getNbVoucher());
        Paragraph reference = new Paragraph(ref, refFont);
        reference.setAlignment(Element.ALIGN_CENTER);
        reference.setSpacingAfter(30);
        document.add(reference);

        // Ligne de séparation
        LineSeparator line = new LineSeparator();
        line.setLineColor(new BaseColor(33, 150, 243));
        document.add(new Chunk(String.valueOf(line)));
        document.add(new Paragraph("\n"));

        // Informations de la demande
        Font boldFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
        Font normalFont = new Font(Font.FontFamily.HELVETICA, 12);

        PdfPTable infoTable = new PdfPTable(2);
        infoTable.setWidthPercentage(80);
        infoTable.setSpacingBefore(20);
        infoTable.setSpacingAfter(30);

        addInfoRow(infoTable, "Client:", demande.getClientName(), boldFont, normalFont);
        addInfoRow(infoTable, "Email:", demande.getClientEmail() != null ? demande.getClientEmail() : "N/A", boldFont, normalFont);
        addInfoRow(infoTable, "Nombre de vouchers:", String.valueOf(voucherCount), boldFont, normalFont);
        addInfoRow(infoTable, "Valeur unitaire:", "Rs " + demande.getValeurVoucher(), boldFont, normalFont);
        addInfoRow(infoTable, "Montant total:", "Rs " + demande.getTotal(), boldFont, normalFont);
        addInfoRow(infoTable, "Date de création:", DATE_FORMATTER.format(demande.getDateCreation()), boldFont, normalFont);

        document.add(infoTable);

        // Note
        Font noteFont = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY);
        Paragraph note = new Paragraph(
                "\nCe document contient " + voucherCount + " voucher(s) sous forme d'images.\n" +
                        "Chaque voucher peut être utilisé individuellement.\n" +
                        "Scannez le QR code pour validation.",
                noteFont
        );
        note.setAlignment(Element.ALIGN_CENTER);
        note.setSpacingBefore(40);
        document.add(note);
    }

    /**
     * Ajouter une ligne d'information dans la table
     */
    private void addInfoRow(PdfPTable table, String label, String value, Font labelFont, Font valueFont) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setPaddingBottom(8);
        table.addCell(labelCell);

        PdfPCell valueCell = new PdfPCell(new Phrase(value, valueFont));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setPaddingBottom(8);
        table.addCell(valueCell);
    }

    /**
     * Ajouter les images des vouchers au PDF
     */
    private void addVoucherImages(Document document, Demande demande, List<Voucher> vouchers) throws Exception {
        String voucherDir = "vouchers/VR" + String.format("%05d", demande.getRefDemande());

        for (int i = 0; i < vouchers.size(); i++) {
            Voucher voucher = vouchers.get(i);

            // Sanitize le no_voucher pour le nom de fichier
            String sanitizedVoucherNo = voucher.getNoVoucher()
                    .replace("/", "-")
                    .replace("\\", "-")
                    .replace(":", "-");

            // Chemin de l'image du voucher
            String imagePath = voucherDir + "/Voucher_" + sanitizedVoucherNo + ".png";
            File imageFile = new File(imagePath);

            // Vérifier si l'image existe
            if (!imageFile.exists()) {
                // Si l'image n'existe pas, afficher un message
                Font errorFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC, BaseColor.RED);
                Paragraph error = new Paragraph(
                        "Image du voucher " + voucher.getNoVoucher() + " non trouvée.\n" +
                                "Chemin recherché: " + imagePath + "\n" +
                                "Veuillez régénérer les images des vouchers.",
                        errorFont
                );
                error.setAlignment(Element.ALIGN_CENTER);
                error.setSpacingBefore(50);
                document.add(error);

                // Continuer avec le prochain voucher
                if (i < vouchers.size() - 1) {
                    document.newPage();
                }
                continue;
            }

            // Ajouter un titre pour le voucher
            Font voucherTitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, new BaseColor(33, 150, 243));
            Paragraph voucherTitle = new Paragraph(
                    "Voucher " + (i + 1) + " / " + vouchers.size() + " - " + voucher.getNoVoucher(),
                    voucherTitleFont
            );
            voucherTitle.setAlignment(Element.ALIGN_CENTER);
            voucherTitle.setSpacingBefore(20);
            voucherTitle.setSpacingAfter(10);
            document.add(voucherTitle);

            // Ajouter l'image du voucher
            Image voucherImage = Image.getInstance(imagePath);

            // Calculer la taille pour que le voucher tienne sur la page
            float pageWidth = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
            float pageHeight = document.getPageSize().getHeight() - document.topMargin() - document.bottomMargin();

            // Garder le ratio de l'image (900x500)
            float maxWidth = pageWidth * 0.95f;  // 95% de la largeur de la page
            float maxHeight = pageHeight * 0.6f;  // 60% de la hauteur disponible

            voucherImage.scaleToFit(maxWidth, maxHeight);
            voucherImage.setAlignment(Element.ALIGN_CENTER);

            // Centrer l'image
            float imageWidth = voucherImage.getScaledWidth();
            float indentation = (pageWidth - imageWidth) / 2;
            voucherImage.setIndentationLeft(indentation);

            document.add(voucherImage);

            // Ajouter les informations du voucher sous l'image
            addVoucherDetails(document, voucher);

            // Nouvelle page pour le prochain voucher (sauf pour le dernier)
            if (i < vouchers.size() - 1) {
                document.newPage();
            }
        }
    }

    /**
     * Ajouter les détails du voucher sous l'image
     */
    private void addVoucherDetails(Document document, Voucher voucher) throws DocumentException {
        Font detailFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.DARK_GRAY);

        PdfPTable detailsTable = new PdfPTable(2);
        detailsTable.setWidthPercentage(80);
        detailsTable.setSpacingBefore(15);
        detailsTable.setSpacingAfter(10);

        // Code
        PdfPCell codeLabel = new PdfPCell(new Phrase("Code:", detailFont));
        codeLabel.setBorder(Rectangle.NO_BORDER);
        codeLabel.setHorizontalAlignment(Element.ALIGN_RIGHT);
        detailsTable.addCell(codeLabel);

        PdfPCell codeValue = new PdfPCell(new Phrase(voucher.getNoVoucher(), detailFont));
        codeValue.setBorder(Rectangle.NO_BORDER);
        detailsTable.addCell(codeValue);

        // Montant
        PdfPCell amountLabel = new PdfPCell(new Phrase("Montant:", detailFont));
        amountLabel.setBorder(Rectangle.NO_BORDER);
        amountLabel.setHorizontalAlignment(Element.ALIGN_RIGHT);
        detailsTable.addCell(amountLabel);

        PdfPCell amountValue = new PdfPCell(new Phrase("Rs " + voucher.getMontant(), detailFont));
        amountValue.setBorder(Rectangle.NO_BORDER);
        detailsTable.addCell(amountValue);

        // Statut
        PdfPCell statusLabel = new PdfPCell(new Phrase("Statut:", detailFont));
        statusLabel.setBorder(Rectangle.NO_BORDER);
        statusLabel.setHorizontalAlignment(Element.ALIGN_RIGHT);
        detailsTable.addCell(statusLabel);

        Font statusFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        BaseColor statusColor = getStatusColor(voucher.getStatusVouch());
        statusFont.setColor(statusColor);

        PdfPCell statusValue = new PdfPCell(new Phrase(voucher.getStatusVouch().toUpperCase(), statusFont));
        statusValue.setBorder(Rectangle.NO_BORDER);
        detailsTable.addCell(statusValue);

        document.add(detailsTable);

        // Ligne de séparation
        LineSeparator separator = new LineSeparator();
        separator.setLineColor(BaseColor.LIGHT_GRAY);
        document.add(new Chunk(separator));
    }

    /**
     * Obtenir la couleur selon le statut
     */
    private BaseColor getStatusColor(String status) {
        switch (status.toLowerCase()) {
            case "active":
                return new BaseColor(76, 175, 80);  // Vert
            case "redeemed":
                return new BaseColor(33, 150, 243);  // Bleu
            case "expired":
                return new BaseColor(244, 67, 54);   // Rouge
            case "draft":
                return new BaseColor(255, 152, 0);   // Orange
            default:
                return BaseColor.GRAY;
        }
    }

    /**
     * Génère un PDF pour un seul voucher
     */
    public void generateSingleVoucherPDF(Voucher voucher, String clientName, String outputPath) throws Exception {
        Document document = new Document(PageSize.A4.rotate()); // Paysage pour mieux afficher le voucher
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(outputPath));

        document.open();

        // Titre
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD);
        Paragraph title = new Paragraph("VOUCHER - " + voucher.getNoVoucher(), titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(30);
        document.add(title);

        // Sanitize le no_voucher pour le nom de fichier
        String sanitizedVoucherNo = voucher.getNoVoucher()
                .replace("/", "-")
                .replace("\\", "-")
                .replace(":", "-");

        // Chemin de l'image
        String imagePath = "vouchers/VR" + String.format("%05d", voucher.getRefDemande()) +
                "/Voucher_" + sanitizedVoucherNo + ".png";
        File imageFile = new File(imagePath);

        if (imageFile.exists()) {
            // Ajouter l'image
            Image voucherImage = Image.getInstance(imagePath);

            float pageWidth = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
            float pageHeight = document.getPageSize().getHeight() - document.topMargin() - document.bottomMargin();

            voucherImage.scaleToFit(pageWidth * 0.9f, pageHeight * 0.7f);
            voucherImage.setAlignment(Element.ALIGN_CENTER);

            float imageWidth = voucherImage.getScaledWidth();
            float indentation = (pageWidth - imageWidth) / 2;
            voucherImage.setIndentationLeft(indentation);

            document.add(voucherImage);
        } else {
            Font errorFont = new Font(Font.FontFamily.HELVETICA, 14, Font.ITALIC, BaseColor.RED);
            Paragraph error = new Paragraph(
                    "Image du voucher non trouvée.\nChemin recherché: " + imagePath,
                    errorFont
            );
            error.setAlignment(Element.ALIGN_CENTER);
            document.add(error);
        }

        document.close();
        writer.close();
    }

    /**
     * Génère un PDF compact avec plusieurs vouchers par page (format économique)
     */
    public void generateCompactVouchersPDF(Demande demande, List<Voucher> vouchers, String outputPath) throws Exception {
        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(outputPath));

        document.open();

        // Page de garde
        addCoverPage(document, demande, vouchers.size());
        document.newPage();

        // 2 vouchers par page
        String voucherDir = "vouchers/VR" + String.format("%05d", demande.getRefDemande());

        for (int i = 0; i < vouchers.size(); i++) {
            Voucher voucher = vouchers.get(i);

            // Sanitize le no_voucher pour le nom de fichier
            String sanitizedVoucherNo = voucher.getNoVoucher()
                    .replace("/", "-")
                    .replace("\\", "-")
                    .replace(":", "-");

            String imagePath = voucherDir + "/Voucher_" + sanitizedVoucherNo + ".png";
            File imageFile = new File(imagePath);

            if (imageFile.exists()) {
                // Titre du voucher
                Font voucherFont = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD);
                Paragraph voucherTitle = new Paragraph(voucher.getNoVoucher() + " - Rs " + voucher.getMontant(), voucherFont);
                voucherTitle.setSpacingBefore(10);
                voucherTitle.setSpacingAfter(5);
                document.add(voucherTitle);

                // Image réduite
                Image voucherImage = Image.getInstance(imagePath);
                float pageWidth = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
                voucherImage.scaleToFit(pageWidth * 0.95f, 200);
                voucherImage.setAlignment(Element.ALIGN_CENTER);
                document.add(voucherImage);

                // Ligne de séparation
                document.add(new Paragraph(" "));
                LineSeparator line = new LineSeparator();
                line.setLineColor(BaseColor.LIGHT_GRAY);
                document.add(new Chunk(line));
                document.add(new Paragraph(" "));

                // Nouvelle page tous les 2 vouchers
                if ((i + 1) % 2 == 0 && i < vouchers.size() - 1) {
                    document.newPage();
                }
            } else {
                // Message d'erreur si image non trouvée
                Font errorFont = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.RED);
                Paragraph error = new Paragraph("Image non trouvée: " + voucher.getNoVoucher(), errorFont);
                error.setSpacingBefore(10);
                error.setSpacingAfter(10);
                document.add(error);
            }
        }

        document.close();
        writer.close();
    }
}
package pkg.vms.services;

import pkg.vms.models.Voucher;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Service pour générer des images de vouchers — design premium moderne
 */
public class VoucherImageGeneratorService {

    private static final int W = 1000;
    private static final int H = 420;

    private static final DateTimeFormatter FMT_MONTH = DateTimeFormatter.ofPattern("MMM yyyy");
    private static final DateTimeFormatter FMT_DATE  = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // ── Palette ──────────────────────────────────────────────────────────────
    private static final Color C_BG_LEFT    = new Color(15, 15, 25);        // quasi-noir
    private static final Color C_BG_RIGHT   = new Color(24, 24, 40);        // bleu nuit
    private static final Color C_ACCENT     = new Color(130, 90, 255);      // violet
    private static final Color C_ACCENT2    = new Color(80, 160, 255);      // bleu clair
    private static final Color C_GOLD       = new Color(255, 200, 80);      // or
    private static final Color C_WHITE      = new Color(255, 255, 255);
    private static final Color C_WHITE_70   = new Color(255, 255, 255, 178);
    private static final Color C_WHITE_30   = new Color(255, 255, 255, 76);
    private static final Color C_SEPARATOR  = new Color(255, 255, 255, 40);

    private final QRCodeService qrCodeService = new QRCodeService();

    // ─────────────────────────────────────────────────────────────────────────
    //  Point d'entrée principal
    // ─────────────────────────────────────────────────────────────────────────

    public BufferedImage generateVoucherImage(Voucher voucher) throws Exception {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        applyQuality(g);

        drawBackground(g);
        drawDecorations(g);

        int split = (int)(W * 0.58);   // 58% gauche / 42% droite
        drawLeftPanel(g, voucher, split);
        drawRightPanel(g, voucher, split);
        drawBorder(g);

        g.dispose();
        return img;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Fond + décorations
    // ─────────────────────────────────────────────────────────────────────────

    private void drawBackground(Graphics2D g) {
        // Dégradé horizontal
        GradientPaint grad = new GradientPaint(0, 0, C_BG_LEFT, W, 0, C_BG_RIGHT);
        g.setPaint(grad);
        g.fillRoundRect(0, 0, W, H, 20, 20);
    }

    private void drawDecorations(Graphics2D g) {
        // Grand cercle décoratif en haut à gauche (flou simulé par transparence)
        g.setColor(new Color(130, 90, 255, 25));
        g.fillOval(-80, -80, 320, 320);

        // Petit cercle en bas à droite
        g.setColor(new Color(80, 160, 255, 20));
        g.fillOval(W - 200, H - 180, 340, 340);

        // Lignes diagonales légères
        g.setStroke(new BasicStroke(1f));
        g.setColor(new Color(255, 255, 255, 8));
        for (int i = -H; i < W; i += 40) {
            g.drawLine(i, 0, i + H, H);
        }
    }

    private void drawBorder(Graphics2D g) {
        // Bordure extérieure dégradée
        g.setStroke(new BasicStroke(2f));
        GradientPaint bp = new GradientPaint(0, 0, C_ACCENT, W, H, C_ACCENT2);
        g.setPaint(bp);
        g.drawRoundRect(1, 1, W - 2, H - 2, 20, 20);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Panneau GAUCHE — montant + infos
    // ─────────────────────────────────────────────────────────────────────────

    private void drawLeftPanel(Graphics2D g, Voucher voucher, int split) {
        int padX = 52;
        int y    = 58;

        // ── Badge "GIFT VOUCHER" ──
        drawBadge(g, padX, y - 4, "GIFT VOUCHER");
        y += 38;

        // ── Montant (très grand) ──
        String amount = "Rs " + voucher.getMontant().toBigInteger();
        Font fBig = loadFont(Font.BOLD, 88);
        g.setFont(fBig);

        // Dégradé sur le texte du montant
        GradientPaint gp = new GradientPaint(padX, y, C_GOLD, padX + 400, y, C_WHITE);
        g.setPaint(gp);
        g.drawString(amount, padX, y + 78);
        y += 100;

        // ── Ligne séparatrice ──
        g.setColor(C_SEPARATOR);
        g.setStroke(new BasicStroke(1.5f));
        g.drawLine(padX, y, split - 50, y);
        y += 22;

        // ── Code voucher ──
        drawLabel(g, padX, y, "CODE");
        y += 20;
        drawValue(g, padX, y, voucher.getNoVoucher(), 15);
        y += 32;

        // ── Validité ──
        drawLabel(g, padX, y, "VALIDITÉ");
        y += 20;
        String validity = buildValidity(voucher);
        drawValue(g, padX, y, validity, 13);
        y += 32;

        // ── Statut ──
        drawLabel(g, padX, y, "STATUT");
        y += 22;
        drawStatusBadge(g, padX, y, voucher.getStatusVouch());
    }

    private void drawBadge(Graphics2D g, int x, int y, String text) {
        g.setFont(loadFont(Font.BOLD, 10));
        FontMetrics fm = g.getFontMetrics();
        int tw = fm.stringWidth(text);
        int bw = tw + 20;
        int bh = 22;

        GradientPaint gp = new GradientPaint(x, y, C_ACCENT, x + bw, y, C_ACCENT2);
        g.setPaint(gp);
        g.fillRoundRect(x, y, bw, bh, 11, 11);

        g.setColor(C_WHITE);
        g.drawString(text, x + 10, y + bh - 7);
    }

    private void drawLabel(Graphics2D g, int x, int y, String text) {
        g.setFont(loadFont(Font.PLAIN, 10));
        g.setColor(new Color(180, 160, 255, 200));
        g.drawString(text, x, y);
    }

    private void drawValue(Graphics2D g, int x, int y, String text, int size) {
        g.setFont(loadFont(Font.BOLD, size));
        g.setColor(C_WHITE);
        g.drawString(text, x, y);
    }

    private void drawStatusBadge(Graphics2D g, int x, int y, String status) {
        Color bg, fg;
        switch (status == null ? "" : status.toLowerCase()) {
            case "active":
                bg = new Color(40, 167, 69, 60);  fg = new Color(100, 220, 130); break;
            case "redeemed":
                bg = new Color(80, 160, 255, 60); fg = C_ACCENT2;              break;
            case "expired":
                bg = new Color(220, 53, 69, 60);  fg = new Color(255, 120, 130); break;
            default:
                bg = new Color(255, 200, 80, 60); fg = C_GOLD;
        }
        String label = (status != null ? status : "DRAFT").toUpperCase();
        g.setFont(loadFont(Font.BOLD, 10));
        FontMetrics fm = g.getFontMetrics();
        int bw = fm.stringWidth(label) + 18;
        g.setColor(bg);
        g.fillRoundRect(x, y - 14, bw, 20, 10, 10);
        g.setColor(fg);
        g.drawString(label, x + 9, y - 1);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Panneau DROIT — QR code
    // ─────────────────────────────────────────────────────────────────────────

    private void drawRightPanel(Graphics2D g, Voucher voucher, int split) throws Exception {
        // Séparateur pointillé vertical
        drawDashedSeparator(g, split);

        int centerX = split + (W - split) / 2;
        int qrSize  = 170;
        int qrX     = centerX - qrSize / 2;
        int qrY     = (H - qrSize) / 2 - 25;

        // Halo derrière le QR
        g.setColor(new Color(130, 90, 255, 30));
        g.fillOval(qrX - 15, qrY - 15, qrSize + 30, qrSize + 30);

        // Cadre QR arrondi blanc semi-transparent
        g.setColor(new Color(255, 255, 255, 18));
        g.fillRoundRect(qrX - 10, qrY - 10, qrSize + 20, qrSize + 20, 16, 16);
        g.setColor(new Color(255, 255, 255, 60));
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(qrX - 10, qrY - 10, qrSize + 20, qrSize + 20, 16, 16);

        // QR code lui-même
        BufferedImage qr = qrCodeService.generateQRCodeImage(voucher.getNoVoucher(), qrSize, qrSize);
        // Fond blanc pour le QR
        g.setColor(Color.WHITE);
        g.fillRect(qrX, qrY, qrSize, qrSize);
        g.drawImage(qr, qrX, qrY, null);

        // Texte sous le QR
        g.setFont(loadFont(Font.BOLD, 10));
        g.setColor(C_WHITE_70);
        String scan = "SCANNER POUR VALIDER";
        FontMetrics fm = g.getFontMetrics();
        g.drawString(scan, centerX - fm.stringWidth(scan) / 2, qrY + qrSize + 28);

        // Petit "VMS" en haut du panneau droit
        g.setFont(loadFont(Font.BOLD, 11));
        g.setColor(C_WHITE_30);
        String brand = "V M S";
        fm = g.getFontMetrics();
        g.drawString(brand, centerX - fm.stringWidth(brand) / 2, 36);
    }

    private void drawDashedSeparator(Graphics2D g, int x) {
        float[] dash = {6f, 6f};
        g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, dash, 0));
        g.setColor(new Color(255, 255, 255, 50));
        g.drawLine(x, 30, x, H - 30);
        g.setStroke(new BasicStroke(1f));
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private String buildValidity(Voucher voucher) {
        String from = voucher.getIssueDate()  != null ? FMT_MONTH.format(voucher.getIssueDate())  : "N/A";
        String to   = voucher.getExpireDate() != null ? FMT_DATE.format(voucher.getExpireDate())  : "N/A";
        return from + "  →  " + to;
    }

    private Font loadFont(int style, float size) {
        return new Font("SansSerif", style, (int) size);
    }

    private void applyQuality(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,       RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,  RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
        g.setRenderingHint(RenderingHints.KEY_RENDERING,          RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,      RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,  RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Sauvegarde / génération fichiers
    // ─────────────────────────────────────────────────────────────────────────

    public void saveVoucherImage(Voucher voucher, String outputPath) throws Exception {
        BufferedImage image = generateVoucherImage(voucher);
        File outputFile = new File(outputPath);
        outputFile.getParentFile().mkdirs();
        ImageIO.write(image, "PNG", outputFile);
        System.out.println("Image sauvegardée : " + outputPath);
    }

    public String generateAndSaveVoucher(Voucher voucher, String directory) throws Exception {
        String sanitized = voucher.getNoVoucher()
                .replace("/", "-").replace("\\", "-").replace(":", "-");
        String fullPath = directory + File.separator + "Voucher_" + sanitized + ".png";
        saveVoucherImage(voucher, fullPath);
        return fullPath;
    }

    public void generateVouchersImages(List<Voucher> vouchers, String directory) throws Exception {
        for (Voucher v : vouchers) generateAndSaveVoucher(v, directory);
        System.out.println("Génération terminée : " + vouchers.size() + " voucher(s)");
    }
}
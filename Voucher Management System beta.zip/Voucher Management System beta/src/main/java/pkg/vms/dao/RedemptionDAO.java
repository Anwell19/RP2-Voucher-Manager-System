package pkg.vms.dao;

import pkg.vms.models.Redemption;
import pkg.vms.models.Voucher;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO pour la rédemption de vouchers.
 *
 * Flux métier :
 *   1. validateVoucher(code)  → retourne ValidationStatus avec les infos du bon
 *   2. enregistrerRedemption() → écrit dans vms.redemption + met statut voucher à 'redeemed'
 *   3. getHistorique()        → liste des rédemptions pour le tableau
 */
public class RedemptionDAO {

    // ─── Résultat de validation ───────────────────────────────────────────────

    public enum ValidationResult {
        VALID,
        NOT_FOUND,
        ALREADY_REDEEMED,
        EXPIRED,
        INVALID_STATUS,
        ERROR
    }

    /** Encapsule le résultat de la validation avec les données du voucher */
    public static class ValidationStatus {
        public final ValidationResult result;
        public final Voucher          voucher; // non null si VALID
        public final String           message;

        public ValidationStatus(ValidationResult result, Voucher voucher, String message) {
            this.result  = result;
            this.voucher = voucher;
            this.message = message;
        }

        public boolean isValid() { return result == ValidationResult.VALID; }
    }

    // ─── Valider un voucher avant rédemption ──────────────────────────────────

    public ValidationStatus validateVoucher(String noVoucher) {
        if (noVoucher == null || noVoucher.trim().isEmpty()) {
            return new ValidationStatus(ValidationResult.NOT_FOUND, null, "Code vide.");
        }

        String sql = "SELECT v.*, c.nom_client " +
                "FROM vms.voucher v " +
                "LEFT JOIN vms.client c ON v.client_id = c.ref_client " +
                "WHERE UPPER(TRIM(v.no_voucher)) = UPPER(TRIM(?))";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, noVoucher.trim());
            ResultSet rs = stmt.executeQuery();

            if (!rs.next()) {
                return new ValidationStatus(ValidationResult.NOT_FOUND, null,
                        "Aucun voucher trouvé pour le code : " + noVoucher);
            }

            Voucher v = extractVoucher(rs);

            // Anti double-spend
            if ("redeemed".equalsIgnoreCase(v.getStatusVouch())) {
                return new ValidationStatus(ValidationResult.ALREADY_REDEEMED, v,
                        "Ce voucher a déjà été rédimé.");
            }

            // Statut invalide (draft, cancelled...)
            if (!"active".equalsIgnoreCase(v.getStatusVouch())) {
                return new ValidationStatus(ValidationResult.INVALID_STATUS, v,
                        "Statut du voucher invalide : " + v.getStatusVouch());
            }

            // Expiration
            if (v.getExpireDate() != null && v.getExpireDate().isBefore(LocalDateTime.now())) {
                return new ValidationStatus(ValidationResult.EXPIRED, v,
                        "Ce voucher a expiré le " + v.getExpireDate().toLocalDate());
            }

            return new ValidationStatus(ValidationResult.VALID, v, "Voucher valide.");

        } catch (SQLException e) {
            System.err.println("Erreur validation voucher : " + e.getMessage());
            return new ValidationStatus(ValidationResult.ERROR, null,
                    "Erreur technique : " + e.getMessage());
        }
    }

    // ─── Enregistrer une rédemption ───────────────────────────────────────────

    /**
     * Exécute la rédemption dans une transaction :
     *  1. Insère dans vms.redemption
     *  2. Met à jour vms.voucher.status_vouch = 'redeemed'
     */
    public boolean enregistrerRedemption(int refVoucher, int magasinId, int redeemedBy) {
        String sqlInsert = "INSERT INTO vms.redemption " +
                "(ref_voucher, magasin_id, redeemed_by, date_redemption, statut) " +
                "VALUES (?, ?, ?, CURRENT_TIMESTAMP, 'success')";

        String sqlUpdate = "UPDATE vms.voucher SET status_vouch = 'redeemed', " +
                "updated_at = CURRENT_TIMESTAMP WHERE ref_voucher = ?";

        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // 1. Enregistrer la rédemption
            try (PreparedStatement stmtInsert = conn.prepareStatement(sqlInsert)) {
                stmtInsert.setInt(1, refVoucher);
                stmtInsert.setInt(2, magasinId);
                stmtInsert.setInt(3, redeemedBy);
                stmtInsert.executeUpdate();
            }

            // 2. Marquer le voucher comme rédimé
            try (PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate)) {
                stmtUpdate.setInt(1, refVoucher);
                stmtUpdate.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("Erreur rédemption : " + e.getMessage());
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }
    }

    // ─── Historique des rédemptions ───────────────────────────────────────────

    public List<Redemption> getHistorique() {
        List<Redemption> liste = new ArrayList<>();
        String sql = "SELECT r.*, " +
                "v.no_voucher, v.montant, v.expire_date, v.status_vouch, " +
                "m.nom AS nom_magasin, " +
                "u.nom || ' ' || u.prenom AS nom_utilisateur, " +
                "c.nom_client " +
                "FROM vms.redemption r " +
                "LEFT JOIN vms.voucher  v ON r.ref_voucher = v.ref_voucher " +
                "LEFT JOIN vms.magasin  m ON r.magasin_id  = m.magasin_id " +
                "LEFT JOIN vms.users    u ON r.redeemed_by = u.user_id " +
                "LEFT JOIN vms.client   c ON v.client_id   = c.ref_client " +
                "ORDER BY r.date_redemption DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                liste.add(extractRedemption(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur historique rédemptions : " + e.getMessage());
            e.printStackTrace();
        }
        return liste;
    }

    // ─── Historique par magasin ───────────────────────────────────────────────

    public List<Redemption> getHistoriqueByMagasin(int magasinId) {
        List<Redemption> liste = new ArrayList<>();
        String sql = "SELECT r.*, " +
                "v.no_voucher, v.montant, v.expire_date, v.status_vouch, " +
                "m.nom AS nom_magasin, " +
                "u.nom || ' ' || u.prenom AS nom_utilisateur, " +
                "c.nom_client " +
                "FROM vms.redemption r " +
                "LEFT JOIN vms.voucher  v ON r.ref_voucher = v.ref_voucher " +
                "LEFT JOIN vms.magasin  m ON r.magasin_id  = m.magasin_id " +
                "LEFT JOIN vms.users    u ON r.redeemed_by = u.user_id " +
                "LEFT JOIN vms.client   c ON v.client_id   = c.ref_client " +
                "WHERE r.magasin_id = ? " +
                "ORDER BY r.date_redemption DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, magasinId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) liste.add(extractRedemption(rs));

        } catch (SQLException e) {
            System.err.println("Erreur historique rédemptions magasin : " + e.getMessage());
            e.printStackTrace();
        }
        return liste;
    }

    // ─── Comptage ─────────────────────────────────────────────────────────────

    public int countToday() {
        String sql = "SELECT COUNT(*) FROM vms.redemption WHERE DATE(date_redemption) = CURRENT_DATE";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Erreur countToday : " + e.getMessage());
        }
        return 0;
    }

    // ─── Extracteurs ─────────────────────────────────────────────────────────

    private Voucher extractVoucher(ResultSet rs) throws SQLException {
        Voucher v = new Voucher();
        v.setRefVoucher(rs.getInt("ref_voucher"));
        v.setNoVoucher(rs.getString("no_voucher"));
        v.setMontant(rs.getBigDecimal("montant"));
        v.setStatusVouch(rs.getString("status_vouch"));
        v.setClientId(rs.getInt("client_id"));
        v.setRefDemande(rs.getInt("ref_demande"));
        v.setClientName(rs.getString("nom_client"));
        // expire_date peut être timestamp ou date selon la BD
        try {
            Timestamp ts = rs.getTimestamp("expire_date");
            if (ts != null) v.setExpireDate(ts.toLocalDateTime());
        } catch (SQLException e) {
            Date d = rs.getDate("expire_date");
            if (d != null) v.setExpireDate(d.toLocalDate().atStartOfDay());
        }
        return v;
    }

    private Redemption extractRedemption(ResultSet rs) throws SQLException {
        Redemption r = new Redemption();
        r.setRefRedemption(rs.getInt("ref_redemption"));
        r.setRefVoucher(rs.getInt("ref_voucher"));
        r.setMagasinId(rs.getInt("magasin_id"));
        r.setRedeemedBy(rs.getInt("redeemed_by"));
        r.setStatut(rs.getString("statut"));
        r.setMotifEchec(rs.getString("motif_echec"));
        r.setNoVoucher(rs.getString("no_voucher"));
        r.setMontantVoucher(rs.getBigDecimal("montant"));
        r.setNomMagasin(rs.getString("nom_magasin"));
        r.setNomUtilisateur(rs.getString("nom_utilisateur"));
        r.setClientNom(rs.getString("nom_client"));
        r.setVoucherStatut(rs.getString("status_vouch"));

        Timestamp dateRed = rs.getTimestamp("date_redemption");
        if (dateRed != null) r.setDateRedemption(dateRed.toLocalDateTime());

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) r.setCreatedAt(createdAt.toLocalDateTime());

        try {
            Timestamp exp = rs.getTimestamp("expire_date");
            if (exp != null) r.setExpireDate(exp.toLocalDateTime());
        } catch (SQLException e) {
            Date exp = rs.getDate("expire_date");
            if (exp != null) r.setExpireDate(exp.toLocalDate().atStartOfDay());
        }

        return r;
    }
}
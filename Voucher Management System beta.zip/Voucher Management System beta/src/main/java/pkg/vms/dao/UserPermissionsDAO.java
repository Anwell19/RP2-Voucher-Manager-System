package pkg.vms.dao;

import java.sql.*;

/**
 * DAO pour la gestion des permissions de menu par utilisateur.
 *
 * Table : vms.user_permissions
 * Colonnes booléennes : menu_clients, menu_users, menu_magasins,
 *                       menu_demandes, menu_vouchers
 *
 * L'admin sélectionne les menus accessibles lors de la création
 * ou modification d'un utilisateur.
 */
public class UserPermissionsDAO {

    // ---------------------------------------------------------------
    // Lire
    // ---------------------------------------------------------------

    /**
     * Retourne les permissions d'un utilisateur.
     * Si aucune ligne n'existe, retourne des permissions vides (tout à false).
     */
    public UserPermissions getByUserId(int userId) {
        String sql = "SELECT * FROM vms.user_permissions WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return map(rs);
            }

        } catch (SQLException e) {
            System.err.println("[UserPermissionsDAO] getByUserId : " + e.getMessage());
        }

        // Pas de ligne → retourne permissions vides
        UserPermissions p = new UserPermissions();
        p.setUserId(userId);
        return p;
    }

    // ---------------------------------------------------------------
    // Écrire (UPSERT)
    // ---------------------------------------------------------------

    /**
     * Crée ou met à jour les permissions d'un utilisateur.
     * Utilise ON CONFLICT DO UPDATE pour simplifier la logique appelante.
     */
    public boolean save(UserPermissions perms) {
        String sql = """
                INSERT INTO vms.user_permissions
                    (user_id, menu_clients, menu_users, menu_magasins, menu_demandes, menu_vouchers, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT (user_id) DO UPDATE SET
                    menu_clients  = EXCLUDED.menu_clients,
                    menu_users    = EXCLUDED.menu_users,
                    menu_magasins = EXCLUDED.menu_magasins,
                    menu_demandes = EXCLUDED.menu_demandes,
                    menu_vouchers = EXCLUDED.menu_vouchers,
                    updated_at    = CURRENT_TIMESTAMP
                """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt    (1, perms.getUserId());
            stmt.setBoolean(2, perms.isMenuClients());
            stmt.setBoolean(3, perms.isMenuUsers());
            stmt.setBoolean(4, perms.isMenuMagasins());
            stmt.setBoolean(5, perms.isMenuDemandes());
            stmt.setBoolean(6, perms.isMenuVouchers());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("[UserPermissionsDAO] save : " + e.getMessage());
        }
        return false;
    }

    /**
     * Supprime les permissions d'un utilisateur (appelé avant suppression user).
     * La contrainte ON DELETE CASCADE le fait automatiquement, mais utile si besoin.
     */
    public boolean deleteByUserId(int userId) {
        String sql = "DELETE FROM vms.user_permissions WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("[UserPermissionsDAO] deleteByUserId : " + e.getMessage());
        }
        return false;
    }

    // ---------------------------------------------------------------
    // Mapping
    // ---------------------------------------------------------------

    private UserPermissions map(ResultSet rs) throws SQLException {
        UserPermissions p = new UserPermissions();
        p.setPermissionId(rs.getInt("permission_id"));
        p.setUserId      (rs.getInt("user_id"));
        p.setMenuClients (rs.getBoolean("menu_clients"));
        p.setMenuUsers   (rs.getBoolean("menu_users"));
        p.setMenuMagasins(rs.getBoolean("menu_magasins"));
        p.setMenuDemandes(rs.getBoolean("menu_demandes"));
        p.setMenuVouchers(rs.getBoolean("menu_vouchers"));
        return p;
    }

    // ---------------------------------------------------------------
    // Classe interne : modèle de permissions
    // ---------------------------------------------------------------

    public static class UserPermissions {
        private int     permissionId;
        private int     userId;
        private boolean menuClients;
        private boolean menuUsers;
        private boolean menuMagasins;
        private boolean menuDemandes;
        private boolean menuVouchers;

        // Getters
        public int     getPermissionId() { return permissionId; }
        public int     getUserId()       { return userId; }
        public boolean isMenuClients()   { return menuClients; }
        public boolean isMenuUsers()     { return menuUsers; }
        public boolean isMenuMagasins()  { return menuMagasins; }
        public boolean isMenuDemandes()  { return menuDemandes; }
        public boolean isMenuVouchers()  { return menuVouchers; }

        // Setters
        public void setPermissionId(int permissionId) { this.permissionId = permissionId; }
        public void setUserId(int userId)             { this.userId = userId; }
        public void setMenuClients(boolean v)         { this.menuClients = v; }
        public void setMenuUsers(boolean v)           { this.menuUsers = v; }
        public void setMenuMagasins(boolean v)        { this.menuMagasins = v; }
        public void setMenuDemandes(boolean v)        { this.menuDemandes = v; }
        public void setMenuVouchers(boolean v)        { this.menuVouchers = v; }

        @Override
        public String toString() {
            return "Permissions{userId=" + userId
                    + ", clients=" + menuClients
                    + ", users="   + menuUsers
                    + ", magasins=" + menuMagasins
                    + ", demandes=" + menuDemandes
                    + ", vouchers=" + menuVouchers + "}";
        }
    }
}

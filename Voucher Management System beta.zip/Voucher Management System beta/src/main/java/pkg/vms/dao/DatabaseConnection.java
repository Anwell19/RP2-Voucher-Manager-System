package pkg.vms.dao;

import pkg.vms.models.User;

import java.sql.*;

/**
 * Gestionnaire de connexion PostgreSQL.
 *
 * CORRECTION PRINCIPALE : Le singleton statique de l'ancienne version
 * pouvait retourner une connexion fermée ou invalide après un timeout réseau.
 *
 * Solution : on vérifie conn.isValid(2) avant de réutiliser la connexion,
 * et on la recrée si elle est invalide.
 *
 * Le try-with-resources dans chaque DAO ferme correctement la connexion
 * après chaque requête — donc on utilise ici un pool minimal.
 */
public class DatabaseConnection {

    private static final String URL      = "jdbc:postgresql://postgresql-vmsproject.alwaysdata.net:5432/vmsproject_vms";
    private static final String USER     = "vmsproject";
    private static final String PASSWORD = "Vmsmada2025";

    // Connexion réutilisable (pseudo-pool à 1 connexion)
    private static Connection conn = null;

    /**
     * Retourne une connexion valide.
     * Recrée la connexion si elle est nulle, fermée ou expirée.
     */
    public static synchronized Connection getConnection() {
        try {
            // Charger le driver
            Class.forName("org.postgresql.Driver");

            // Vérifier si la connexion existante est encore valide (timeout 2s)
            if (conn != null && !conn.isClosed() && conn.isValid(2)) {
                return conn;
            }

            // Fermer proprement l'ancienne connexion si elle existe
            if (conn != null) {
                try { conn.close(); } catch (SQLException ignored) {}
                conn = null;
            }

            // Créer une nouvelle connexion
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            conn.setAutoCommit(true);
            return conn;

        } catch (ClassNotFoundException e) {
            System.err.println("[DB] Driver PostgreSQL non trouvé : " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("[DB] Erreur de connexion PostgreSQL : " + e.getMessage());
            conn = null; // reset pour forcer nouvelle tentative au prochain appel
        }
        return null;
    }

    /**
     * Teste si la base de données est accessible.
     * Utilisé par l'indicateur de connexion dans la vue Rédemption.
     */
    public static boolean isConnected() {
        try {
            Connection c = getConnection();
            return c != null && !c.isClosed() && c.isValid(3);
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Authentifie un utilisateur (stub — délégué à LoginDAO en production).
     */
    public static User authenticate(String username, String password) {
        return null;
    }
}

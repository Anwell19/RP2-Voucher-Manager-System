package pkg.vms.dao;

import pkg.vms.models.Client;
import pkg.vms.dao.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientDAO {

    // Créer un nouveau client
    public boolean create(Client client) {
        String sql = "INSERT INTO vms.client (nom_client, email, adresse, company) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, client.getNom());
            stmt.setString(2, client.getEmail());
            stmt.setString(3, client.getAdresse());
            stmt.setString(4, client.getCompany());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    client.setId(rs.getInt(1)); // récupère ref_client généré
                }
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la création du client : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Lire tous les clients
    public List<Client> readAll() {
        List<Client> clients = new ArrayList<>();
        String sql = "SELECT * FROM vms.client ORDER BY nom_client";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                clients.add(extractClientFromResultSet(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la lecture des clients : " + e.getMessage());
            e.printStackTrace();
        }
        return clients;
    }

    // Lire un client par ID
    public Client readById(int id) {
        String sql = "SELECT * FROM vms.client WHERE ref_client = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return extractClientFromResultSet(rs);
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la lecture du client : " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    // Mettre à jour un client
    public boolean update(Client client) {
        String sql = "UPDATE vms.client SET nom_client = ?, email = ?, adresse = ?, company = ? WHERE ref_client = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, client.getNom());
            stmt.setString(2, client.getEmail());
            stmt.setString(3, client.getAdresse());
            stmt.setString(4, client.getCompany());
            stmt.setInt(5, client.getId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur lors de la mise à jour du client : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Supprimer un client
    public boolean delete(int id) {
        String sql = "DELETE FROM vms.client WHERE ref_client = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression du client : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Rechercher des clients
    public List<Client> search(String keyword) {
        List<Client> clients = new ArrayList<>();
        String sql = "SELECT * FROM vms.client WHERE " +
                "LOWER(nom_client) LIKE LOWER(?) OR " +
                "LOWER(email) LIKE LOWER(?) OR " +
                "LOWER(company) LIKE LOWER(?) " +
                "ORDER BY nom_client";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String searchPattern = "%" + keyword + "%";
            for (int i = 1; i <= 3; i++) {
                stmt.setString(i, searchPattern);
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                clients.add(extractClientFromResultSet(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche de clients : " + e.getMessage());
            e.printStackTrace();
        }
        return clients;
    }

    // Vérifier si un email existe déjà
    public boolean emailExists(String email, Integer excludeId) {
        String sql = excludeId == null ?
                "SELECT COUNT(*) FROM vms.client WHERE email = ?" :
                "SELECT COUNT(*) FROM vms.client WHERE email = ? AND ref_client != ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            if (excludeId != null) {
                stmt.setInt(2, excludeId);
            }

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la vérification de l'email : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Compter le nombre total de clients
    public int count() {
        String sql = "SELECT COUNT(*) FROM vms.client";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors du comptage des clients : " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }

    // Méthode utilitaire pour extraire un client du ResultSet
    private Client extractClientFromResultSet(ResultSet rs) throws SQLException {
        Client client = new Client();
        client.setId(rs.getInt("ref_client"));       // CORRIGÉ
        client.setNom(rs.getString("nom_client"));   // CORRIGÉ
        client.setEmail(rs.getString("email"));
        client.setAdresse(rs.getString("adresse"));
        client.setCompany(rs.getString("company"));

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            client.setCreatedAt(createdAt.toLocalDateTime());
        }

        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) {
            client.setUpdatedAt(updatedAt.toLocalDateTime());
        }

        return client;
    }

    // Supprimer tous les clients
    public boolean deleteAll() {
        String sql = "DELETE FROM vms.client";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            int rowsAffected = stmt.executeUpdate();
            System.out.println("✅ " + rowsAffected + " clients supprimés.");
            return true;

        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la suppression de tous les clients : " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }


}

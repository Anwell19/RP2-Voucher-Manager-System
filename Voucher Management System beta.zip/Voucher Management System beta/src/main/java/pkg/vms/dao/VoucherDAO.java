package pkg.vms.dao;

import pkg.vms.models.Voucher;
import pkg.vms.models.Demande;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VoucherDAO {

    // ─── Utilitaire : lire les colonnes disponibles dans un ResultSet ─────────

    private Set<String> getColumns(ResultSet rs) throws SQLException {
        Set<String> cols = new HashSet<>();
        ResultSetMetaData meta = rs.getMetaData();
        for (int i = 1; i <= meta.getColumnCount(); i++) {
            cols.add(meta.getColumnName(i).toLowerCase());
        }
        return cols;
    }

    /** Lit un LocalDateTime de façon sûre (retourne null si colonne absente ou valeur nulle) */
    private LocalDateTime safeGetDateTime(ResultSet rs, Set<String> cols, String colName) {
        try {
            if (cols.contains(colName.toLowerCase())) {
                return rs.getObject(colName, LocalDateTime.class);
            }
        } catch (SQLException ignored) {}
        return null;
    }

    /** Lit un String de façon sûre */
    private String safeGetString(ResultSet rs, Set<String> cols, String colName) {
        try {
            if (cols.contains(colName.toLowerCase())) {
                return rs.getString(colName);
            }
        } catch (SQLException ignored) {}
        return null;
    }

    /** Lit un int de façon sûre (retourne 0 si absent) */
    private int safeGetInt(ResultSet rs, Set<String> cols, String colName) {
        try {
            if (cols.contains(colName.toLowerCase())) {
                int v = rs.getInt(colName);
                return rs.wasNull() ? 0 : v;
            }
        } catch (SQLException ignored) {}
        return 0;
    }

    // ─── Récupérer toutes les demandes avec informations client ───────────────

    public List<Demande> getAllDemandeWithClient() throws SQLException {
        List<Demande> demandes = new ArrayList<>();
        String sql = "SELECT d.*, c.nom_client, c.email " +
                "FROM vms.demande d " +
                "LEFT JOIN vms.client c ON d.client_id = c.ref_client " +
                "ORDER BY d.ref_demande DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                demandes.add(extractDemande(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur SQL getAllDemandeWithClient: " + e.getMessage());
            throw e;
        }
        return demandes;
    }

    // ─── Récupérer une demande spécifique ────────────────────────────────────

    public Demande getDemandeById(int refDemande) throws SQLException {
        String sql = "SELECT d.*, c.nom_client, c.email " +
                "FROM vms.demande d " +
                "LEFT JOIN vms.client c ON d.client_id = c.ref_client " +
                "WHERE d.ref_demande = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, refDemande);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return extractDemande(rs);
        }
        return null;
    }

    private Demande extractDemande(ResultSet rs) throws SQLException {
        Demande demande = new Demande();
        demande.setRefDemande(rs.getInt("ref_demande"));
        demande.setClientId(rs.getInt("client_id"));
        demande.setDateCreation(rs.getObject("date_creation", LocalDateTime.class));
        demande.setNbVoucher(rs.getInt("nb_voucher"));
        demande.setValeurVoucher(rs.getBigDecimal("valeur_voucher"));
        demande.setStatut(rs.getString("statut"));
        demande.setDatePaiement(rs.getObject("date_payement", LocalDateTime.class));
        demande.setDateApprobation(rs.getObject("date_approbation", LocalDateTime.class));

        int duree = rs.getInt("duree");
        if (!rs.wasNull()) demande.setDuree(duree);

        demande.setExpireDate(rs.getDate("expire_date") != null ?
                rs.getDate("expire_date").toLocalDate() : null);
        demande.setStatusDemande(rs.getString("status_demande"));

        String clientName  = rs.getString("nom_client");
        String clientEmail = rs.getString("email");

        demande.setClientName(clientName  != null && !clientName.trim().isEmpty()
                ? clientName : "Client #" + demande.getClientId());
        demande.setClientEmail(clientEmail != null && !clientEmail.trim().isEmpty()
                ? clientEmail : "N/A");

        return demande;
    }

    // ─── Générer les vouchers via la fonction stockée ─────────────────────────
    //
    //  La fonction generate_vouchers_for_demande() peut retourner des colonnes
    //  avec des noms variés selon la version PostgreSQL / la définition exacte.
    //  On lit d'abord les métadonnées puis on mappe de façon défensive.
    //  Colonnes alternatives connues :
    //    issue_date  ↔  created_at / date_creation / issued_at
    //    expire_date ↔  expiry_date / expiration_date / date_expiration
    //    status_vouch ↔ statut / status / voucher_status
    //    no_voucher  ↔  code / voucher_code / code_voucher

    public List<Voucher> generateVouchersForDemande(int refDemande) throws SQLException {
        List<Voucher> vouchers = new ArrayList<>();
        String sql = "SELECT * FROM vms.generate_vouchers_for_demande(?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, refDemande);
            ResultSet rs = pstmt.executeQuery();

            // Lire les colonnes réellement retournées
            Set<String> cols = getColumns(rs);
            System.out.println("[VoucherDAO] Colonnes retournées par generate_vouchers_for_demande: " + cols);

            while (rs.next()) {
                Voucher v = new Voucher();

                // ref_voucher
                v.setRefVoucher(safeGetInt(rs, cols, "ref_voucher"));

                // no_voucher — alternatives possibles
                String noVoucher = safeGetString(rs, cols, "no_voucher");
                if (noVoucher == null) noVoucher = safeGetString(rs, cols, "code");
                if (noVoucher == null) noVoucher = safeGetString(rs, cols, "voucher_code");
                if (noVoucher == null) noVoucher = safeGetString(rs, cols, "code_voucher");
                v.setNoVoucher(noVoucher);

                // montant
                try { v.setMontant(rs.getBigDecimal("montant")); }
                catch (SQLException e) {
                    try { v.setMontant(rs.getBigDecimal("valeur")); } catch (SQLException ignored) {}
                }

                // issue_date — alternatives possibles
                LocalDateTime issueDate = safeGetDateTime(rs, cols, "issue_date");
                if (issueDate == null) issueDate = safeGetDateTime(rs, cols, "issued_at");
                if (issueDate == null) issueDate = safeGetDateTime(rs, cols, "date_creation");
                if (issueDate == null) issueDate = safeGetDateTime(rs, cols, "created_at");
                if (issueDate == null) issueDate = LocalDateTime.now(); // fallback
                v.setIssueDate(issueDate);

                // expire_date — alternatives possibles
                LocalDateTime expireDate = safeGetDateTime(rs, cols, "expire_date");
                if (expireDate == null) expireDate = safeGetDateTime(rs, cols, "expiry_date");
                if (expireDate == null) expireDate = safeGetDateTime(rs, cols, "expiration_date");
                if (expireDate == null) expireDate = safeGetDateTime(rs, cols, "date_expiration");
                // Essayer en tant que date simple (pas timestamp)
                if (expireDate == null && cols.contains("expire_date")) {
                    try {
                        Date d = rs.getDate("expire_date");
                        if (d != null) expireDate = d.toLocalDate().atStartOfDay();
                    } catch (SQLException ignored) {}
                }
                v.setExpireDate(expireDate);

                // qr_code
                v.setQrCode(safeGetString(rs, cols, "qr_code"));

                // status_vouch — alternatives possibles
                String status = safeGetString(rs, cols, "status_vouch");
                if (status == null) status = safeGetString(rs, cols, "statut");
                if (status == null) status = safeGetString(rs, cols, "status");
                if (status == null) status = safeGetString(rs, cols, "voucher_status");
                if (status == null) status = "active"; // fallback
                v.setStatusVouch(status);

                // client_id
                v.setClientId(safeGetInt(rs, cols, "client_id"));

                // ref_demande
                int rd = safeGetInt(rs, cols, "ref_demande");
                v.setRefDemande(rd != 0 ? rd : refDemande);

                vouchers.add(v);
            }
        }
        return vouchers;
    }

    // ─── Récupérer tous les vouchers d'une demande ────────────────────────────

    public List<Voucher> getVouchersByDemande(int refDemande) throws SQLException {
        List<Voucher> vouchers = new ArrayList<>();
        String sql = "SELECT v.*, c.nom_client " +
                "FROM vms.voucher v " +
                "LEFT JOIN vms.client c ON v.client_id = c.ref_client " +
                "WHERE v.ref_demande = ? " +
                "ORDER BY v.no_voucher";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, refDemande);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Voucher voucher = new Voucher();
                voucher.setRefVoucher(rs.getInt("ref_voucher"));
                voucher.setNoVoucher(rs.getString("no_voucher"));
                voucher.setMontant(rs.getBigDecimal("montant"));
                voucher.setIssueDate(rs.getObject("issue_date", LocalDateTime.class));
                voucher.setExpireDate(rs.getObject("expire_date", LocalDateTime.class));
                voucher.setQrCode(rs.getString("qr_code"));
                voucher.setStatusVouch(rs.getString("status_vouch"));
                voucher.setClientId(rs.getInt("client_id"));
                voucher.setRefDemande(rs.getInt("ref_demande"));
                voucher.setClientName(rs.getString("nom_client"));
                vouchers.add(voucher);
            }
        }
        return vouchers;
    }

    // ─── Récupérer un voucher spécifique ──────────────────────────────────────

    public Voucher getVoucherById(int refVoucher) throws SQLException {
        String sql = "SELECT v.*, c.nom_client, c.email " +
                "FROM vms.voucher v " +
                "LEFT JOIN vms.client c ON v.client_id = c.ref_client " +
                "WHERE v.ref_voucher = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, refVoucher);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Voucher v = new Voucher();
                v.setRefVoucher(rs.getInt("ref_voucher"));
                v.setNoVoucher(rs.getString("no_voucher"));
                v.setMontant(rs.getBigDecimal("montant"));
                v.setIssueDate(rs.getObject("issue_date", LocalDateTime.class));
                v.setExpireDate(rs.getObject("expire_date", LocalDateTime.class));
                v.setQrCode(rs.getString("qr_code"));
                v.setStatusVouch(rs.getString("status_vouch"));
                v.setClientId(rs.getInt("client_id"));
                v.setRefDemande(rs.getInt("ref_demande"));
                v.setClientName(rs.getString("nom_client"));
                return v;
            }
        }
        return null;
    }

    // ─── Mettre à jour le statut d'un voucher ────────────────────────────────

    public boolean updateVoucherStatus(int refVoucher, String status) throws SQLException {
        String sql = "UPDATE vms.voucher SET status_vouch = ?::voucher_status, " +
                "updated_at = CURRENT_TIMESTAMP WHERE ref_voucher = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, status);
            pstmt.setInt(2, refVoucher);
            return pstmt.executeUpdate() > 0;
        }
    }

    // ─── Comptage ────────────────────────────────────────────────────────────

    public int countVouchersByDemande(int refDemande) throws SQLException {
        String sql = "SELECT COUNT(*) FROM vms.voucher WHERE ref_demande = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, refDemande);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }

    public boolean hasGeneratedVouchers(int refDemande) throws SQLException {
        return countVouchersByDemande(refDemande) > 0;
    }

    // ─── Tous les vouchers avec détails ──────────────────────────────────────

    public List<Voucher> getAllVouchersWithDetails() throws SQLException {
        List<Voucher> vouchers = new ArrayList<>();
        String sql = "SELECT v.*, c.nom_client, d.nb_voucher " +
                "FROM vms.voucher v " +
                "LEFT JOIN vms.client c ON v.client_id = c.ref_client " +
                "LEFT JOIN vms.demande d ON v.ref_demande = d.ref_demande " +
                "ORDER BY v.ref_voucher DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Voucher v = new Voucher();
                v.setRefVoucher(rs.getInt("ref_voucher"));
                v.setNoVoucher(rs.getString("no_voucher"));
                v.setMontant(rs.getBigDecimal("montant"));
                v.setIssueDate(rs.getObject("issue_date", LocalDateTime.class));
                v.setExpireDate(rs.getObject("expire_date", LocalDateTime.class));
                v.setQrCode(rs.getString("qr_code"));
                v.setStatusVouch(rs.getString("status_vouch"));
                v.setClientId(rs.getInt("client_id"));
                v.setRefDemande(rs.getInt("ref_demande"));
                v.setClientName(rs.getString("nom_client"));
                v.setQuantity(rs.getInt("nb_voucher"));
                vouchers.add(v);
            }
        }
        return vouchers;
    }
}
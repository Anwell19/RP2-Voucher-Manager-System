package pkg.vms.dao;

import pkg.vms.models.User;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO CRUD pour vms.users.
 * Pas de table "roles" : le rôle est un enum PostgreSQL (user_role).
 * Valeurs valides : 'admin', 'manager', 'agent'
 */
public class UserManagementDAO {

    // ---------------------------------------------------------------
    // LIRE
    // ---------------------------------------------------------------

    public List<User> readAll() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM vms.users ORDER BY username";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) users.add(map(rs));

        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] readAll : " + e.getMessage());
        }
        return users;
    }

    public User readById(int userId) {
        String sql = "SELECT * FROM vms.users WHERE user_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] readById : " + e.getMessage());
        }
        return null;
    }

    public List<User> search(String keyword) {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM vms.users "
                + "WHERE LOWER(username) LIKE LOWER(?) "
                + "OR LOWER(nom) LIKE LOWER(?) "
                + "OR LOWER(prenom) LIKE LOWER(?) "
                + "OR LOWER(COALESCE(email,'')) LIKE LOWER(?) "
                + "ORDER BY username";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String pat = "%" + keyword + "%";
            stmt.setString(1, pat);
            stmt.setString(2, pat);
            stmt.setString(3, pat);
            stmt.setString(4, pat);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) users.add(map(rs));
            }
        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] search : " + e.getMessage());
        }
        return users;
    }

    // ---------------------------------------------------------------
    // CRÉER
    // ---------------------------------------------------------------

    /**
     * Crée un utilisateur. Le mot de passe en clair est passé séparément
     * et haché avant insertion.
     */
    public boolean create(User user, String plainPassword) {
        String sql = "INSERT INTO vms.users "
                + "(username, nom, prenom, role, password_hash, email, titre, statut) "
                + "VALUES (?, ?, ?, ?::vms.user_role, ?, ?, ?, ?::vms.user_status)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getNom());
            stmt.setString(3, user.getPrenom());
            stmt.setString(4, user.getRole() != null ? user.getRole() : "agent");
            stmt.setString(5, LoginDAO.hashPassword(plainPassword));
            stmt.setString(6, user.getEmail());
            stmt.setString(7, user.getTitre());
            stmt.setString(8, user.getStatut() != null ? user.getStatut() : "active");

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = stmt.getGeneratedKeys()) {
                    if (keys.next()) user.setUserId(keys.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] create : " + e.getMessage());
        }
        return false;
    }

    // ---------------------------------------------------------------
    // METTRE À JOUR
    // ---------------------------------------------------------------

    /** Met à jour toutes les infos sauf le mot de passe. */
    public boolean update(User user) {
        String sql = "UPDATE vms.users SET "
                + "username = ?, nom = ?, prenom = ?, role = ?::vms.user_role, "
                + "email = ?, titre = ?, statut = ?::vms.user_status, "
                + "updated_at = CURRENT_TIMESTAMP "
                + "WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getNom());
            stmt.setString(3, user.getPrenom());
            stmt.setString(4, user.getRole());
            stmt.setString(5, user.getEmail());
            stmt.setString(6, user.getTitre());
            stmt.setString(7, user.getStatut() != null ? user.getStatut() : "active");
            stmt.setInt(8, user.getUserId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] update : " + e.getMessage());
        }
        return false;
    }

    /** Change le mot de passe (admin / reset — pas de vérification ancien MDP). */
    public boolean changePassword(int userId, String newPlainPassword) {
        String sql = "UPDATE vms.users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, LoginDAO.hashPassword(newPlainPassword));
            stmt.setInt(2, userId);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] changePassword : " + e.getMessage());
        }
        return false;
    }

    // ---------------------------------------------------------------
    // SUPPRIMER
    // ---------------------------------------------------------------

    public boolean delete(int userId) {
        String sql = "DELETE FROM vms.users WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] delete : " + e.getMessage());
        }
        return false;
    }

    // ---------------------------------------------------------------
    // VÉRIFICATIONS
    // ---------------------------------------------------------------

    public boolean usernameExists(String username, Integer excludeUserId) {
        String sql = excludeUserId == null
                ? "SELECT COUNT(*) FROM vms.users WHERE username = ?"
                : "SELECT COUNT(*) FROM vms.users WHERE username = ? AND user_id <> ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            if (excludeUserId != null) stmt.setInt(2, excludeUserId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] usernameExists : " + e.getMessage());
        }
        return false;
    }

    public boolean emailExists(String email, Integer excludeUserId) {
        String sql = excludeUserId == null
                ? "SELECT COUNT(*) FROM vms.users WHERE email = ?"
                : "SELECT COUNT(*) FROM vms.users WHERE email = ? AND user_id <> ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            if (excludeUserId != null) stmt.setInt(2, excludeUserId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] emailExists : " + e.getMessage());
        }
        return false;
    }

    public int count() {
        String sql = "SELECT COUNT(*) FROM vms.users";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[UserManagementDAO] count : " + e.getMessage());
        }
        return 0;
    }

    // ---------------------------------------------------------------
    // Mapping
    // ---------------------------------------------------------------

    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setUserId(rs.getInt("user_id"));
        u.setUsername(rs.getString("username"));
        u.setNom(rs.getString("nom"));
        u.setPrenom(rs.getString("prenom"));
        u.setRole(rs.getString("role"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setDdl(rs.getObject("ddl", LocalDateTime.class));
        u.setEmail(rs.getString("email"));
        u.setTitre(rs.getString("titre"));
        u.setStatut(rs.getString("statut"));
        u.setCreatedAt(rs.getObject("created_at", LocalDateTime.class));
        u.setUpdatedAt(rs.getObject("updated_at", LocalDateTime.class));
        return u;
    }
}
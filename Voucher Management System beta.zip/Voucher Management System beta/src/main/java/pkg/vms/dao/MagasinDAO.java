package pkg.vms.dao;

import pkg.vms.models.Magasin;
import pkg.vms.dao.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MagasinDAO {

    // Créer un magasin
    public boolean create(Magasin magasin) {
        String sql = "INSERT INTO vms.magasin (nom, attribute1) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, magasin.getNom());
            stmt.setString(2, magasin.getAttribute1());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    magasin.setMagasinId(rs.getInt(1));
                }
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la création du magasin : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Lire tous les magasins
    public List<Magasin> readAll() {
        List<Magasin> magasins = new ArrayList<>();
        String sql = "SELECT * FROM vms.magasin ORDER BY nom";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                magasins.add(extractMagasinFromResultSet(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la lecture des magasins : " + e.getMessage());
            e.printStackTrace();
        }
        return magasins;
    }

    // Lire un magasin par ID
    public Magasin readById(int magasinId) {
        String sql = "SELECT * FROM vms.magasin WHERE magasin_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, magasinId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return extractMagasinFromResultSet(rs);
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la lecture du magasin : " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    // Mettre à jour un magasin
    public boolean update(Magasin magasin) {
        String sql = "UPDATE vms.magasin SET nom = ?, attribute1 = ? WHERE magasin_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, magasin.getNom());
            stmt.setString(2, magasin.getAttribute1());
            stmt.setInt(3, magasin.getMagasinId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur lors de la mise à jour du magasin : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Supprimer un magasin
    public boolean delete(int magasinId) {
        String sql = "DELETE FROM vms.magasin WHERE magasin_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, magasinId);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression du magasin : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Rechercher des magasins
    public List<Magasin> search(String keyword) {
        List<Magasin> magasins = new ArrayList<>();
        String sql = "SELECT * FROM vms.magasin WHERE " +
                "LOWER(nom) LIKE LOWER(?) OR " +
                "LOWER(attribute1) LIKE LOWER(?) " +
                "ORDER BY nom";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                magasins.add(extractMagasinFromResultSet(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche de magasins : " + e.getMessage());
            e.printStackTrace();
        }
        return magasins;
    }

    // Compter le nombre de magasins
    public int count() {
        String sql = "SELECT COUNT(*) FROM vms.magasin";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.err.println("Erreur lors du comptage des magasins : " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }

    // Extraire un magasin du ResultSet
    private Magasin extractMagasinFromResultSet(ResultSet rs) throws SQLException {
        Magasin magasin = new Magasin();
        magasin.setMagasinId(rs.getInt("magasin_id"));
        magasin.setNom(rs.getString("nom"));
        magasin.setAttribute1(rs.getString("attribute1"));

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            magasin.setCreatedAt(createdAt.toLocalDateTime());
        }

        return magasin;
    }
}
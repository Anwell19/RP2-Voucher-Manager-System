package pkg.vms.dao;

import pkg.vms.models.Demande;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DemandeDAO {

    // ─── CREATE ──────────────────────────────────────────────────────
    public boolean create(Demande demande) {
        String sql = "INSERT INTO vms.demande " +
                "(client_id, nb_voucher, valeur_voucher, duree, expire_date, status_demande, initiated_by) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, demande.getClientId());
            stmt.setInt(2, demande.getNbVoucher());
            stmt.setBigDecimal(3, demande.getValeurVoucher());

            // Durée nullable
            if (demande.getDuree() != null)
                stmt.setInt(4, demande.getDuree());
            else
                stmt.setNull(4, Types.INTEGER);

            // Date expiration nullable
            if (demande.getExpireDate() != null)
                stmt.setDate(5, Date.valueOf(demande.getExpireDate()));
            else
                stmt.setNull(5, Types.DATE);

            stmt.setString(6, demande.getStatusDemande());

            // ── FIX PRINCIPAL : initiated_by nullable ─────────────────
            // On utilise setObject avec Types.INTEGER pour gérer proprement le NULL
            // sans violer la FK si l'utilisateur n'est pas encore créé
            if (demande.getInitiatedBy() != null)
                stmt.setInt(7, demande.getInitiatedBy());
            else
                stmt.setNull(7, Types.INTEGER);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        demande.setRefDemande(rs.getInt(1));
                    }
                }
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Erreur création demande : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // ─── READ ALL ─────────────────────────────────────────────────────
    public List<Demande> readAll() {
        List<Demande> demandes = new ArrayList<>();
        String sql = "SELECT d.*, c.nom_client AS client_nom, c.email AS client_email " +
                "FROM vms.demande d " +
                "LEFT JOIN vms.client c ON d.client_id = c.ref_client " +
                "ORDER BY d.ref_demande DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                demandes.add(extractFromResultSet(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur lecture demandes : " + e.getMessage());
            e.printStackTrace();
        }
        return demandes;
    }

    // ─── READ BY REF ──────────────────────────────────────────────────
    public Demande readByRef(int refDemande) {
        String sql = "SELECT d.*, c.nom_client AS client_nom, c.email AS client_email " +
                "FROM vms.demande d " +
                "LEFT JOIN vms.client c ON d.client_id = c.ref_client " +
                "WHERE d.ref_demande = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, refDemande);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return extractFromResultSet(rs);
            }

        } catch (SQLException e) {
            System.err.println("Erreur lecture demande #" + refDemande + " : " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    // ─── UPDATE ───────────────────────────────────────────────────────
    public boolean update(Demande demande) {
        String sql = "UPDATE vms.demande SET client_id=?, nb_voucher=?, valeur_voucher=?, " +
                "duree=?, expire_date=?, status_demande=? " +
                "WHERE ref_demande=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, demande.getClientId());
            stmt.setInt(2, demande.getNbVoucher());
            stmt.setBigDecimal(3, demande.getValeurVoucher());

            if (demande.getDuree() != null) stmt.setInt(4, demande.getDuree());
            else stmt.setNull(4, Types.INTEGER);

            if (demande.getExpireDate() != null) stmt.setDate(5, Date.valueOf(demande.getExpireDate()));
            else stmt.setNull(5, Types.DATE);

            stmt.setString(6, demande.getStatusDemande());
            stmt.setInt(7, demande.getRefDemande());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur mise à jour demande : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // ─── DELETE ───────────────────────────────────────────────────────
    public boolean delete(int refDemande) {
        String sql = "DELETE FROM vms.demande WHERE ref_demande = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, refDemande);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur suppression demande : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // ─── MARQUER PAYÉ ─────────────────────────────────────────────────
    public boolean marquerPaye(int refDemande, Integer paidBy) {
        String sql = "UPDATE vms.demande SET statut='payee', date_payement=CURRENT_TIMESTAMP, " +
                "paid_by=? WHERE ref_demande=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            if (paidBy != null) stmt.setInt(1, paidBy);
            else stmt.setNull(1, Types.INTEGER);
            stmt.setInt(2, refDemande);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur marquage paiement : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // ─── MARQUER APPROUVÉ ─────────────────────────────────────────────
    public boolean marquerApprouve(int refDemande, Integer approvedBy) {
        String sql = "UPDATE vms.demande SET statut='approuvee', date_approbation=CURRENT_TIMESTAMP, " +
                "approved_by=? WHERE ref_demande=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            if (approvedBy != null) stmt.setInt(1, approvedBy);
            else stmt.setNull(1, Types.INTEGER);
            stmt.setInt(2, refDemande);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur approbation : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // ─── MARQUER REJETÉ ───────────────────────────────────────────────
    public boolean marquerRejetee(int refDemande, String motif) {
        String sql = "UPDATE vms.demande SET statut='rejetee', status_demande=? WHERE ref_demande=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "Rejeté : " + motif);
            stmt.setInt(2, refDemande);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur rejet demande : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // ─── RECHERCHE ────────────────────────────────────────────────────
    public List<Demande> search(String keyword) {
        List<Demande> demandes = new ArrayList<>();
        String sql = "SELECT d.*, c.nom_client AS client_nom, c.email AS client_email " +
                "FROM vms.demande d " +
                "LEFT JOIN vms.client c ON d.client_id = c.ref_client " +
                "WHERE CAST(d.ref_demande AS TEXT) LIKE ? " +
                "OR LOWER(c.nom_client) LIKE LOWER(?) " +
                "OR LOWER(c.email) LIKE LOWER(?) " +
                "OR LOWER(d.status_demande) LIKE LOWER(?) " +
                "ORDER BY d.ref_demande DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String pattern = "%" + keyword + "%";
            for (int i = 1; i <= 4; i++) stmt.setString(i, pattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) demandes.add(extractFromResultSet(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur recherche demandes : " + e.getMessage());
            e.printStackTrace();
        }
        return demandes;
    }

    // ─── FILTRER PAR STATUT ───────────────────────────────────────────
    public List<Demande> filterByStatut(String statut) {
        List<Demande> demandes = new ArrayList<>();
        String sql = "SELECT d.*, c.nom_client AS client_nom, c.email AS client_email " +
                "FROM vms.demande d " +
                "LEFT JOIN vms.client c ON d.client_id = c.ref_client " +
                "WHERE d.statut = ? " +
                "ORDER BY d.ref_demande DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, statut);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) demandes.add(extractFromResultSet(rs));
            }

        } catch (SQLException e) {
            System.err.println("Erreur filtre statut : " + e.getMessage());
            e.printStackTrace();
        }
        return demandes;
    }

    // ─── COUNT ────────────────────────────────────────────────────────
    public static int count() {
        String sql = "SELECT COUNT(*) FROM vms.demande";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) return rs.getInt(1);

        } catch (SQLException e) {
            System.err.println("Erreur comptage demandes : " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }

    // ─── EXTRACT ──────────────────────────────────────────────────────
    private Demande extractFromResultSet(ResultSet rs) throws SQLException {
        Demande d = new Demande();

        d.setRefDemande(rs.getInt("ref_demande"));
        d.setClientId(rs.getInt("client_id"));
        d.setNbVoucher(rs.getInt("nb_voucher"));
        d.setValeurVoucher(rs.getBigDecimal("valeur_voucher"));
        d.setStatut(rs.getString("statut"));
        d.setStatusDemande(rs.getString("status_demande"));

        Timestamp dateCreation = rs.getTimestamp("date_creation");
        if (dateCreation != null) d.setDateCreation(dateCreation.toLocalDateTime());

        Timestamp datePayement = rs.getTimestamp("date_payement");
        if (datePayement != null) d.setDatePayement(datePayement.toLocalDateTime());

        Timestamp dateApprobation = rs.getTimestamp("date_approbation");
        if (dateApprobation != null) d.setDateApprobation(dateApprobation.toLocalDateTime());

        // Colonnes nullable → getObject pour éviter NPE
        Object duree = rs.getObject("duree");
        if (duree != null) d.setDuree(((Number) duree).intValue());

        Date expireDate = rs.getDate("expire_date");
        if (expireDate != null) d.setExpireDate(expireDate.toLocalDate());

        Object initiatedBy = rs.getObject("initiated_by");
        if (initiatedBy != null) d.setInitiatedBy(((Number) initiatedBy).intValue());

        Object approvedBy = rs.getObject("approved_by");
        if (approvedBy != null) d.setApprovedBy(((Number) approvedBy).intValue());

        Object paidBy = rs.getObject("paid_by");
        if (paidBy != null) d.setPaidBy(((Number) paidBy).intValue());

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) d.setCreatedAt(createdAt.toLocalDateTime());

        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) d.setUpdatedAt(updatedAt.toLocalDateTime());

        d.setClientNom(rs.getString("client_nom"));
        d.setClientEmail(rs.getString("client_email"));

        return d;
    }
}
package pkg.vms.dao;

import pkg.vms.models.User;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.time.LocalDateTime;

/**
 * DAO d'authentification — utilise le schéma vms.users.
 * La colonne "role" est un enum PostgreSQL (user_role).
 * La colonne "statut" est un enum PostgreSQL (user_status).
 */
public class LoginDAO {

    // ---------------------------------------------------------------
    // Authentification
    // ---------------------------------------------------------------

    /**
     * Authentifie un utilisateur actif.
     * Retourne l'objet User si les credentials sont corrects, null sinon.
     */
    public User authenticate(String username, String password) throws SQLException {
        String sql = "SELECT * FROM vms.users WHERE username = ? AND statut = 'active'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("password_hash");
                    String inputHash  = hashPassword(password);

                    if (storedHash != null && storedHash.equals(inputHash)) {
                        User user = mapResultSetToUser(rs);
                        updateLastLogin(user.getUserId());
                        System.out.println("[LoginDAO] Authentification OK : "
                                + user.getFullName() + " (rôle : " + user.getRole() + ")");
                        return user;
                    } else {
                        System.out.println("[LoginDAO] Mot de passe incorrect pour : " + username);
                    }
                } else {
                    System.out.println("[LoginDAO] Utilisateur non trouvé ou inactif : " + username);
                }
            }
        } catch (SQLException e) {
            System.err.println("[LoginDAO] Erreur d'authentification : " + e.getMessage());
            throw e;
        }
        return null;
    }

    // ---------------------------------------------------------------
    // Création d'utilisateur
    // ---------------------------------------------------------------

    /**
     * Insère un nouvel utilisateur dans vms.users.
     * Les colonnes "role" et "statut" sont des enums PostgreSQL :
     * on les caste explicitement dans la requête SQL.
     */
    public boolean createUser(User user, String password) throws SQLException {
        String sql = "INSERT INTO vms.users "
                + "(username, nom, prenom, role, password_hash, email, titre, statut) "
                + "VALUES (?, ?, ?, ?::vms.user_role, ?, ?, ?, ?::vms.user_status)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getNom());
            pstmt.setString(3, user.getPrenom());
            pstmt.setString(4, user.getRole() != null ? user.getRole() : "agent");
            pstmt.setString(5, hashPassword(password));
            pstmt.setString(6, user.getEmail());
            pstmt.setString(7, user.getTitre());
            pstmt.setString(8, user.getStatut() != null ? user.getStatut() : "active");

            int affected = pstmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = pstmt.getGeneratedKeys()) {
                    if (keys.next()) {
                        user.setUserId(keys.getInt(1));
                    }
                }
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------
    // Vérifications
    // ---------------------------------------------------------------

    /** Renvoie true si le username est déjà pris (optionnellement en excluant un userId). */
    public boolean usernameExists(String username, Integer excludeUserId) throws SQLException {
        String sql = excludeUserId == null
                ? "SELECT COUNT(*) FROM vms.users WHERE username = ?"
                : "SELECT COUNT(*) FROM vms.users WHERE username = ? AND user_id <> ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            if (excludeUserId != null) pstmt.setInt(2, excludeUserId);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    /** Renvoie true si l'email est déjà utilisé (optionnellement en excluant un userId). */
    public boolean emailExists(String email, Integer excludeUserId) throws SQLException {
        String sql = excludeUserId == null
                ? "SELECT COUNT(*) FROM vms.users WHERE email = ?"
                : "SELECT COUNT(*) FROM vms.users WHERE email = ? AND user_id <> ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            if (excludeUserId != null) pstmt.setInt(2, excludeUserId);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    // ---------------------------------------------------------------
    // Gestion du mot de passe
    // ---------------------------------------------------------------

    /** Vérifie l'ancien MDP avant de mettre à jour. */
    public boolean changePassword(int userId, String oldPassword, String newPassword) throws SQLException {
        String checkSql  = "SELECT password_hash FROM vms.users WHERE user_id = ?";
        String updateSql = "UPDATE vms.users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {

            checkStmt.setInt(1, userId);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (!rs.next()) return false;
                if (!rs.getString("password_hash").equals(hashPassword(oldPassword))) return false;
            }

            try (PreparedStatement updStmt = conn.prepareStatement(updateSql)) {
                updStmt.setString(1, hashPassword(newPassword));
                updStmt.setInt(2, userId);
                return updStmt.executeUpdate() > 0;
            }
        }
    }

    /** Réinitialise le MDP sans vérifier l'ancien (action admin). */
    public boolean resetPassword(int userId, String newPassword) throws SQLException {
        String sql = "UPDATE vms.users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, hashPassword(newPassword));
            pstmt.setInt(2, userId);
            return pstmt.executeUpdate() > 0;
        }
    }

    // ---------------------------------------------------------------
    // Lecture
    // ---------------------------------------------------------------

    public User getUserById(int userId) throws SQLException {
        String sql = "SELECT * FROM vms.users WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapResultSetToUser(rs);
            }
        }
        return null;
    }

    // ---------------------------------------------------------------
    // Helpers privés
    // ---------------------------------------------------------------

    private void updateLastLogin(int userId) {
        String sql = "UPDATE vms.users SET ddl = CURRENT_TIMESTAMP WHERE user_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[LoginDAO] Erreur maj dernière connexion : " + e.getMessage());
        }
    }

    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setNom(rs.getString("nom"));
        user.setPrenom(rs.getString("prenom"));
        user.setRole(rs.getString("role"));
        user.setPasswordHash(rs.getString("password_hash"));
        user.setDdl(rs.getObject("ddl", LocalDateTime.class));
        user.setEmail(rs.getString("email"));
        user.setTitre(rs.getString("titre"));
        user.setStatut(rs.getString("statut"));
        user.setCreatedAt(rs.getObject("created_at", LocalDateTime.class));
        user.setUpdatedAt(rs.getObject("updated_at", LocalDateTime.class));
        return user;
    }

    // ---------------------------------------------------------------
    // Hash SHA-256 (public pour réutilisation dans UserManagementDAO)
    // ---------------------------------------------------------------

    public static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) sb.append('0');
                sb.append(hex);
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erreur hashage", e);
        }
    }

    /** Utilitaire : génère des hashs pour initialiser la DB. */
    public static void main(String[] args) {
        System.out.println("admin123  -> " + hashPassword("admin123"));
        System.out.println("manager123 -> " + hashPassword("manager123"));
        System.out.println("agent123  -> " + hashPassword("agent123"));
    }
}
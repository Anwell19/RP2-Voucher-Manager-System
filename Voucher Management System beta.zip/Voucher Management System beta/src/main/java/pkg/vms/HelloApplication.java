package pkg.vms;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        URL fxmlUrl = getClass().getResource("/pkg/vms/fxml/login.fxml");

        if (fxmlUrl == null) {
            System.err.println("ERROR: FXML introuvable.");
            throw new RuntimeException("FXML file not found");
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        Parent root = loader.load();

        Scene scene = new Scene(root);


        scene.getStylesheets().add(
                getClass().getResource("/pkg/vms/css/style.css").toExternalForm()
        );

        stage.setScene(scene);
        stage.setTitle("Voucher Management System");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}

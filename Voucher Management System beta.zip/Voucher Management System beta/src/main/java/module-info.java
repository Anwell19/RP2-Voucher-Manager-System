module pkg.vms {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.postgresql.jdbc;
    requires activation;
    requires java.mail;
    requires itextpdf;
    requires com.google.zxing;
    requires com.google.zxing.javase;
    requires javafx.graphics;
    requires java.desktop;
    opens pkg.vms to javafx.fxml;
    opens pkg.vms.models to javafx.base, javafx.fxml;
    opens pkg.vms.controllers to javafx.fxml;

    exports pkg.vms;

}
